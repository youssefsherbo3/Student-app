# Student API contract (`/api/v1`)

Reconstructed from `apps/api/src/student.js`. Source of truth is the code. All routes except `auth/register|login|refresh|forgot-password` need `Authorization: Bearer <access token>`. The app sends `X-Device-Id` on every request (account is bound to the first device; other devices get `403 device_locked`).

| Method & path | Purpose |
|---|---|
| POST `/auth/register` · `/auth/login` · `/auth/refresh` · `/auth/logout` | account + tokens (access 1 h, refresh 60 d, rotated) |
| POST `/auth/forgot-password` | creates a request for the assistant |
| GET / PATCH `/auth/me` · POST `/auth/change-password` | profile |
| GET `/courses` · `/courses/:id/my-rank` | subscribed courses, class rank |
| GET `/courses/:id/lessons` | lessons (sequential unlock, `opensAt`, `unlockAfterQuizId`) |
| POST `/lessons/:id/start` · `/heartbeat` · `/complete` | watch tracking (min watch seconds) |
| GET `/lesson-files/:id` | PDF handout |
| GET `/courses/:id/quizzes` · `/quizzes/:id/questions` | quizzes / homework |
| POST `/quizzes/:id/start` · `/quizzes/:id/submit` | timed, shuffled sessions |
| GET `/quizzes/:id/attempts` · `/submissions/:id` | attempts and review |
| POST `/uploads` (multipart `file`) · GET `/uploads/:id` | essay photos / avatar |
| POST `/codes/redeem` | subscription code |
| GET `/notifications` · `/notifications/unread-count` · POST `/notifications/read-all` · `/notifications/:id/read` | inbox |
| POST / DELETE `/push-tokens` | device push tokens (stored only, no FCM yet) |

Back-office endpoints (`/api/v1/admin/*`, header `X-Admin-Key`) are listed in `apps/api/README.md`.
