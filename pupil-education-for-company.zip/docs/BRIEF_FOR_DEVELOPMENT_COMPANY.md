# Project brief – Education platform (student app + API)

> Fill in every `[ ... ]` before sending. Delete this line.

## 1. What is in this archive
- `apps/mobile` – Flutter student app (Android / iOS / Web), Arabic, RTL. Verified with `flutter analyze` and `flutter test`.
- `apps/api` – Node.js 18+ / Express / SQLite REST API (`/api/v1`) plus a back-office API (no web admin UI exists).
- `docs/API.md` – API summary. Start with `README.md`.
- No APK/IPA, no signing keys, no secrets are included.

## 2. Requested changes
[Replace with the numbered list: what to change, in the app / API / both, with screenshots or examples. Mark priority: must / nice-to-have.]

1. [ ]
2. [ ]

## 3. Known state of the code (so you can quote accurately)
- The app's default `API_URL` (`apps/mobile/lib/core/config.dart`) points to an old server: `https://pupil-learning-hub--awedy52.replit.app`. The `apps/api` backend is a separate, new implementation with an empty database. **Decision:** [keep old server / migrate to new API – choose one].
- Push notifications are not implemented (`NoopPushService`; no Firebase).
- Tokens are stored unencrypted in SharedPreferences.
- Android release build is signed with the debug key; app/bundle IDs are placeholders (`com.pupil.edu_student`, `com.pupil.eduStudent`), default launcher icon.
- Single-instance backend (SQLite); needs a persistent disk for `DATA_DIR`.

## 4. What we will provide
- Final app name / bundle ID: [ ]
- Logo, icon, brand colors: [ ]
- Store accounts: Google Play [ ] · Apple Developer [ ] (invite you as a developer; we keep ownership)
- Hosting / domain (https): [ ]
- Access to the old server (only if we keep it): [ ]
- Secrets (`JWT_SECRET`, `ADMIN_KEY`, signing keystore) are created and held by us.

## 5. Deliverables expected
- Full source code in a Git repository we own, with history.
- `flutter analyze`, `flutter test` and `npm test` still passing.
- Signed Android release (AAB/APK) and iOS build/TestFlight upload.
- Short written notes of what changed and how to deploy.
- IP/ownership of all code is transferred to us.

## 6. Commercial
- Timeline: [ ] · Price/payment milestones: [ ] · Support/warranty period after delivery: [ ]
- Contact: [name / phone / email]
