# Education platform API (`/api/v1`)

Express + SQLite backend for the student mobile app in `../mobile`. It implements every endpoint the app calls
(auth with device binding + refresh tokens, courses, sequential lessons with minimum watch time, timed/shuffled quizzes,
essay answers with photos, grading, ranking, notifications, subscription codes, uploads) plus a back-office API.

> This is a **new, self-contained implementation** written from the app's request/response contract. It is NOT the
> original server that runs at `pupil-learning-hub--awedy52.replit.app` and it starts with an empty database.

## Run locally

```bash
cd apps/api
npm install
cp .env.example .env     # then edit; or export JWT_SECRET / ADMIN_KEY in your shell
npm run seed:demo        # optional: demo teacher, courses, lessons, quizzes, 3 students, codes (printed once)
npm start                # http://0.0.0.0:3000   (health: /health)
npm test                 # end-to-end smoke test (36 checks, uses a temporary database)
```

Node 18+ required (tested on Node 22). Data is stored in `DATA_DIR` (`app.db`, `uploads/`, `public/`, `lesson-files/`).

## Connect the mobile app

```bash
cd apps/mobile
flutter pub get
flutter run --dart-define=API_URL=http://10.0.2.2:3000            # Android emulator
flutter run --dart-define=API_URL=http://localhost:3000           # iOS simulator / chrome
flutter run --dart-define=API_URL=http://<LAN-IP>:3000            # real phone on the same wifi
flutter build apk --release --dart-define=API_URL=https://your-domain.com
```

Release builds must use **https**. Without `API_URL` the app talks to the old Replit server.

## Deploy

Any Node host works (Render, Railway, Fly.io, a VPS). Set `JWT_SECRET`, `ADMIN_KEY`, `PORT` and mount a **persistent disk** at
`DATA_DIR` (SQLite + uploads live there). A `Dockerfile` is included: `docker build -t edu-api . && docker run -p 3000:3000 -v edu-data:/data -e JWT_SECRET=... -e ADMIN_KEY=... edu-api`.
Put it behind https (the host's proxy is enough). Single instance only (SQLite).

## Back-office API (teacher / assistant)

All requests need the header `X-Admin-Key: <ADMIN_KEY>`. Base: `/api/v1/admin`. JSON bodies unless noted.

| Method & path | Purpose |
|---|---|
| `POST /teachers` `{name}` | create a teacher |
| `POST /courses` `{teacherId,title,description}` / `GET /courses` | create / list courses |
| `POST /lessons` `{courseId,title,position,videoUrl,minSeconds,opensAt?,unlockAfterQuizId?}` | create a lesson (YouTube/Vimeo URL) |
| `POST /lessons/:id/files` multipart `file` (PDF) + `title` | attach a PDF handout |
| `POST /quizzes` `{courseId,title,kind:'quiz'|'homework',maxAttempts?,dueAt?,timeLimitMinutes?,showAnswers?}` | create quiz/homework |
| `POST /quizzes/:id/questions` `{kind:'mcq'|'essay',body,options[],correctIndex,points,position}` | add a question |
| `POST /codes` `{courseId,days,count}` | generate subscription codes |
| `POST /subscriptions` `{userId,courseId,days}` | subscribe a student directly |
| `GET /students` | list students |
| `POST /students/:id/reset-device` | unbind device (fixes `device_locked`) |
| `POST /students/:id/disable` · `/enable` | suspend / reactivate |
| `POST /students/:id/reset-password` `{password}` | set a new password (also marks the forgot-password request handled) |
| `GET /password-requests` | pending "forgot password" requests |
| `GET /submissions?pending=true` | essay submissions waiting for grading |
| `POST /submissions/:id/grade` `{essayScore,feedback}` | grade essay part (student is notified) |
| `POST /announcements` `{title,body,courseId?}` | notify all students (or one course) |

Example:
```bash
H='-H X-Admin-Key:YOUR_KEY -H Content-Type:application/json'
curl $H -X POST localhost:3000/api/v1/admin/teachers -d '{"name":"أ. أحمد"}'
```

## Behaviour notes

- Student account binds to the first device that logs in (`X-Device-Id`); other devices get `403 device_locked`.
- Lessons open in order; a lesson can also wait for `opensAt` or for a submitted quiz (`unlockAfterQuizId`).
  `complete` needs `minSeconds` of watch time measured from heartbeats.
- Quizzes: options/questions are shuffled per session; timed quizzes need `sessionId` and accept a 15 s grace period.
- Push notifications are stored in the app's inbox; this server does not call FCM/APNs.
- Access tokens last 1 h, refresh tokens 60 days (rotated on use). 5 wrong logins lock the account for 5 minutes.
