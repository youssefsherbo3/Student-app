const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(path.join(DATA_DIR, 'uploads'), { recursive: true });
fs.mkdirSync(path.join(DATA_DIR, 'public'), { recursive: true });
fs.mkdirSync(path.join(DATA_DIR, 'lesson-files'), { recursive: true });

const db = new Database(process.env.DB_FILE || path.join(DATA_DIR, 'app.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student',
  phone TEXT UNIQUE,
  email TEXT UNIQUE,
  parent_phone TEXT,
  password_hash TEXT NOT NULL,
  avatar_path TEXT,
  device_id TEXT,
  disabled INTEGER NOT NULL DEFAULT 0,
  failed_logins INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE, device_id TEXT, expires_at INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS teachers (id TEXT PRIMARY KEY, name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS courses (
  id TEXT PRIMARY KEY, teacher_id TEXT REFERENCES teachers(id), title TEXT NOT NULL, description TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS subscriptions (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE, expires_at TEXT NOT NULL,
  UNIQUE(user_id, course_id)
);
CREATE TABLE IF NOT EXISTS codes (
  id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  days INTEGER NOT NULL DEFAULT 180, used_by TEXT, used_at TEXT
);
CREATE TABLE IF NOT EXISTS lessons (
  id TEXT PRIMARY KEY, course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0, video_url TEXT, min_seconds INTEGER NOT NULL DEFAULT 0,
  opens_at TEXT, unlock_after_quiz_id TEXT
);
CREATE TABLE IF NOT EXISTS lesson_files (
  id TEXT PRIMARY KEY, lesson_id TEXT NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  title TEXT NOT NULL, path TEXT NOT NULL, size INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS lesson_progress (
  user_id TEXT NOT NULL, lesson_id TEXT NOT NULL, started_at TEXT, last_ping TEXT, watched_seconds INTEGER NOT NULL DEFAULT 0,
  done INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (user_id, lesson_id)
);
CREATE TABLE IF NOT EXISTS quizzes (
  id TEXT PRIMARY KEY, course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE, title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'quiz', max_attempts INTEGER, due_at TEXT, time_limit_minutes INTEGER,
  show_answers INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS questions (
  id TEXT PRIMARY KEY, quiz_id TEXT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE, kind TEXT NOT NULL DEFAULT 'mcq',
  body TEXT NOT NULL, options TEXT NOT NULL DEFAULT '[]', correct_index INTEGER, points INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0, image_path TEXT
);
CREATE TABLE IF NOT EXISTS quiz_sessions (
  id TEXT PRIMARY KEY, quiz_id TEXT NOT NULL, user_id TEXT NOT NULL, started_at INTEGER NOT NULL, ends_at INTEGER,
  layout TEXT NOT NULL, submitted INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS submissions (
  id TEXT PRIMARY KEY, quiz_id TEXT NOT NULL, user_id TEXT NOT NULL, score INTEGER NOT NULL DEFAULT 0, mcq_total INTEGER NOT NULL DEFAULT 0,
  essay_total INTEGER NOT NULL DEFAULT 0, essay_score INTEGER, feedback TEXT, has_essay INTEGER NOT NULL DEFAULT 0,
  answers TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS uploads (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, kind TEXT NOT NULL, path TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, type TEXT NOT NULL, title TEXT NOT NULL,
  body TEXT NOT NULL, data TEXT NOT NULL DEFAULT '{}', read INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS push_tokens (
  token TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, platform TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS password_requests (
  id TEXT PRIMARY KEY, user_id TEXT, identifier TEXT NOT NULL, created_at TEXT NOT NULL, handled INTEGER NOT NULL DEFAULT 0
);
`);

module.exports = { db, DATA_DIR };
