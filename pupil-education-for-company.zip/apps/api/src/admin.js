// Back-office API protected by the X-Admin-Key header (set ADMIN_KEY in the environment).
const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const { db, DATA_DIR } = require('./db');
const U = require('./util');
const { ApiError, uid, nowIso, wrap } = U;

const a = express.Router();
a.use(U.adminOnly);
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });
const req_ = (v, name) => { if (v === undefined || v === null || v === '') throw new ApiError(400, 'validation_error', `${name} is required`, [{ message: `${name} is required` }]); return v; };

a.post('/teachers', wrap((req, res) => {
  const id = uid(); db.prepare('INSERT INTO teachers (id,name) VALUES (?,?)').run(id, req_(req.body.name, 'name'));
  res.status(201).json({ id, name: req.body.name });
}));
a.post('/courses', wrap((req, res) => {
  const { teacherId, title, description = '' } = req.body;
  req_(title, 'title');
  if (teacherId && !db.prepare('SELECT 1 FROM teachers WHERE id=?').get(teacherId)) throw new ApiError(404, 'teacher_not_found', 'Teacher not found');
  const id = uid(); db.prepare('INSERT INTO courses (id,teacher_id,title,description) VALUES (?,?,?,?)').run(id, teacherId || null, title, description);
  res.status(201).json({ id, title });
}));
a.get('/courses', wrap((_req, res) => res.json(db.prepare('SELECT * FROM courses').all())));
a.post('/lessons', wrap((req, res) => {
  const b = req.body; req_(b.courseId, 'courseId'); req_(b.title, 'title');
  if (!db.prepare('SELECT 1 FROM courses WHERE id=?').get(b.courseId)) throw new ApiError(404, 'course_not_found', 'Course not found');
  const id = uid();
  db.prepare('INSERT INTO lessons (id,course_id,title,position,video_url,min_seconds,opens_at,unlock_after_quiz_id) VALUES (?,?,?,?,?,?,?,?)')
    .run(id, b.courseId, b.title, b.position ?? 0, b.videoUrl || null, b.minSeconds ?? 0, b.opensAt || null, b.unlockAfterQuizId || null);
  res.status(201).json({ id });
}));
a.post('/lessons/:id/files', upload.single('file'), wrap((req, res) => {
  if (!db.prepare('SELECT 1 FROM lessons WHERE id=?').get(req.params.id)) throw new ApiError(404, 'lesson_not_found', 'Lesson not found');
  if (!req.file || req.file.buffer.slice(0, 4).toString() !== '%PDF') throw new ApiError(400, 'validation_error', 'A PDF file is required', [{ message: 'PDF file required' }]);
  const id = uid(); const file = `${id}.pdf`;
  fs.writeFileSync(path.join(DATA_DIR, 'lesson-files', file), req.file.buffer);
  db.prepare('INSERT INTO lesson_files (id,lesson_id,title,path,size) VALUES (?,?,?,?,?)').run(id, req.params.id, req.body.title || req.file.originalname, file, req.file.size);
  res.status(201).json({ id });
}));
a.post('/quizzes', wrap((req, res) => {
  const b = req.body; req_(b.courseId, 'courseId'); req_(b.title, 'title');
  const id = uid();
  db.prepare('INSERT INTO quizzes (id,course_id,title,kind,max_attempts,due_at,time_limit_minutes,show_answers) VALUES (?,?,?,?,?,?,?,?)')
    .run(id, b.courseId, b.title, b.kind === 'homework' ? 'homework' : 'quiz', b.maxAttempts ?? null, b.dueAt || null, b.timeLimitMinutes ?? null, b.showAnswers === false ? 0 : 1);
  res.status(201).json({ id });
}));
a.post('/quizzes/:id/questions', wrap((req, res) => {
  const b = req.body; req_(b.body, 'body');
  if (!db.prepare('SELECT 1 FROM quizzes WHERE id=?').get(req.params.id)) throw new ApiError(404, 'quiz_not_found', 'Quiz not found');
  const kind = b.kind === 'essay' ? 'essay' : 'mcq';
  if (kind === 'mcq' && (!Array.isArray(b.options) || b.options.length < 2 || !Number.isInteger(b.correctIndex) || b.correctIndex < 0 || b.correctIndex >= b.options.length))
    throw new ApiError(400, 'validation_error', 'mcq needs options[] (2+) and a valid correctIndex', [{ message: 'mcq needs options[] and correctIndex' }]);
  const id = uid();
  db.prepare('INSERT INTO questions (id,quiz_id,kind,body,options,correct_index,points,position) VALUES (?,?,?,?,?,?,?,?)')
    .run(id, req.params.id, kind, b.body, JSON.stringify(kind === 'mcq' ? b.options : []), kind === 'mcq' ? b.correctIndex : null, b.points ?? 1, b.position ?? 0);
  res.status(201).json({ id });
}));
a.post('/codes', wrap((req, res) => {
  const { courseId, days = 180, count = 1 } = req.body; req_(courseId, 'courseId');
  if (!db.prepare('SELECT 1 FROM courses WHERE id=?').get(courseId)) throw new ApiError(404, 'course_not_found', 'Course not found');
  const codes = [];
  for (let i = 0; i < Math.min(500, count); i++) {
    const code = crypto.randomBytes(5).toString('hex').toUpperCase();
    db.prepare('INSERT INTO codes (id,code,course_id,days) VALUES (?,?,?,?)').run(uid(), code, courseId, days); codes.push(code);
  }
  res.status(201).json({ codes });
}));
a.post('/subscriptions', wrap((req, res) => {
  const { userId, courseId, days = 180 } = req.body; req_(userId, 'userId'); req_(courseId, 'courseId');
  const exp = new Date(Date.now() + days * 86400000).toISOString();
  db.prepare('INSERT INTO subscriptions (id,user_id,course_id,expires_at) VALUES (?,?,?,?) ON CONFLICT(user_id,course_id) DO UPDATE SET expires_at=excluded.expires_at').run(uid(), userId, courseId, exp);
  res.status(201).json({ expiresAt: exp });
}));
a.get('/students', wrap((_req, res) => res.json(db.prepare("SELECT id,name,phone,email,parent_phone,device_id IS NOT NULL deviceBound,disabled,created_at FROM users WHERE role='student' ORDER BY created_at DESC").all())));
a.post('/students/:id/reset-device', wrap((req, res) => { db.prepare('UPDATE users SET device_id=NULL WHERE id=?').run(req.params.id); db.prepare('UPDATE refresh_tokens SET revoked=1 WHERE user_id=?').run(req.params.id); res.status(204).end(); }));
a.post('/students/:id/disable', wrap((req, res) => { db.prepare('UPDATE users SET disabled=1 WHERE id=?').run(req.params.id); res.status(204).end(); }));
a.post('/students/:id/enable', wrap((req, res) => { db.prepare('UPDATE users SET disabled=0 WHERE id=?').run(req.params.id); res.status(204).end(); }));
a.post('/students/:id/reset-password', wrap((req, res) => {
  const pw = req_(req.body.password, 'password'); if (String(pw).length < 6) throw new ApiError(400, 'validation_error', 'min 6 chars', [{ message: 'min 6 chars' }]);
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(String(pw), 10), req.params.id);
  db.prepare('UPDATE refresh_tokens SET revoked=1 WHERE user_id=?').run(req.params.id);
  db.prepare('UPDATE password_requests SET handled=1 WHERE user_id=?').run(req.params.id);
  res.status(204).end();
}));
a.get('/password-requests', wrap((_req, res) => res.json(db.prepare('SELECT * FROM password_requests WHERE handled=0 ORDER BY created_at DESC').all())));
a.get('/submissions', wrap((req, res) => {
  const pending = req.query.pending === 'true' ? ' AND s.has_essay=1 AND s.essay_score IS NULL' : '';
  res.json(db.prepare(`SELECT s.id, s.quiz_id, q.title quiz, u.name student, s.score, s.essay_score, s.created_at FROM submissions s
    JOIN users u ON u.id=s.user_id JOIN quizzes q ON q.id=s.quiz_id WHERE 1=1${pending} ORDER BY s.created_at DESC LIMIT 200`).all());
}));
a.post('/submissions/:id/grade', wrap((req, res) => {
  const s = db.prepare('SELECT s.*, q.title qt FROM submissions s JOIN quizzes q ON q.id=s.quiz_id WHERE s.id=?').get(req.params.id);
  if (!s) throw new ApiError(404, 'submission_not_found', 'Submission not found');
  const { essayScore, feedback = null } = req.body;
  if (!Number.isInteger(essayScore) || essayScore < 0 || essayScore > s.essay_total) throw new ApiError(400, 'validation_error', `essayScore must be 0..${s.essay_total}`, [{ message: `essayScore must be 0..${s.essay_total}` }]);
  db.prepare('UPDATE submissions SET essay_score=?, feedback=? WHERE id=?').run(essayScore, feedback, s.id);
  U.notify(s.user_id, 'grade', 'تم تصحيح إجابتك', `تم تصحيح ${s.qt}.`, { submissionId: s.id });
  res.status(204).end();
}));
a.post('/announcements', wrap((req, res) => {
  const { title, body, courseId } = req.body; req_(title, 'title'); req_(body, 'body');
  const users = courseId
    ? db.prepare('SELECT DISTINCT user_id id FROM subscriptions WHERE course_id=? AND expires_at > ?').all(courseId, nowIso())
    : db.prepare("SELECT id FROM users WHERE role='student'").all();
  db.transaction(() => users.forEach((u) => U.notify(u.id, 'announcement', title, body)))();
  res.status(201).json({ sent: users.length });
}));

module.exports = a;
