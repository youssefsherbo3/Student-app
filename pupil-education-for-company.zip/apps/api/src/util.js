const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { db } = require('./db');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const ADMIN_KEY = process.env.ADMIN_KEY || 'change-me-admin-key';
if (!process.env.JWT_SECRET) console.warn('[warn] JWT_SECRET not set – using an insecure development secret.');
if (!process.env.ADMIN_KEY) console.warn('[warn] ADMIN_KEY not set – using the default admin key "change-me-admin-key".');

class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message || code);
    this.status = status; this.code = code; this.details = details || [];
  }
}
const uid = () => crypto.randomUUID();
const nowIso = () => new Date().toISOString();
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const wrap = (fn) => (req, res, next) => Promise.resolve().then(() => fn(req, res, next)).catch(next);

const signAccess = (userId) => jwt.sign({ sub: userId, typ: 'access' }, JWT_SECRET, { expiresIn: '1h' });

function userJson(u) {
  return {
    id: u.id, name: u.name, role: u.role, email: u.email, phone: u.phone, parentPhone: u.parent_phone,
    avatarUrl: u.avatar_path ? `/files/public/${u.avatar_path}` : null,
    deviceBound: !!u.device_id,
  };
}

function notify(userId, type, title, body, data = {}) {
  db.prepare('INSERT INTO notifications (id,user_id,type,title,body,data,read,created_at) VALUES (?,?,?,?,?,?,0,?)')
    .run(uid(), userId, type, title, body, JSON.stringify(data), nowIso());
}

function auth(req, _res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return next(new ApiError(401, 'unauthorized', 'Missing token'));
  let payload;
  try { payload = jwt.verify(token, JWT_SECRET); } catch { return next(new ApiError(401, 'invalid_token', 'Invalid or expired token')); }
  if (payload.typ !== 'access') return next(new ApiError(401, 'invalid_token', 'Invalid token'));
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(payload.sub);
  if (!u) return next(new ApiError(401, 'invalid_token', 'Unknown user'));
  if (u.disabled) return next(new ApiError(403, 'account_disabled', 'Account disabled'));
  const dev = req.headers['x-device-id'];
  if (u.role === 'student' && u.device_id && dev && dev !== u.device_id) return next(new ApiError(403, 'device_locked', 'Account is bound to another device'));
  req.user = u;
  next();
}

function adminOnly(req, _res, next) {
  const k = req.headers['x-admin-key'];
  if (!k || k.length !== ADMIN_KEY.length || !crypto.timingSafeEqual(Buffer.from(k), Buffer.from(ADMIN_KEY))) {
    return next(new ApiError(401, 'unauthorized', 'Bad admin key'));
  }
  next();
}

function activeSub(userId, courseId) {
  return db.prepare('SELECT * FROM subscriptions WHERE user_id=? AND course_id=? AND expires_at > ?').get(userId, courseId, nowIso());
}
function requireEnrolled(userId, courseId) {
  const c = db.prepare('SELECT id FROM courses WHERE id=?').get(courseId);
  if (!c) throw new ApiError(404, 'course_not_found', 'Course not found');
  if (!activeSub(userId, courseId)) throw new ApiError(403, 'not_enrolled', 'Not enrolled');
}

function sniffImage(buf) {
  if (buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return ['image/png', 'png'];
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return ['image/jpeg', 'jpg'];
  if (buf.length > 12 && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return ['image/webp', 'webp'];
  return null;
}

module.exports = { ApiError, uid, nowIso, sha, wrap, signAccess, userJson, notify, auth, adminOnly, activeSub, requireEnrolled, sniffImage, JWT_SECRET };
