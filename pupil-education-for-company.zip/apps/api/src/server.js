const express = require('express');
const cors = require('cors');
const path = require('path');
const { DATA_DIR } = require('./db');
const { ApiError } = require('./util');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(cors({ origin: true, allowedHeaders: ['Content-Type', 'Authorization', 'X-Device-Id', 'X-Admin-Key'] }));
app.use(express.json({ limit: '1mb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));
app.get('/', (_req, res) => res.json({ name: 'edu-api', api: '/api/v1', health: '/health' }));
app.use('/files/public', express.static(path.join(DATA_DIR, 'public'), { maxAge: '1h' }));
app.use('/api/v1/admin', require('./admin'));
app.use('/api/v1', require('./student'));

app.use((_req, _res, next) => next(new ApiError(404, 'not_found', 'Route not found')));
app.use((err, _req, res, _next) => {
  if (err && err.code === 'LIMIT_FILE_SIZE') err = new ApiError(413, 'file_too_large', 'حجم الملف كبير.');
  if (err && err.type === 'entity.parse.failed') err = new ApiError(400, 'validation_error', 'Invalid JSON');
  if (!(err instanceof ApiError)) { console.error(err); err = new ApiError(500, 'internal_error', 'Internal error'); }
  res.status(err.status).json({ error: { code: err.code, message: err.message, details: err.details } });
});

const PORT = process.env.PORT || 3000;
if (require.main === module) app.listen(PORT, '0.0.0.0', () => console.log(`API listening on 0.0.0.0:${PORT}`));
module.exports = app;
