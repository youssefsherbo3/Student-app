const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { db, DATA_DIR } = require('./db');
const U = require('./util');
const { ApiError, uid, nowIso, sha, wrap, auth } = U;

const r = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

// ---------- auth ----------
function issueTokens(user, deviceId) {
  const refresh = crypto.randomBytes(48).toString('hex');
  db.prepare('INSERT INTO refresh_tokens (id,user_id,token_hash,device_id,expires_at) VALUES (?,?,?,?,?)')
    .run(uid(), user.id, sha(refresh), deviceId || null, Date.now() + 60 * 24 * 3600 * 1000);
  return { accessToken: U.signAccess(user.id), refreshToken: refresh };
}
const need = (cond, msg) => { if (!cond) throw new ApiError(400, 'validation_error', msg, [{ message: msg }]); };
const normPhone = (p) => (p || '').replace(/[\s-]/g, '');

r.post('/auth/register', wrap((req, res) => {
  const { name, password, deviceId } = req.body || {};
  const phone = normPhone(req.body.phone) || null;
  const email = (req.body.email || '').trim().toLowerCase() || null;
  need(typeof name === 'string' && name.trim().length >= 2, 'الاسم لازم يكون حرفين على الأقل.');
  need(typeof password === 'string' && password.length >= 6, 'كلمة السر لازم تكون 6 حروف على الأقل.');
  need(phone || email, 'اكتب رقم الموبايل أو الإيميل.');
  need(!email || /^\S+@\S+\.\S+$/.test(email), 'الإيميل غير صحيح.');
  if ((phone && db.prepare('SELECT 1 FROM users WHERE phone=?').get(phone)) || (email && db.prepare('SELECT 1 FROM users WHERE email=?').get(email))) {
    throw new ApiError(409, 'already_exists', 'الرقم أو الإيميل مسجّل قبل كده.');
  }
  const id = uid();
  db.prepare('INSERT INTO users (id,name,role,phone,email,parent_phone,password_hash,device_id,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(id, name.trim(), 'student', phone, email, normPhone(req.body.parentPhone) || null, bcrypt.hashSync(password, 10), deviceId || null, nowIso());
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  res.status(201).json({ ...issueTokens(user, deviceId), user: U.userJson(user) });
}));

r.post('/auth/login', wrap((req, res) => {
  const { identifier, password, deviceId } = req.body || {};
  need(identifier && password, 'اكتب بيانات الدخول.');
  const idf = String(identifier).trim();
  const u = db.prepare('SELECT * FROM users WHERE phone=? OR email=?').get(normPhone(idf), idf.toLowerCase());
  if (u && u.locked_until > Date.now()) throw new ApiError(429, 'too_many_attempts', 'محاولات كتير غلط.');
  if (!u || !bcrypt.compareSync(String(password), u.password_hash)) {
    if (u) {
      const f = u.failed_logins + 1;
      db.prepare('UPDATE users SET failed_logins=?, locked_until=? WHERE id=?').run(f >= 5 ? 0 : f, f >= 5 ? Date.now() + 5 * 60 * 1000 : 0, u.id);
    }
    throw new ApiError(401, 'invalid_credentials', 'Invalid credentials');
  }
  if (u.disabled) throw new ApiError(403, 'account_disabled', 'Account disabled');
  if (u.role === 'student') {
    if (u.device_id && deviceId && u.device_id !== deviceId) throw new ApiError(403, 'device_locked', 'Account is bound to another device');
    if (!u.device_id && deviceId) db.prepare('UPDATE users SET device_id=? WHERE id=?').run(deviceId, u.id);
  }
  db.prepare('UPDATE users SET failed_logins=0, locked_until=0 WHERE id=?').run(u.id);
  const fresh = db.prepare('SELECT * FROM users WHERE id=?').get(u.id);
  res.json({ ...issueTokens(fresh, deviceId), user: U.userJson(fresh) });
}));

r.post('/auth/refresh', wrap((req, res) => {
  const { refreshToken, deviceId } = req.body || {};
  const row = refreshToken && db.prepare('SELECT * FROM refresh_tokens WHERE token_hash=?').get(sha(String(refreshToken)));
  if (!row || row.revoked || row.expires_at < Date.now()) throw new ApiError(401, 'invalid_token', 'Invalid refresh token');
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(row.user_id);
  if (!u || u.disabled) throw new ApiError(401, 'invalid_token', 'Invalid refresh token');
  if (u.role === 'student' && u.device_id && deviceId && u.device_id !== deviceId) throw new ApiError(403, 'device_locked', 'Bound to another device');
  db.prepare('UPDATE refresh_tokens SET revoked=1 WHERE id=?').run(row.id);
  res.json(issueTokens(u, deviceId));
}));

r.post('/auth/logout', wrap((req, res) => {
  const { refreshToken } = req.body || {};
  if (refreshToken) db.prepare('UPDATE refresh_tokens SET revoked=1 WHERE token_hash=?').run(sha(String(refreshToken)));
  res.status(204).end();
}));

r.post('/auth/forgot-password', wrap((req, res) => {
  const idf = String((req.body || {}).identifier || '').trim();
  if (idf) {
    const u = db.prepare('SELECT id FROM users WHERE phone=? OR email=?').get(normPhone(idf), idf.toLowerCase());
    db.prepare('INSERT INTO password_requests (id,user_id,identifier,created_at) VALUES (?,?,?,?)').run(uid(), u ? u.id : null, idf, nowIso());
  }
  res.status(204).end();
}));

r.get('/auth/me', auth, wrap((req, res) => res.json(U.userJson(req.user))));

r.patch('/auth/me', auth, wrap((req, res) => {
  const { name, avatarUploadId } = req.body || {};
  if (name !== undefined) {
    need(typeof name === 'string' && name.trim().length >= 2, 'الاسم لازم يكون حرفين على الأقل.');
    db.prepare('UPDATE users SET name=? WHERE id=?').run(name.trim(), req.user.id);
  }
  if (avatarUploadId) {
    const up = db.prepare('SELECT * FROM uploads WHERE id=? AND user_id=? AND kind=?').get(avatarUploadId, req.user.id, 'avatar');
    if (!up) throw new ApiError(404, 'upload_not_found', 'Upload not found');
    const file = `${req.user.id}-${Date.now()}${path.extname(up.path)}`;
    fs.copyFileSync(path.join(DATA_DIR, 'uploads', up.path), path.join(DATA_DIR, 'public', file));
    db.prepare('UPDATE users SET avatar_path=? WHERE id=?').run(file, req.user.id);
  }
  res.json(U.userJson(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)));
}));

r.post('/auth/change-password', auth, wrap((req, res) => {
  const { current, next } = req.body || {};
  need(typeof next === 'string' && next.length >= 6, 'كلمة السر الجديدة لازم تكون 6 حروف على الأقل.');
  if (!bcrypt.compareSync(String(current || ''), req.user.password_hash)) throw new ApiError(400, 'invalid_credentials', 'Wrong current password');
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(next, 10), req.user.id);
  res.status(204).end();
}));

// ---------- courses ----------
r.get('/courses', auth, wrap((req, res) => {
  const rows = db.prepare(`SELECT c.id,c.title,c.description,c.teacher_id,t.name teacher_name,s.expires_at
    FROM subscriptions s JOIN courses c ON c.id=s.course_id LEFT JOIN teachers t ON t.id=c.teacher_id
    WHERE s.user_id=? AND s.expires_at > ? ORDER BY t.name, c.title`).all(req.user.id, nowIso());
  res.json(rows.map((c) => ({ id: c.id, title: c.title, description: c.description, teacherId: c.teacher_id, teacherName: c.teacher_name || '', expiresAt: c.expires_at })));
}));

function bestPercentByUser(courseId) {
  const rows = db.prepare(`SELECT s.user_id, s.quiz_id, MAX(CAST(s.score + COALESCE(s.essay_score,0) AS REAL) / NULLIF(s.mcq_total + s.essay_total,0)) p
    FROM submissions s JOIN quizzes q ON q.id=s.quiz_id WHERE q.course_id=? GROUP BY s.user_id, s.quiz_id`).all(courseId);
  const m = new Map();
  for (const x of rows) { const a = m.get(x.user_id) || []; a.push(x.p || 0); m.set(x.user_id, a); }
  return [...m.entries()].map(([uidv, a]) => ({ uid: uidv, pct: (a.reduce((s, v) => s + v, 0) / a.length) * 100 })).sort((a, b) => b.pct - a.pct);
}
r.get('/courses/:id/my-rank', auth, wrap((req, res) => {
  U.requireEnrolled(req.user.id, req.params.id);
  const list = bestPercentByUser(req.params.id);
  const idx = list.findIndex((x) => x.uid === req.user.id);
  if (idx < 0) return res.json({ rank: null, of: list.length, percent: 0 });
  res.json({ rank: idx + 1, of: list.length, percent: Math.round(list[idx].pct) });
}));

// ---------- lessons ----------
function lessonState(userId, courseId) {
  const lessons = db.prepare('SELECT * FROM lessons WHERE course_id=? ORDER BY position, rowid').all(courseId);
  const prog = new Map(db.prepare('SELECT * FROM lesson_progress WHERE user_id=?').all(userId).map((p) => [p.lesson_id, p]));
  const out = []; let prevDone = true;
  for (const l of lessons) {
    const p = prog.get(l.id);
    const done = !!(p && p.done);
    let assessmentLocked = false, quizTitle = null;
    if (l.unlock_after_quiz_id) {
      const q = db.prepare('SELECT title FROM quizzes WHERE id=?').get(l.unlock_after_quiz_id);
      quizTitle = q ? q.title : null;
      assessmentLocked = !db.prepare('SELECT 1 FROM submissions WHERE quiz_id=? AND user_id=?').get(l.unlock_after_quiz_id, userId);
    }
    const early = l.opens_at && l.opens_at > nowIso();
    const locked = !!(early || !prevDone || assessmentLocked);
    out.push({ l, p, done, locked, assessmentLocked, quizTitle });
    prevDone = done;
  }
  return out;
}
r.get('/courses/:id/lessons', auth, wrap((req, res) => {
  U.requireEnrolled(req.user.id, req.params.id);
  res.json(lessonState(req.user.id, req.params.id).map(({ l, done, locked, assessmentLocked, quizTitle }) => ({
    id: l.id, title: l.title, position: l.position, opensAt: l.opens_at, locked, done, minSeconds: l.min_seconds,
    unlockAfterQuizId: l.unlock_after_quiz_id, unlockAfterQuizTitle: quizTitle, assessmentLocked,
    videoUrl: locked ? null : l.video_url,
    files: locked ? [] : db.prepare('SELECT id,title,size FROM lesson_files WHERE lesson_id=?').all(l.id),
  })));
}));

function loadLesson(req) {
  const l = db.prepare('SELECT * FROM lessons WHERE id=?').get(req.params.id);
  if (!l) throw new ApiError(404, 'lesson_not_found', 'Lesson not found');
  U.requireEnrolled(req.user.id, l.course_id);
  const st = lessonState(req.user.id, l.course_id).find((x) => x.l.id === l.id);
  if (st.locked) throw new ApiError(403, 'locked_lesson', 'Lesson is locked');
  return { l, st };
}
const effectiveWatched = (p) => {
  if (!p || !p.started_at) return 0;
  const since = Math.min(45, Math.max(0, (Date.now() - new Date(p.last_ping).getTime()) / 1000));
  return p.watched_seconds + since;
};
r.post('/lessons/:id/start', auth, wrap((req, res) => {
  const { l, st } = loadLesson(req);
  if (!st.p) db.prepare('INSERT INTO lesson_progress (user_id,lesson_id,started_at,last_ping) VALUES (?,?,?,?)').run(req.user.id, l.id, nowIso(), nowIso());
  else db.prepare('UPDATE lesson_progress SET started_at=COALESCE(started_at,?), last_ping=? WHERE user_id=? AND lesson_id=?').run(nowIso(), nowIso(), req.user.id, l.id);
  const p = db.prepare('SELECT * FROM lesson_progress WHERE user_id=? AND lesson_id=?').get(req.user.id, l.id);
  res.json({ remainingSeconds: Math.max(0, Math.ceil(l.min_seconds - p.watched_seconds)), startedAt: p.started_at });
}));
r.post('/lessons/:id/heartbeat', auth, wrap((req, res) => {
  const { l } = loadLesson(req);
  const p = db.prepare('SELECT * FROM lesson_progress WHERE user_id=? AND lesson_id=?').get(req.user.id, l.id);
  if (!p || !p.started_at) throw new ApiError(409, 'not_started', 'Lesson not started');
  const delta = Math.min(45, Math.max(0, (Date.now() - new Date(p.last_ping).getTime()) / 1000));
  const w = p.watched_seconds + Math.round(delta);
  db.prepare('UPDATE lesson_progress SET watched_seconds=?, last_ping=? WHERE user_id=? AND lesson_id=?').run(w, nowIso(), req.user.id, l.id);
  res.json({ remainingSeconds: Math.max(0, l.min_seconds - w) });
}));
r.post('/lessons/:id/complete', auth, wrap((req, res) => {
  const { l, st } = loadLesson(req);
  if (effectiveWatched(st.p) + 2 < l.min_seconds) throw new ApiError(409, 'too_early', 'Minimum watch time not reached');
  db.prepare(`INSERT INTO lesson_progress (user_id,lesson_id,started_at,last_ping,done) VALUES (?,?,?,?,1)
    ON CONFLICT(user_id,lesson_id) DO UPDATE SET done=1`).run(req.user.id, l.id, nowIso(), nowIso());
  res.json({ done: true });
}));
r.get('/lesson-files/:id', auth, wrap((req, res) => {
  const f = db.prepare('SELECT f.*, l.course_id FROM lesson_files f JOIN lessons l ON l.id=f.lesson_id WHERE f.id=?').get(req.params.id);
  if (!f) throw new ApiError(404, 'file_not_found', 'File not found');
  U.requireEnrolled(req.user.id, f.course_id);
  res.type('application/pdf').sendFile(path.join(DATA_DIR, 'lesson-files', f.path));
}));

// ---------- quizzes ----------
const imgUrl = (p) => (p ? `/files/public/${p}` : null);
const shuffle = (a) => { const b = a.slice(); for (let i = b.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [b[i], b[j]] = [b[j], b[i]]; } return b; };
const isClosed = (q) => !!(q.due_at && q.due_at < nowIso());
function loadQuiz(req) {
  const q = db.prepare('SELECT * FROM quizzes WHERE id=?').get(req.params.id);
  if (!q) throw new ApiError(404, 'quiz_not_found', 'Quiz not found');
  U.requireEnrolled(req.user.id, q.course_id);
  return q;
}
const attemptsUsed = (quizId, userId) => db.prepare('SELECT COUNT(*) c FROM submissions WHERE quiz_id=? AND user_id=?').get(quizId, userId).c;

r.get('/courses/:id/quizzes', auth, wrap((req, res) => {
  U.requireEnrolled(req.user.id, req.params.id);
  res.json(db.prepare('SELECT * FROM quizzes WHERE course_id=? ORDER BY rowid').all(req.params.id).map((q) => ({
    id: q.id, title: q.title, kind: q.kind, maxAttempts: q.max_attempts, dueAt: q.due_at,
    attemptsUsed: attemptsUsed(q.id, req.user.id), closed: isClosed(q), timeLimitMinutes: q.time_limit_minutes,
  })));
}));

r.get('/quizzes/:id/questions', auth, wrap((req, res) => {
  const q = loadQuiz(req);
  if (q.time_limit_minutes) throw new ApiError(409, 'not_started', 'Timed quiz must be started');
  res.json(db.prepare('SELECT * FROM questions WHERE quiz_id=? ORDER BY position, rowid').all(q.id).map((x) => ({
    id: x.id, body: x.body, kind: x.kind, options: JSON.parse(x.options), points: x.points, position: x.position, imageUrl: imgUrl(x.image_path),
  })));
}));

r.post('/quizzes/:id/start', auth, wrap((req, res) => {
  const q = loadQuiz(req);
  if (isClosed(q)) throw new ApiError(403, 'closed', 'Closed');
  if (q.max_attempts != null && attemptsUsed(q.id, req.user.id) >= q.max_attempts) throw new ApiError(403, 'no_attempts_left', 'No attempts left');
  const timed = !!q.time_limit_minutes;
  let s = db.prepare('SELECT * FROM quiz_sessions WHERE quiz_id=? AND user_id=? AND submitted=0 ORDER BY started_at DESC').get(q.id, req.user.id);
  if (s && timed && s.ends_at && s.ends_at < Date.now()) s = null;
  const qs = db.prepare('SELECT * FROM questions WHERE quiz_id=? ORDER BY position, rowid').all(q.id);
  if (!s) {
    const order = shuffle(qs.map((x) => x.id));
    const layout = {};
    for (const x of qs) layout[x.id] = x.kind === 'mcq' ? shuffle(JSON.parse(x.options).map((_, i) => i)) : null;
    const id = uid(); const started = Date.now();
    db.prepare('INSERT INTO quiz_sessions (id,quiz_id,user_id,started_at,ends_at,layout) VALUES (?,?,?,?,?,?)')
      .run(id, q.id, req.user.id, started, timed ? started + q.time_limit_minutes * 60000 : null, JSON.stringify({ order, perms: layout }));
    s = db.prepare('SELECT * FROM quiz_sessions WHERE id=?').get(id);
  }
  const layout = JSON.parse(s.layout); const byId = new Map(qs.map((x) => [x.id, x]));
  const questions = layout.order.filter((id) => byId.has(id)).map((id, pos) => {
    const x = byId.get(id); const opts = JSON.parse(x.options); const perm = layout.perms[id];
    return { id: x.id, body: x.body, kind: x.kind, options: perm ? perm.map((i) => opts[i]) : opts, points: x.points, position: pos, imageUrl: imgUrl(x.image_path) };
  });
  res.json({ sessionId: timed ? s.id : null, endsAt: timed ? new Date(s.ends_at).toISOString() : null, serverNow: nowIso(), questions });
}));

r.post('/quizzes/:id/submit', auth, wrap((req, res) => {
  const q = loadQuiz(req);
  const { answers = {}, sessionId, images = {} } = req.body || {};
  if (isClosed(q)) throw new ApiError(403, 'closed', 'Closed');
  if (q.max_attempts != null && attemptsUsed(q.id, req.user.id) >= q.max_attempts) throw new ApiError(403, 'no_attempts_left', 'No attempts left');
  const timed = !!q.time_limit_minutes;
  if (timed && !sessionId) throw new ApiError(409, 'session_required', 'Session required');
  let s = sessionId
    ? db.prepare('SELECT * FROM quiz_sessions WHERE id=? AND quiz_id=? AND user_id=? AND submitted=0').get(sessionId, q.id, req.user.id)
    : db.prepare('SELECT * FROM quiz_sessions WHERE quiz_id=? AND user_id=? AND submitted=0 ORDER BY started_at DESC').get(q.id, req.user.id);
  if (!s) throw new ApiError(409, 'no_session', 'No session');
  if (timed && s.ends_at && Date.now() > s.ends_at + 15000) throw new ApiError(409, 'time_over', 'Time is over');
  const perms = JSON.parse(s.layout).perms;
  const qs = db.prepare('SELECT * FROM questions WHERE quiz_id=? ORDER BY position, rowid').all(q.id);
  let score = 0, mcqTotal = 0, essayTotal = 0, hasEssay = false; const stored = [];
  for (const x of qs) {
    const a = answers[x.id];
    if (x.kind === 'mcq') {
      mcqTotal += x.points;
      let orig = null;
      if (Number.isInteger(a) && perms[x.id] && a >= 0 && a < perms[x.id].length) orig = perms[x.id][a];
      if (orig !== null && orig === x.correct_index) score += x.points;
      stored.push({ questionId: x.id, answer: orig === null ? null : String(orig) });
    } else {
      essayTotal += x.points; hasEssay = true;
      const ids = Array.isArray(images[x.id]) ? images[x.id].map(String) : [];
      for (const id of ids) if (!db.prepare('SELECT 1 FROM uploads WHERE id=? AND user_id=?').get(id, req.user.id)) throw new ApiError(404, 'upload_not_found', 'Upload not found');
      stored.push({ questionId: x.id, answer: typeof a === 'string' ? a : '', images: ids });
    }
  }
  const id = uid();
  db.prepare('INSERT INTO submissions (id,quiz_id,user_id,score,mcq_total,essay_total,has_essay,answers,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(id, q.id, req.user.id, score, mcqTotal, essayTotal, hasEssay ? 1 : 0, JSON.stringify(stored), nowIso());
  db.prepare('UPDATE quiz_sessions SET submitted=1 WHERE id=?').run(s.id);
  res.status(201).json({ id, score, mcqTotal, hasEssay });
}));

r.get('/quizzes/:id/attempts', auth, wrap((req, res) => {
  const q = loadQuiz(req);
  res.json(db.prepare('SELECT * FROM submissions WHERE quiz_id=? AND user_id=? ORDER BY created_at DESC').all(q.id, req.user.id)
    .map((s) => ({ id: s.id, score: s.score, essayScore: s.essay_score, feedback: s.feedback, createdAt: s.created_at })));
}));

r.get('/submissions/:id', auth, wrap((req, res) => {
  const s = db.prepare('SELECT * FROM submissions WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
  if (!s) throw new ApiError(404, 'submission_not_found', 'Submission not found');
  const q = db.prepare('SELECT * FROM quizzes WHERE id=?').get(s.quiz_id);
  const visible = !!q.show_answers;
  const ans = new Map(JSON.parse(s.answers).map((a) => [a.questionId, a]));
  const items = db.prepare('SELECT * FROM questions WHERE quiz_id=? ORDER BY position, rowid').all(s.quiz_id).map((x) => {
    const a = ans.get(x.id) || {};
    return { questionId: x.id, kind: x.kind, body: x.body, options: JSON.parse(x.options), points: x.points, yourAnswer: a.answer ?? null,
      correctIndex: visible && x.kind === 'mcq' ? x.correct_index : null, imageUrl: imgUrl(x.image_path), yourImages: a.images || [] };
  });
  res.json({ score: s.score, mcqTotal: s.mcq_total, essayScore: s.essay_score, essayTotal: s.essay_total,
    essayPending: !!s.has_essay && s.essay_score == null, feedback: s.feedback, answersVisible: visible, items });
}));

// ---------- uploads ----------
r.post('/uploads', auth, upload.single('file'), wrap((req, res) => {
  const kind = req.query.kind;
  if (kind !== 'answer' && kind !== 'avatar') throw new ApiError(400, 'validation_error', 'kind must be answer or avatar', [{ message: 'نوع الرفع غير صحيح.' }]);
  if (!req.file) throw new ApiError(400, 'validation_error', 'file required', [{ message: 'مفيش ملف.' }]);
  const t = U.sniffImage(req.file.buffer);
  if (!t) throw new ApiError(400, 'invalid_image', 'الملف لازم يكون صورة PNG أو JPG أو WEBP.');
  const id = uid(); const file = `${id}.${t[1]}`;
  fs.writeFileSync(path.join(DATA_DIR, 'uploads', file), req.file.buffer);
  db.prepare('INSERT INTO uploads (id,user_id,kind,path,mime,size) VALUES (?,?,?,?,?,?)').run(id, req.user.id, kind, file, t[0], req.file.size);
  res.status(201).json({ id, url: null });
}));
r.get('/uploads/:id', auth, wrap((req, res) => {
  const u = db.prepare('SELECT * FROM uploads WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
  if (!u) throw new ApiError(404, 'upload_not_found', 'Upload not found');
  res.type(u.mime).sendFile(path.join(DATA_DIR, 'uploads', u.path));
}));

// ---------- codes / notifications / push ----------
r.post('/codes/redeem', auth, wrap((req, res) => {
  const code = String((req.body || {}).code || '').trim().toUpperCase();
  const c = code && db.prepare('SELECT * FROM codes WHERE code=? AND used_by IS NULL').get(code);
  if (!c) throw new ApiError(400, 'invalid_code', 'Invalid code');
  const cur = db.prepare('SELECT * FROM subscriptions WHERE user_id=? AND course_id=?').get(req.user.id, c.course_id);
  const base = cur && cur.expires_at > nowIso() ? new Date(cur.expires_at).getTime() : Date.now();
  const exp = new Date(base + c.days * 86400000).toISOString();
  db.transaction(() => {
    if (cur) db.prepare('UPDATE subscriptions SET expires_at=? WHERE id=?').run(exp, cur.id);
    else db.prepare('INSERT INTO subscriptions (id,user_id,course_id,expires_at) VALUES (?,?,?,?)').run(uid(), req.user.id, c.course_id, exp);
    db.prepare('UPDATE codes SET used_by=?, used_at=? WHERE id=?').run(req.user.id, nowIso(), c.id);
  })();
  const course = db.prepare('SELECT title FROM courses WHERE id=?').get(c.course_id);
  U.notify(req.user.id, 'subscription', 'تم تفعيل الاشتراك', `تم تفعيل كورس ${course.title}.`, { courseId: c.course_id });
  res.json({ courseId: c.course_id, expiresAt: exp });
}));

const notifJson = (n) => ({ id: n.id, type: n.type, title: n.title, body: n.body, data: JSON.parse(n.data), read: !!n.read, createdAt: n.created_at });
r.get('/notifications', auth, wrap((req, res) => {
  const size = Math.min(100, parseInt(req.query.pageSize, 10) || 50);
  const unread = req.query.unreadOnly === 'true' ? ' AND read=0' : '';
  res.json(db.prepare(`SELECT * FROM notifications WHERE user_id=?${unread} ORDER BY created_at DESC LIMIT ?`).all(req.user.id, size).map(notifJson));
}));
r.get('/notifications/unread-count', auth, wrap((req, res) =>
  res.json({ count: db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND read=0').get(req.user.id).c })));
r.post('/notifications/read-all', auth, wrap((req, res) => { db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(req.user.id); res.status(204).end(); }));
r.post('/notifications/:id/read', auth, wrap((req, res) => { db.prepare('UPDATE notifications SET read=1 WHERE id=? AND user_id=?').run(req.params.id, req.user.id); res.status(204).end(); }));
r.post('/push-tokens', auth, wrap((req, res) => {
  const { token, platform } = req.body || {};
  need(token && platform, 'token و platform مطلوبين.');
  db.prepare('INSERT INTO push_tokens (token,user_id,platform) VALUES (?,?,?) ON CONFLICT(token) DO UPDATE SET user_id=excluded.user_id, platform=excluded.platform').run(token, req.user.id, platform);
  res.status(204).end();
}));
r.delete('/push-tokens', auth, wrap((req, res) => { db.prepare('DELETE FROM push_tokens WHERE token=? AND user_id=?').run(String((req.body || {}).token || ''), req.user.id); res.status(204).end(); }));

module.exports = r;
