// End-to-end smoke test: starts the API on a temp database and exercises every endpoint the mobile app uses.
const { spawn } = require('child_process');
const os = require('os'); const fs = require('fs'); const path = require('path');
const assert = require('assert');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'edu-api-'));
const PORT = 3900 + Math.floor(Math.random() * 90);
const base = `http://127.0.0.1:${PORT}`; const A = `${base}/api/v1`; const KEY = 'test-admin';
const srv = spawn('node', [path.join(__dirname, '..', 'src', 'server.js')], { env: { ...process.env, PORT, DATA_DIR: dir, JWT_SECRET: 'x'.repeat(32), ADMIN_KEY: KEY }, stdio: 'inherit' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const DEV = 'device-1';
async function call(method, p, { body, token, dev = DEV, admin, raw } = {}) {
  const h = { 'X-Device-Id': dev };
  if (body) h['Content-Type'] = 'application/json';
  if (token) h.Authorization = `Bearer ${token}`;
  if (admin) h['X-Admin-Key'] = KEY;
  const res = await fetch(A + p, { method, headers: h, body: body ? JSON.stringify(body) : undefined });
  if (raw) return res;
  const txt = await res.text();
  return { status: res.status, json: txt ? JSON.parse(txt) : null };
}
const ok = (r, s = 200) => assert.strictEqual(r.status, s, JSON.stringify(r.json));
const ad = (m, p, b) => call(m, '/admin' + p, { body: b, admin: true });
let passed = 0; const t = (n) => { passed++; console.log('  ✓', n); };

(async () => {
  for (let i = 0; i < 50; i++) { try { await fetch(base + '/health'); break; } catch { await sleep(100); } }
  // auth
  let r = await call('POST', '/auth/register', { body: { name: 'طالب', password: '123456', phone: '01099999999', deviceId: DEV } }); ok(r, 201);
  let { accessToken: tok, refreshToken: ref } = r.json; assert(r.json.user.deviceBound); t('register');
  r = await call('POST', '/auth/register', { body: { name: 'x', password: '123456', phone: '01099999999' } }); ok(r, 400); t('register validation');
  r = await call('POST', '/auth/login', { body: { identifier: '01099999999', password: 'bad', deviceId: DEV } }); ok(r, 401); assert.strictEqual(r.json.error.code, 'invalid_credentials'); t('bad login');
  r = await call('POST', '/auth/login', { body: { identifier: '01099999999', password: '123456', deviceId: 'other' } }); ok(r, 403); assert.strictEqual(r.json.error.code, 'device_locked'); t('device_locked on login');
  r = await call('GET', '/auth/me', { token: tok, dev: 'other' }); ok(r, 403); t('device_locked on request');
  r = await call('POST', '/auth/login', { body: { identifier: '01099999999', password: '123456', deviceId: DEV } }); ok(r); tok = r.json.accessToken; ref = r.json.refreshToken; t('login');
  r = await call('GET', '/auth/me'); ok(r, 401); t('unauthorized without token');
  r = await call('POST', '/auth/refresh', { body: { refreshToken: ref, deviceId: DEV } }); ok(r); tok = r.json.accessToken;
  r = await call('POST', '/auth/refresh', { body: { refreshToken: ref, deviceId: DEV } }); ok(r, 401); ref = null; t('refresh rotates');
  r = await call('POST', '/auth/forgot-password', { body: { identifier: '01099999999' } }); ok(r, 204);
  r = await ad('GET', '/password-requests'); ok(r); assert.strictEqual(r.json.length, 1); t('forgot-password');
  r = await call('PATCH', '/auth/me', { token: tok, body: { name: 'طالب جديد' } }); ok(r); assert.strictEqual(r.json.name, 'طالب جديد'); t('update profile');
  r = await call('POST', '/auth/change-password', { token: tok, body: { current: 'wrong', next: 'abcdef' } }); ok(r, 400);
  r = await call('POST', '/auth/change-password', { token: tok, body: { current: '123456', next: 'abcdef' } }); ok(r, 204); t('change password');
  const userId = r.json === null ? (await call('GET', '/auth/me', { token: tok })).json.id : null;

  // admin content
  const teacher = (await ad('POST', '/teachers', { name: 'أ. أحمد' })).json.id;
  const course = (await ad('POST', '/courses', { teacherId: teacher, title: 'كيمياء' })).json.id;
  const quiz = (await ad('POST', '/quizzes', { courseId: course, title: 'امتحان', maxAttempts: 2, timeLimitMinutes: 10 })).json.id;
  const hw = (await ad('POST', '/quizzes', { courseId: course, title: 'واجب', kind: 'homework' })).json.id;
  await ad('POST', `/quizzes/${quiz}/questions`, { body: 'Q1', options: ['a', 'b', 'c'], correctIndex: 2 });
  await ad('POST', `/quizzes/${quiz}/questions`, { body: 'Q2', options: ['a', 'b'], correctIndex: 0, points: 2 });
  await ad('POST', `/quizzes/${hw}/questions`, { kind: 'essay', body: 'اشرح', points: 4 });
  const l1 = (await ad('POST', '/lessons', { courseId: course, title: 'L1', position: 1, videoUrl: 'https://youtu.be/abc', minSeconds: 0 })).json.id;
  const l2 = (await ad('POST', '/lessons', { courseId: course, title: 'L2', position: 2, videoUrl: 'https://youtu.be/def', unlockAfterQuizId: quiz })).json.id;
  const pdf = new FormData(); pdf.append('title', 'ملزمة'); pdf.append('file', new Blob(['%PDF-1.4 test'], { type: 'application/pdf' }), 'a.pdf');
  r = await fetch(`${A}/admin/lessons/${l1}/files`, { method: 'POST', headers: { 'X-Admin-Key': KEY }, body: pdf }); assert.strictEqual(r.status, 201);
  r = await call('GET', '/courses', { token: tok }); ok(r); assert.strictEqual(r.json.length, 0); t('no courses before subscribing');
  r = await call('GET', `/courses/${course}/lessons`, { token: tok }); ok(r, 403); assert.strictEqual(r.json.error.code, 'not_enrolled'); t('not_enrolled');
  const codes = (await ad('POST', '/codes', { courseId: course, days: 30, count: 2 })).json.codes;
  r = await call('POST', '/codes/redeem', { token: tok, body: { code: 'NOPE' } }); ok(r, 400); assert.strictEqual(r.json.error.code, 'invalid_code');
  r = await call('POST', '/codes/redeem', { token: tok, body: { code: codes[0].toLowerCase() } }); ok(r); assert.strictEqual(r.json.courseId, course); t('redeem code');
  r = await call('POST', '/codes/redeem', { token: tok, body: { code: codes[0] } }); ok(r, 400); t('code single use');
  r = await call('GET', '/courses', { token: tok }); ok(r); assert.strictEqual(r.json[0].teacherName, 'أ. أحمد'); t('courses list');

  // lessons
  r = await call('GET', `/courses/${course}/lessons`, { token: tok }); ok(r);
  assert.strictEqual(r.json[0].locked, false); assert.strictEqual(r.json[0].files.length, 1); assert.strictEqual(r.json[1].locked, true); assert.strictEqual(r.json[1].videoUrl, null); assert.strictEqual(r.json[1].assessmentLocked, true); t('lessons + lock flags');
  const fileId = r.json[0].files[0].id;
  r = await call('POST', `/lessons/${l1}/heartbeat`, { token: tok }); ok(r, 409); t('heartbeat before start -> not_started');
  r = await call('POST', `/lessons/${l1}/start`, { token: tok }); ok(r); t('lesson start');
  r = await call('POST', `/lessons/${l1}/heartbeat`, { token: tok }); ok(r);
  r = await call('POST', `/lessons/${l1}/complete`, { token: tok }); ok(r); t('lesson complete');
  r = await call('POST', `/lessons/${l2}/start`, { token: tok }); ok(r, 403); assert.strictEqual(r.json.error.code, 'locked_lesson'); t('lesson locked until quiz submitted');
  r = await call('GET', `/lesson-files/${fileId}`, { token: tok, raw: true }); assert.strictEqual(r.status, 200); t('lesson file download');

  // quiz
  r = await call('GET', `/courses/${course}/quizzes`, { token: tok }); ok(r); assert.strictEqual(r.json.length, 2);
  r = await call('GET', `/quizzes/${quiz}/questions`, { token: tok }); ok(r, 409); assert.strictEqual(r.json.error.code, 'not_started'); t('timed quiz questions need start');
  r = await call('POST', `/quizzes/${quiz}/submit`, { token: tok, body: { answers: {} } }); ok(r, 409); assert.strictEqual(r.json.error.code, 'session_required');
  r = await call('POST', `/quizzes/${quiz}/start`, { token: tok }); ok(r); const s1 = r.json; assert(s1.sessionId && s1.endsAt && s1.questions.length === 2);
  r = await call('POST', `/quizzes/${quiz}/start`, { token: tok }); ok(r); assert.strictEqual(r.json.sessionId, s1.sessionId); t('quiz start is idempotent');
  // answer correctly using DISPLAYED positions: find displayed index of correct option text
  const correct = { Q1: 'c', Q2: 'a' }; const ans = {};
  for (const q of s1.questions) ans[q.id] = q.options.indexOf(correct[q.body]);
  r = await call('POST', `/quizzes/${quiz}/submit`, { token: tok, body: { answers: ans, sessionId: s1.sessionId } }); ok(r, 201);
  assert.strictEqual(r.json.score, 3); assert.strictEqual(r.json.mcqTotal, 3); const sub = r.json.id; t('quiz submit + shuffled grading');
  r = await call('POST', `/quizzes/${quiz}/submit`, { token: tok, body: { answers: ans, sessionId: s1.sessionId } }); ok(r, 409); t('session single use');
  r = await call('GET', `/quizzes/${quiz}/attempts`, { token: tok }); ok(r); assert.strictEqual(r.json.length, 1);
  r = await call('GET', `/submissions/${sub}`, { token: tok }); ok(r); assert(r.json.answersVisible); assert.strictEqual(r.json.items.length, 2);
  for (const it of r.json.items) assert.strictEqual(it.yourAnswer, String(it.correctIndex)); t('review');
  r = await call('POST', `/lessons/${l2}/start`, { token: tok }); ok(r); t('lesson unlocked after quiz');

  // homework with essay + upload
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
  const fd = new FormData(); fd.append('file', new Blob([png], { type: 'image/png' }), 'a.png');
  let up = await fetch(`${A}/uploads?kind=answer`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'X-Device-Id': DEV }, body: fd }); assert.strictEqual(up.status, 201);
  const upId = (await up.json()).id;
  const bad = new FormData(); bad.append('file', new Blob(['not an image']), 'a.png');
  up = await fetch(`${A}/uploads?kind=answer`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'X-Device-Id': DEV }, body: bad }); assert.strictEqual(up.status, 400); t('uploads (valid + rejected)');
  r = await call('POST', `/quizzes/${hw}/start`, { token: tok }); ok(r); assert.strictEqual(r.json.sessionId, null);
  const eq = r.json.questions[0];
  r = await call('POST', `/quizzes/${hw}/submit`, { token: tok, body: { answers: { [eq.id]: 'إجابتي' }, images: { [eq.id]: [upId] } } }); ok(r, 201); assert(r.json.hasEssay); const hs = r.json.id;
  r = await call('GET', `/submissions/${hs}`, { token: tok }); ok(r); assert(r.json.essayPending); assert.deepStrictEqual(r.json.items[0].yourImages, [upId]);
  r = await call('GET', `/uploads/${upId}`, { token: tok, raw: true }); assert.strictEqual(r.status, 200); assert.strictEqual(r.headers.get('content-type'), 'image/png'); t('essay submit + image fetch');
  r = await ad('POST', `/submissions/${hs}/grade`, { essayScore: 3, feedback: 'تمام' }); assert.strictEqual(r.status, 204);
  r = await call('GET', `/submissions/${hs}`, { token: tok }); assert.strictEqual(r.json.essayScore, 3); assert.strictEqual(r.json.essayPending, false); t('teacher grading');

  // rank + notifications + push
  r = await call('GET', `/courses/${course}/my-rank`, { token: tok }); ok(r); assert.strictEqual(r.json.rank, 1); assert(r.json.percent > 0); t('my-rank');
  r = await call('GET', '/notifications/unread-count', { token: tok }); ok(r); assert(r.json.count >= 2);
  r = await call('GET', '/notifications?pageSize=50', { token: tok }); ok(r); const nid = r.json[0].id;
  r = await call('POST', `/notifications/${nid}/read`, { token: tok }); ok(r, 204);
  r = await call('POST', '/notifications/read-all', { token: tok }); ok(r, 204);
  r = await call('GET', '/notifications/unread-count', { token: tok }); assert.strictEqual(r.json.count, 0); t('notifications');
  r = await ad('POST', '/announcements', { title: 'إعلان', body: 'مرحبا' }); assert.strictEqual(r.json.sent, 1);
  r = await call('POST', '/push-tokens', { token: tok, body: { token: 'tkn', platform: 'android' } }); ok(r, 204);
  r = await call('DELETE', '/push-tokens', { token: tok, body: { token: 'tkn' } }); ok(r, 204); t('push tokens + announcements');
  r = await ad('POST', `/students/${userId}/reset-device`); assert.strictEqual(r.status, 204);
  r = await call('POST', '/auth/login', { body: { identifier: '01099999999', password: 'abcdef', deviceId: 'new-phone' } }); ok(r); t('admin reset-device lets a new device log in');
  r = await call('POST', '/auth/logout', { body: { refreshToken: r.json.refreshToken } }); ok(r, 204);
  r = await fetch(`${A}/admin/students`, { headers: { 'X-Admin-Key': 'wrong' } }); assert.strictEqual(r.status, 401); t('admin key required');
  console.log(`\nAll ${passed} checks passed.`);
})().then(() => { srv.kill(); process.exit(0); }).catch((e) => { console.error('\nFAILED:', e.message); srv.kill(); process.exit(1); });
