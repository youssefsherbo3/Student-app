// Creates demo data: 1 teacher, 2 courses, lessons, a timed quiz, a homework with an essay question,
// a PDF handout, 3 demo students and subscription codes. Safe to run once on an empty database.
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { db, DATA_DIR } = require('../src/db');
const { uid, nowIso } = require('../src/util');

if (db.prepare('SELECT COUNT(*) c FROM courses').get().c > 0) {
  console.log('Database already has courses – demo seed skipped. Delete data/app.db to start over.');
  process.exit(0);
}
const pw = () => crypto.randomBytes(5).toString('hex');
const teacher = uid(); db.prepare('INSERT INTO teachers (id,name) VALUES (?,?)').run(teacher, 'أ. أحمد');
const mkCourse = (t, d) => { const id = uid(); db.prepare('INSERT INTO courses (id,teacher_id,title,description) VALUES (?,?,?,?)').run(id, teacher, t, d); return id; };
const chem = mkCourse('الكيمياء – الصف الثالث الثانوي', 'شرح المنهج كامل مع امتحانات.');
const phys = mkCourse('الفيزياء – الصف الثالث الثانوي', 'الفيزياء الحديثة والكهربية.');

const minimalPdf = '%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 300 144]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n4 0 obj<</Length 44>>stream\nBT /F1 18 Tf 20 70 Td (Demo handout) Tj ET\nendstream endobj\n5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\ntrailer<</Root 1 0 R/Size 6>>\n%%EOF\n';
const lesson = (course, title, pos, extra = {}) => {
  const id = uid();
  db.prepare('INSERT INTO lessons (id,course_id,title,position,video_url,min_seconds,opens_at,unlock_after_quiz_id) VALUES (?,?,?,?,?,?,?,?)')
    .run(id, course, title, pos, 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', extra.min ?? 30, null, extra.unlock || null);
  return id;
};
const l1 = lesson(chem, 'الدرس 1: مقدمة الكيمياء العضوية', 1);
const file = `${uid()}.pdf`; fs.writeFileSync(path.join(DATA_DIR, 'lesson-files', file), minimalPdf);
db.prepare('INSERT INTO lesson_files (id,lesson_id,title,path,size) VALUES (?,?,?,?,?)').run(uid(), l1, 'ملزمة الدرس 1', file, minimalPdf.length);

const quiz = uid();
db.prepare('INSERT INTO quizzes (id,course_id,title,kind,max_attempts,time_limit_minutes,show_answers) VALUES (?,?,?,?,?,?,1)').run(quiz, chem, 'امتحان الباب الأول', 'quiz', 3, 10);
const q = (qz, body, options, correct, pts = 1, pos = 0) => db.prepare('INSERT INTO questions (id,quiz_id,kind,body,options,correct_index,points,position) VALUES (?,?,?,?,?,?,?,?)')
  .run(uid(), qz, options ? 'mcq' : 'essay', body, JSON.stringify(options || []), correct ?? null, pts, pos);
q(quiz, 'ما الصيغة العامة للألكانات؟', ['CnH2n', 'CnH2n+2', 'CnH2n-2', 'CnHn'], 1, 1, 1);
q(quiz, 'أي مما يلي هيدروكربون غير مشبع؟', ['ميثان', 'إيثان', 'إيثين', 'بروبان'], 2, 1, 2);
q(quiz, 'ما اسم المركب CH3CH2CH2CH3؟', ['بيوتان', 'بروبان', 'بنتان', 'ميثيل بروبان'], 0, 1, 3);
lesson(chem, 'الدرس 2: الألكانات', 2, { unlock: quiz });
lesson(chem, 'الدرس 3: الألكينات', 3);
lesson(phys, 'الدرس 1: الكهربية الساكنة', 1);

const hw = uid();
db.prepare('INSERT INTO quizzes (id,course_id,title,kind,max_attempts,show_answers) VALUES (?,?,?,?,?,1)').run(hw, chem, 'واجب الألكانات', 'homework', 2);
q(hw, 'ارسم الصيغة البنائية للـ 2-methylbutane.', null, null, 5, 1);
q(hw, 'ما الصيغة الجزيئية للهكسان؟', ['C6H12', 'C6H14', 'C5H12', 'C6H10'], 1, 1, 2);

console.log('\n=== Demo students (password shown once) ===');
const students = [['طالب تجريبي ١', '01011111111'], ['طالب تجريبي ٢', '01022222222'], ['طالب تجريبي ٣', '01033333333']];
students.forEach(([name, phone], i) => {
  const p = pw(); const id = uid();
  db.prepare('INSERT INTO users (id,name,role,phone,password_hash,created_at) VALUES (?,?,?,?,?,?)').run(id, name, 'student', phone, bcrypt.hashSync(p, 10), nowIso());
  if (i === 0) db.prepare('INSERT INTO subscriptions (id,user_id,course_id,expires_at) VALUES (?,?,?,?)').run(uid(), id, chem, new Date(Date.now() + 180 * 86400000).toISOString());
  console.log(`${name}: ${phone} / ${p}`);
});
console.log('\n=== Subscription codes (use in the "كود" tab) ===');
for (const [label, course] of [['Chemistry', chem], ['Physics', phys]]) {
  for (let i = 0; i < 3; i++) { const code = crypto.randomBytes(5).toString('hex').toUpperCase(); db.prepare('INSERT INTO codes (id,code,course_id,days) VALUES (?,?,?,180)').run(uid(), code, course); console.log(`${label}: ${code}`); }
}
console.log('\nDone.');
