import 'dart:convert';

import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/core/token_store.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

http.Response jsonResponse(int status, Object? body) => http.Response.bytes(
      utf8.encode(body == null ? '' : jsonEncode(body)),
      status,
      headers: {'content-type': 'application/json; charset=utf-8'},
    );

const testDeviceId = 'device-1234-abcd';

ApiClient makeApi(MockClient mock, {TokenStore? tokens}) => ApiClient(
      baseUrl: 'http://api.test/api/v1',
      tokens: tokens ?? InMemoryTokenStore(access: 'A1', refresh: 'R1'),
      deviceId: testDeviceId,
      httpClient: mock,
    );
