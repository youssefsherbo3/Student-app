import 'dart:convert';

import 'package:edu_student/core/app_scope.dart';
import 'package:edu_student/core/image_picker_service.dart';
import 'package:edu_student/core/pdf_service.dart';
import 'package:edu_student/features/auth/auth_repository.dart';
import 'package:edu_student/features/courses/course_models.dart';
import 'package:edu_student/features/courses/courses_repository.dart';
import 'package:edu_student/features/lessons/lesson_models.dart';
import 'package:edu_student/features/lessons/lessons_repository.dart';
import 'package:edu_student/features/notifications/notification_models.dart';
import 'package:edu_student/features/notifications/notifications_repository.dart';
import 'package:edu_student/features/notifications/push_service.dart';
import 'package:edu_student/features/quizzes/quiz_models.dart';
import 'package:edu_student/features/quizzes/quizzes_repository.dart';
import 'package:edu_student/features/redeem/redeem_repository.dart';
import 'package:edu_student/features/uploads/uploads_repository.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

const testUser = AppUser(id: 'u1', name: 'طالب تجريبي', role: 'student', phone: '01011111111');

class FakeAuthRepository implements AuthRepository {
  final ValueNotifier<AppUser?> _user = ValueNotifier<AppUser?>(null);
  Object? loginError;
  Object? changePasswordError;
  String? lastIdentifier;
  String? lastPassword;
  String? lastNewPassword;
  bool loggedOut = false;

  @override
  ValueListenable<AppUser?> get user => _user;

  void setUser(AppUser? u) => _user.value = u;

  @override
  Future<void> restore() async {}

  @override
  Future<AppUser> login(String identifier, String password) async {
    lastIdentifier = identifier;
    lastPassword = password;
    final err = loginError;
    if (err != null) throw err;
    _user.value = testUser;
    return testUser;
  }

  @override
  Future<AppUser> register({
    required String name,
    required String password,
    String? phone,
    String? email,
    String? parentPhone,
  }) async {
    _user.value = testUser;
    return testUser;
  }

  @override
  Future<void> logout() async {
    loggedOut = true;
    _user.value = null;
  }

  @override
  Future<void> changePassword(String current, String next) async {
    final err = changePasswordError;
    if (err != null) throw err;
    lastNewPassword = next;
  }

  Object? forgotError;
  final List<String> forgotIdentifiers = <String>[];
  Object? updateError;
  String? updatedName;
  String? updatedAvatarId;

  @override
  Future<void> forgotPassword(String identifier) async {
    forgotIdentifiers.add(identifier);
    final err = forgotError;
    if (err != null) throw err;
  }

  @override
  Future<AppUser> updateProfile({String? name, String? avatarUploadId}) async {
    final err = updateError;
    if (err != null) throw err;
    updatedName = name;
    updatedAvatarId = avatarUploadId;
    final u = AppUser(id: 'u1', name: name ?? testUser.name, role: 'student', phone: testUser.phone);
    _user.value = u;
    return u;
  }
}

class FakeCoursesRepository implements CoursesRepository {
  List<Course> courses = <Course>[const Course(id: 'c1', title: 'فيزياء', description: 'وصف الكورس')];
  Object? error;
  MyRank rank = const MyRank(rank: 2, of: 10, percent: 80);
  Object? rankError;

  @override
  Future<MyRank> myRank(String courseId) async {
    final err = rankError;
    if (err != null) throw err;
    return rank;
  }

  @override
  Future<List<Course>> list() async {
    final err = error;
    if (err != null) throw err;
    return courses;
  }
}

class FakeLessonsRepository implements LessonsRepository {
  List<Lesson> lessons = <Lesson>[
    const Lesson(id: 'l1', title: 'الدرس الأول', locked: true),
    const Lesson(id: 'l2', title: 'الدرس الثاني', videoUrl: 'https://youtu.be/abc123'),
  ];
  int remainingSeconds = 0;
  Object? completeError;
  final List<String> started = <String>[];
  final List<String> completed = <String>[];
  final List<String> heartbeats = <String>[];
  final List<String> downloadedFiles = <String>[];
  Uint8List fileBytes = Uint8List.fromList(<int>[0x25, 0x50, 0x44, 0x46, 0x2d]);
  Object? downloadError;

  @override
  Future<Uint8List> downloadFile(String fileId) async {
    final err = downloadError;
    if (err != null) throw err;
    downloadedFiles.add(fileId);
    return fileBytes;
  }

  @override
  Future<void> heartbeat(String lessonId) async {
    heartbeats.add(lessonId);
  }

  @override
  Future<List<Lesson>> list(String courseId) async => lessons;

  @override
  Future<LessonStart> start(String lessonId) async {
    started.add(lessonId);
    return LessonStart(remainingSeconds: remainingSeconds);
  }

  @override
  Future<void> complete(String lessonId) async {
    final err = completeError;
    if (err != null) {
      completeError = null; // fail once
      throw err;
    }
    completed.add(lessonId);
  }
}

class FakeQuizzesRepository implements QuizzesRepository {
  List<Quiz> quizzes = <Quiz>[const Quiz(id: 'z1', title: 'امتحان الفصل الأول')];
  bool withEssay = false;
  Map<String, Object>? submitted;
  String? submittedSessionId;
  Map<String, List<String>>? submittedImages;
  int submitCalls = 0;
  int startCalls = 0;
  QuizStart? startOverride;
  Object? submitError;
  SubmitResult submitResult = const SubmitResult(id: 's1', score: 1, mcqTotal: 2, hasEssay: false);
  List<Attempt> attemptList = <Attempt>[
    Attempt(id: 'a2', score: 2, essayScore: 4, feedback: 'شغل كويس', createdAt: DateTime.utc(2026, 1, 2, 10, 30)),
    Attempt(id: 'a1', score: 1, createdAt: DateTime.utc(2026, 1, 1, 9)),
  ];
  Review reviewResult = const Review(
    score: 1,
    mcqTotal: 1,
    essayScore: null,
    essayTotal: 5,
    essayPending: true,
    answersVisible: false,
    feedback: 'ملاحظة المصحّح التجريبية',
    items: <ReviewItem>[
      ReviewItem(questionId: 'q1', kind: 'mcq', body: 'سؤال اختياري', options: <String>['أ', 'ب'], points: 1, yourAnswer: '0'),
      ReviewItem(questionId: 'q3', kind: 'essay', body: 'اشرح', points: 5, yourAnswer: 'إجابتي'),
    ],
  );

  @override
  Future<List<Quiz>> list(String courseId) async => quizzes;

  @override
  Future<List<Question>> questions(String quizId) async => <Question>[
        const Question(id: 'q1', body: 'سؤال أول', options: <String>['خيار ١', 'خيار ٢']),
        const Question(id: 'q2', body: 'سؤال تاني', options: <String>['خيار ٣', 'خيار ٤']),
        if (withEssay) const Question(id: 'q3', body: 'اشرح', kind: 'essay', points: 5),
      ];

  @override
  Future<QuizStart> start(String quizId) async {
    startCalls++;
    return startOverride ?? QuizStart(questions: await questions(quizId));
  }

  @override
  Future<SubmitResult> submit(
    String quizId,
    Map<String, Object> answers, {
    String? sessionId,
    Map<String, List<String>> images = const <String, List<String>>{},
  }) async {
    submitCalls++;
    final err = submitError;
    if (err != null) throw err;
    submitted = Map<String, Object>.of(answers);
    submittedSessionId = sessionId;
    submittedImages = images;
    return submitResult;
  }

  @override
  Future<List<Attempt>> attempts(String quizId) async => attemptList;

  @override
  Future<Review> review(String submissionId) async => reviewResult;
}

class FakeUploadsRepository implements UploadsRepository {
  Object? error;
  final List<String> kinds = <String>[];
  final List<Uint8List> uploaded = <Uint8List>[];
  final List<String> downloaded = <String>[];
  Uint8List downloadBytes = Uint8List.fromList(<int>[1, 2, 3]);
  int _n = 0;

  @override
  Future<UploadResult> upload(PickedImage image, String kind) async {
    final err = error;
    if (err != null) throw err;
    kinds.add(kind);
    uploaded.add(image.bytes);
    _n++;
    return UploadResult(id: 'up$_n');
  }

  @override
  Future<Uint8List> download(String uploadId) async {
    downloaded.add(uploadId);
    return downloadBytes;
  }
}

class FakePdfService implements PdfService {
  final List<String> opened = <String>[];
  Uint8List? lastBytes;

  @override
  Future<void> open(Uint8List bytes, String filename) async {
    opened.add(filename);
    lastBytes = bytes;
  }
}

class FakeImagePickerService implements ImagePickerService {
  /// A valid 1x1 PNG.
  PickedImage? next = PickedImage(
    bytes: base64Decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=='),
    name: 'a.png',
  );
  final List<ImagePickSource> sources = <ImagePickSource>[];

  @override
  Future<PickedImage?> pick(ImagePickSource source) async {
    sources.add(source);
    return next;
  }
}

class FakeRedeemRepository implements RedeemRepository {
  Object? error;
  final List<String> codes = <String>[];
  RedeemResult result = RedeemResult(courseId: 'c1', expiresAt: DateTime(2026, 12, 31, 12));

  @override
  Future<RedeemResult> redeem(String code) async {
    codes.add(code);
    final err = error;
    if (err != null) throw err;
    return result;
  }
}

class FakeNotificationsRepository implements NotificationsRepository {
  List<AppNotification> items = <AppNotification>[
    const AppNotification(id: 'n1', type: 'lesson_opened', title: 'درس جديد', body: 'الدرس الثالث'),
    const AppNotification(id: 'n2', type: 'enrolled', title: 'تم تفعيل اشتراكك', body: 'فيزياء', read: true),
  ];
  final List<String> readIds = <String>[];
  bool readAll = false;
  final List<String> registeredTokens = <String>[];
  final List<String> removedTokens = <String>[];

  @override
  Future<List<AppNotification>> list({bool unreadOnly = false}) async =>
      unreadOnly ? items.where((n) => !n.read).toList() : items;

  @override
  Future<int> unreadCount() async => items.where((n) => !n.read).length;

  @override
  Future<void> markRead(String id) async {
    readIds.add(id);
  }

  @override
  Future<void> markAllRead() async {
    readAll = true;
  }

  @override
  Future<void> registerPushToken(String token, String platform) async {
    registeredTokens.add(token);
  }

  @override
  Future<void> unregisterPushToken(String token) async {
    removedTokens.add(token);
  }
}

class FakePushService implements PushService {
  FakePushService([this.token]);

  final String? token;

  @override
  Future<String?> getToken() async => token;

  @override
  Stream<String> get onTokenRefresh => const Stream<String>.empty();
}

/// Bundle of fakes + a helper that wraps a widget in AppScope and a MaterialApp.
class Fakes {
  final FakeAuthRepository auth = FakeAuthRepository();
  final FakeCoursesRepository courses = FakeCoursesRepository();
  final FakeLessonsRepository lessons = FakeLessonsRepository();
  final FakeQuizzesRepository quizzes = FakeQuizzesRepository();
  final FakeRedeemRepository redeem = FakeRedeemRepository();
  final FakeNotificationsRepository notifications = FakeNotificationsRepository();
  final FakeUploadsRepository uploads = FakeUploadsRepository();
  final FakeImagePickerService picker = FakeImagePickerService();
  final FakePdfService pdf = FakePdfService();
  PushService push = FakePushService();

  Widget scope(Widget child) => AppScope(
        auth: auth,
        courses: courses,
        lessons: lessons,
        quizzes: quizzes,
        redeem: redeem,
        notifications: notifications,
        push: push,
        uploads: uploads,
        imagePicker: picker,
        pdf: pdf,
        child: child,
      );

  /// Pumps [home] inside AppScope + MaterialApp on a tall surface so nothing needs scrolling.
  Future<void> pump(WidgetTester tester, Widget home) async {
    tester.view.physicalSize = const Size(900, 2400);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(scope(MaterialApp(home: home)));
    await tester.pumpAndSettle();
  }

  /// Like [pump] but [page] is pushed on top of a launcher route, so `Navigator.pop` works.
  /// With settle=false the page is shown without pumpAndSettle (needed while a periodic timer runs).
  Future<void> pumpPushed(WidgetTester tester, Widget page, {bool settle = true}) async {
    await pump(
      tester,
      Builder(
        builder: (context) => Scaffold(
          body: Center(
            child: TextButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<Object?>(builder: (_) => page)),
              child: const Text('open'),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('open'));
    if (settle) {
      await tester.pumpAndSettle();
    } else {
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 400));
    }
  }
}
