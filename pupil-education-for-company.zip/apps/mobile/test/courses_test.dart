import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/features/courses/course_models.dart';
import 'package:edu_student/features/courses/course_page.dart';
import 'package:edu_student/features/courses/courses_page.dart';
import 'package:edu_student/features/lessons/lesson_models.dart';
import 'package:edu_student/features/quizzes/quiz_models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

void main() {
  testWidgets('courses list shows title, description and expiry', (
    tester,
  ) async {
    final fakes = Fakes();
    fakes.courses.courses = [
      Course(
        id: 'c1',
        title: 'فيزياء',
        description: 'وصف الكورس',
        expiresAt: DateTime(2026, 12, 31, 12),
      ),
    ];
    await fakes.pump(tester, const CoursesPage());
    expect(find.text('فيزياء'), findsOneWidget);
    expect(find.textContaining('وصف الكورس'), findsOneWidget);
    expect(find.textContaining('2026/12/31'), findsOneWidget);
  });

  testWidgets('courses are grouped under their subscribed teachers', (
    tester,
  ) async {
    final fakes = Fakes();
    fakes.courses.courses = const [
      Course(
        id: 'c1',
        title: 'فيزياء',
        teacherId: 't1',
        teacherName: 'مستر أحمد',
      ),
      Course(
        id: 'c2',
        title: 'كيمياء',
        teacherId: 't1',
        teacherName: 'مستر أحمد',
      ),
      Course(
        id: 'c3',
        title: 'أحياء',
        teacherId: 't2',
        teacherName: 'مستر أحمد',
      ),
    ];
    await fakes.pump(tester, const CoursesPage());
    expect(find.text('مستر أحمد'), findsNWidgets(2));
    expect(find.text('فيزياء'), findsOneWidget);
    expect(find.text('كيمياء'), findsOneWidget);
    expect(find.text('أحياء'), findsOneWidget);
  });

  testWidgets('empty courses list shows a hint', (tester) async {
    final fakes = Fakes();
    fakes.courses.courses = [];
    await fakes.pump(tester, const CoursesPage());
    expect(find.textContaining('مفيش كورسات'), findsOneWidget);
  });

  testWidgets('error shows retry which reloads', (tester) async {
    final fakes = Fakes();
    fakes.courses.error = const ApiException(0, 'network', '');
    await fakes.pump(tester, const CoursesPage());
    expect(find.textContaining('مفيش اتصال'), findsOneWidget);
    fakes.courses.error = null;
    await tester.tap(find.text('حاول تاني'));
    await tester.pumpAndSettle();
    expect(find.text('فيزياء'), findsOneWidget);
  });

  testWidgets('device_locked error offers logout', (tester) async {
    final fakes = Fakes();
    fakes.courses.error = const ApiException(403, 'device_locked', '');
    await fakes.pump(tester, const CoursesPage());
    expect(find.textContaining('جهاز تاني'), findsOneWidget);
    await tester.tap(find.text('تسجيل خروج'));
    await tester.pumpAndSettle();
    expect(fakes.auth.loggedOut, isTrue);
  });

  testWidgets('locked lesson shows a lock icon and does not open', (
    tester,
  ) async {
    final fakes = Fakes();
    await fakes.pump(
      tester,
      const CoursePage(
        course: Course(id: 'c1', title: 'فيزياء'),
      ),
    );
    expect(find.byIcon(Icons.lock), findsOneWidget);
    expect(find.byIcon(Icons.play_circle), findsOneWidget);
    await tester.tap(find.text('الدرس الأول'));
    await tester.pump();
    expect(find.textContaining('لسه مقفول'), findsWidgets);
    expect(fakes.lessons.started, isEmpty);
  });

  testWidgets(
    'tapping an assessment-locked lesson opens its linked quiz first',
    (tester) async {
      final fakes = Fakes();
      fakes.lessons.lessons = const [
        Lesson(
          id: 'l-assessment',
          title: 'حصة عليها واجب',
          locked: true,
          assessmentLocked: true,
          unlockAfterQuizId: 'z1',
          unlockAfterQuizTitle: 'امتحان الفصل الأول',
        ),
      ];
      fakes.quizzes.quizzes = const [
        Quiz(id: 'z1', title: 'امتحان الفصل الأول'),
      ];
      await fakes.pump(
        tester,
        const CoursePage(
          course: Course(id: 'c1', title: 'فيزياء'),
        ),
      );
      await tester.tap(find.text('حصة عليها واجب'));
      await tester.pumpAndSettle();
      expect(find.text('امتحان الفصل الأول'), findsOneWidget);
      expect(fakes.quizzes.startCalls, 1);
      expect(fakes.lessons.started, isEmpty);
    },
  );

  testWidgets('quizzes tab lists quizzes and homework', (tester) async {
    final fakes = Fakes();
    fakes.quizzes.quizzes = const [
      Quiz(id: 'z1', title: 'امتحان 1', maxAttempts: 2, attemptsUsed: 1),
      Quiz(id: 'z2', title: 'واجب 1', kind: 'homework', closed: true),
    ];
    await fakes.pump(
      tester,
      const CoursePage(
        course: Course(id: 'c1', title: 'فيزياء'),
      ),
    );
    await tester.tap(find.text('الامتحانات والواجبات'));
    await tester.pumpAndSettle();
    expect(find.text('امتحان 1'), findsOneWidget);
    expect(find.textContaining('1 / 2'), findsOneWidget);
    expect(find.byIcon(Icons.assignment), findsOneWidget);
  });
}
