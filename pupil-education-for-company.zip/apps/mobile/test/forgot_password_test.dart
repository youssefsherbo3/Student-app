import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/features/auth/forgot_password_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

void main() {
  test('only transport / rate-limit / server errors are shown', () {
    expect(forgotPasswordErrorIsVisible(const ApiException(0, 'network', '')), isTrue);
    expect(forgotPasswordErrorIsVisible(const ApiException(429, 'too_many_requests', '')), isTrue);
    expect(forgotPasswordErrorIsVisible(const ApiException(404, 'not_found', '')), isFalse);
  });

  testWidgets('empty identifier is rejected locally', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const ForgotPasswordPage());
    await tester.tap(find.byType(FilledButton));
    await tester.pumpAndSettle();
    expect(fakes.auth.forgotIdentifiers, isEmpty);
    expect(find.text('اكتب رقم الموبايل أو الإيميل.'), findsOneWidget);
  });

  testWidgets('submit sends the identifier and shows the neutral success view', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const ForgotPasswordPage());
    await tester.enterText(find.byType(TextField), '01011111111');
    await tester.tap(find.byType(FilledButton));
    await tester.pumpAndSettle();
    expect(fakes.auth.forgotIdentifiers, ['01011111111']);
    expect(find.byIcon(Icons.mark_email_read_outlined), findsOneWidget);
  });
}
