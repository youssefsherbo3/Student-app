import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/features/courses/course_models.dart';
import 'package:edu_student/features/lessons/lesson_models.dart';
import 'package:edu_student/features/lessons/lesson_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

const withFiles = Lesson(
  id: 'l2',
  title: 'الدرس الثاني',
  videoUrl: 'https://youtu.be/abc123',
  files: <LessonFile>[LessonFile(id: 'f1', title: 'ملزمة الفصل الأول', size: 2048)],
);

Widget page(Lesson l) => LessonPage(lesson: l, videoBuilder: (context, url) => Text('VIDEO:$url'));

void main() {
  test('Lesson.fromJson reads files and Course.fromJson reads teacherName', () {
    final l = Lesson.fromJson({
      'id': 'a',
      'title': 't',
      'files': [
        {'id': 'f1', 'title': 'x', 'size': 10}
      ]
    });
    expect(l.files.single.id, 'f1');
    expect(l.files.single.size, 10);
    expect(Lesson.fromJson({'id': 'a', 'title': 't'}).files, isEmpty);
    expect(Course.fromJson({'id': 'c', 'title': 'فيزياء', 'teacherName': 'مستر أحمد'}).teacherName, 'مستر أحمد');
    expect(Course.fromJson({'id': 'c', 'title': 'x'}).teacherName, '');
  });

  testWidgets('tapping a handout downloads it and hands it to the PDF service with a .pdf name', (tester) async {
    final fakes = Fakes();
    await fakes.pumpPushed(tester, page(withFiles), settle: false);
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('الملازم'), findsOneWidget);
    expect(find.text('2 ك.ب'), findsOneWidget);
    await tester.tap(find.text('ملزمة الفصل الأول'));
    await tester.pump(const Duration(milliseconds: 100));
    expect(fakes.lessons.downloadedFiles, ['f1']);
    expect(fakes.pdf.opened, ['ملزمة الفصل الأول.pdf']);
    expect(fakes.pdf.lastBytes, fakes.lessons.fileBytes);
  });

  testWidgets('a failed download shows the friendly error and nothing is opened', (tester) async {
    final fakes = Fakes();
    fakes.lessons.downloadError = const ApiException(0, 'network', '');
    await fakes.pumpPushed(tester, page(withFiles), settle: false);
    await tester.pump(const Duration(milliseconds: 100));
    await tester.tap(find.text('ملزمة الفصل الأول'));
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.textContaining('مفيش اتصال'), findsOneWidget);
    expect(fakes.pdf.opened, isEmpty);
  });

  testWidgets('no handouts section when the lesson has none', (tester) async {
    final fakes = Fakes();
    await fakes.pumpPushed(tester, page(const Lesson(id: 'l3', title: 'بدون ملازم', videoUrl: 'https://youtu.be/abc123')), settle: false);
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('الملازم'), findsNothing);
    expect(find.byType(LessonPage), findsOneWidget);
  });
}
