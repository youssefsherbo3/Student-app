import 'dart:convert';

import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/core/token_store.dart';
import 'package:edu_student/features/auth/auth_repository.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

http.Response jsonResponse(int status, Object? body) => http.Response.bytes(
      utf8.encode(body == null ? '' : jsonEncode(body)),
      status,
      headers: {'content-type': 'application/json; charset=utf-8'},
    );

Map<String, dynamic> errorBody(String code, String message) => {
      'error': {'code': code, 'message': message},
    };

const _device = 'device-1234-abcd';

ApiClient makeClient(MockClient mock, TokenStore tokens, {void Function()? onExpired}) =>
    ApiClient(baseUrl: 'http://api.test/api/v1', tokens: tokens, deviceId: _device, httpClient: mock, onSessionExpired: onExpired);

void main() {
  test('sends X-Device-Id and bearer token on every request, and parses JSON', () async {
    final seen = <http.Request>[];
    final mock = MockClient((req) async {
      seen.add(req);
      return jsonResponse(200, {'ok': true});
    });
    final api = makeClient(mock, InMemoryTokenStore(access: 'A1', refresh: 'R1'));

    final res = await api.get('/courses', query: {'page': '2'});
    await api.post('/lessons/l1/start');

    expect(res, {'ok': true});
    expect(seen, hasLength(2));
    for (final r in seen) {
      expect(r.headers['X-Device-Id'], _device);
      expect(r.headers['Authorization'], 'Bearer A1');
    }
    expect(seen[0].url.toString(), 'http://api.test/api/v1/courses?page=2');
    expect(seen[1].method, 'POST');
  });

  test('POST body is JSON and Arabic text survives', () async {
    http.Request? seen;
    final mock = MockClient((req) async {
      seen = req;
      return jsonResponse(201, {'id': 'x'});
    });
    final api = makeClient(mock, InMemoryTokenStore());
    await api.post('/auth/login', body: {'identifier': 'منى', 'password': 'pw'}, auth: false);
    expect(seen!.headers['Content-Type'], contains('application/json'));
    expect(jsonDecode(seen!.body), {'identifier': 'منى', 'password': 'pw'});
    expect(seen!.headers.containsKey('Authorization'), isFalse);
    expect(seen!.headers['X-Device-Id'], _device);
  });

  test('204 returns null', () async {
    final api = makeClient(MockClient((req) async => jsonResponse(204, null)), InMemoryTokenStore(access: 'A'));
    expect(await api.post('/lessons/l1/complete'), isNull);
  });

  test('401 triggers one refresh, rotates the stored refresh token and replays the request', () async {
    final tokens = InMemoryTokenStore(access: 'old', refresh: 'R1');
    final calls = <String>[];
    Map<String, dynamic>? refreshBody;
    final mock = MockClient((req) async {
      calls.add('${req.method} ${req.url.path} ${req.headers['Authorization'] ?? '-'}');
      if (req.url.path.endsWith('/auth/refresh')) {
        refreshBody = jsonDecode(req.body) as Map<String, dynamic>;
        expect(req.headers['X-Device-Id'], _device);
        return jsonResponse(200, {'accessToken': 'new', 'refreshToken': 'R2', 'expiresIn': 1800, 'user': <String, dynamic>{}});
      }
      if (req.headers['Authorization'] == 'Bearer new') return jsonResponse(200, [1, 2]);
      return jsonResponse(401, errorBody('invalid_token', 'x'));
    });
    final api = makeClient(mock, tokens);

    final res = await api.get('/courses');

    expect(res, [1, 2]);
    expect(refreshBody, {'refreshToken': 'R1', 'deviceId': _device});
    expect(await tokens.readAccess(), 'new');
    expect(await tokens.readRefresh(), 'R2');
    expect(calls, [
      'GET /api/v1/courses Bearer old',
      'POST /api/v1/auth/refresh -',
      'GET /api/v1/courses Bearer new',
    ]);
  });

  test('parallel 401s share a single refresh call', () async {
    final tokens = InMemoryTokenStore(access: 'old', refresh: 'R1');
    var refreshes = 0;
    final mock = MockClient((req) async {
      if (req.url.path.endsWith('/auth/refresh')) {
        refreshes++;
        await Future<void>.delayed(const Duration(milliseconds: 10));
        return jsonResponse(200, {'accessToken': 'new', 'refreshToken': 'R2'});
      }
      return req.headers['Authorization'] == 'Bearer new' ? jsonResponse(200, {'ok': 1}) : jsonResponse(401, errorBody('invalid_token', 'x'));
    });
    final api = makeClient(mock, tokens);
    final results = await Future.wait([api.get('/a'), api.get('/b'), api.get('/c')]);
    expect(results, hasLength(3));
    expect(refreshes, 1);
  });

  test('failed refresh clears tokens, notifies and surfaces the 401', () async {
    final tokens = InMemoryTokenStore(access: 'old', refresh: 'R1');
    var expired = 0;
    final mock = MockClient((req) async => jsonResponse(401, errorBody('invalid_token', 'منتهية')));
    final api = makeClient(mock, tokens, onExpired: () => expired++);

    await expectLater(api.get('/courses'), throwsA(isA<ApiException>().having((e) => e.status, 'status', 401)));

    expect(expired, 1);
    expect(await tokens.readAccess(), isNull);
    expect(await tokens.readRefresh(), isNull);
  });

  test('401 without a stored refresh token expires the session', () async {
    var expired = 0;
    final api = makeClient(MockClient((req) async => jsonResponse(401, errorBody('unauthorized', 'x'))), InMemoryTokenStore(access: 'a'), onExpired: () => expired++);
    await expectLater(api.get('/x'), throwsA(isA<ApiException>()));
    expect(expired, 1);
  });

  test('403 device_locked surfaces as ApiException.isDeviceLocked without refreshing', () async {
    var refreshes = 0;
    final mock = MockClient((req) async {
      if (req.url.path.endsWith('/auth/refresh')) refreshes++;
      return jsonResponse(403, errorBody('device_locked', 'الحساب مربوط بجهاز تاني'));
    });
    final api = makeClient(mock, InMemoryTokenStore(access: 'a', refresh: 'r'));
    await expectLater(
      api.get('/courses'),
      throwsA(isA<ApiException>().having((e) => e.isDeviceLocked, 'isDeviceLocked', true).having((e) => e.message, 'message', 'الحساب مربوط بجهاز تاني')),
    );
    expect(refreshes, 0);
  });

  test('network failure becomes ApiException(status 0)', () async {
    final api = makeClient(MockClient((req) async => throw http.ClientException('offline')), InMemoryTokenStore(access: 'a'));
    await expectLater(api.get('/courses'), throwsA(isA<ApiException>().having((e) => e.status, 'status', 0)));
  });

  test('validation_error keeps details', () async {
    final api = makeClient(
      MockClient((req) async => jsonResponse(400, {
            'error': {
              'code': 'validation_error',
              'message': 'bad',
              'details': [
                {'path': 'password', 'message': 'قصيرة'},
              ],
            },
          })),
      InMemoryTokenStore(),
    );
    try {
      await api.post('/auth/register', body: <String, dynamic>{}, auth: false);
      fail('should throw');
    } on ApiException catch (e) {
      expect(e.code, 'validation_error');
      expect(e.details, hasLength(1));
    }
  });

  group('HttpAuthRepository', () {
    Map<String, dynamic> session() => {
          'accessToken': 'AT',
          'refreshToken': 'RT',
          'expiresIn': 1800,
          'user': {'id': 'u1', 'name': 'منى', 'role': 'student', 'phone': '01011111111', 'deviceBound': true},
        };

    test('login sends deviceId, stores tokens and publishes the user', () async {
      Map<String, dynamic>? body;
      final tokens = InMemoryTokenStore();
      final mock = MockClient((req) async {
        body = jsonDecode(req.body) as Map<String, dynamic>;
        return jsonResponse(200, session());
      });
      final repo = HttpAuthRepository(api: makeClient(mock, tokens), tokens: tokens, deviceId: _device);

      final u = await repo.login(' 01011111111 ', 'pw');

      expect(body, {'identifier': '01011111111', 'password': 'pw', 'deviceId': _device});
      expect(u.name, 'منى');
      expect(repo.user.value?.id, 'u1');
      expect(await tokens.readRefresh(), 'RT');
    });

    test('logout clears tokens and user even if the server call fails', () async {
      final tokens = InMemoryTokenStore(access: 'AT', refresh: 'RT');
      final mock = MockClient((req) async => jsonResponse(500, errorBody('boom', 'x')));
      final repo = HttpAuthRepository(api: makeClient(mock, tokens), tokens: tokens, deviceId: _device);
      await repo.logout();
      expect(repo.user.value, isNull);
      expect(await tokens.readRefresh(), isNull);
    });

    test('session expiry from the ApiClient signs the user out', () async {
      final tokens = InMemoryTokenStore(access: 'AT', refresh: 'RT');
      var first = true;
      final mock = MockClient((req) async {
        if (first) {
          first = false;
          return jsonResponse(200, session()['user']);
        }
        return jsonResponse(401, errorBody('invalid_token', 'x'));
      });
      final api = makeClient(mock, tokens);
      final repo = HttpAuthRepository(api: api, tokens: tokens, deviceId: _device);
      await repo.restore();
      expect(repo.user.value, isNotNull);
      await expectLater(api.get('/courses'), throwsA(isA<ApiException>()));
      expect(repo.user.value, isNull);
    });

    test('restore without tokens does nothing', () async {
      final tokens = InMemoryTokenStore();
      final repo = HttpAuthRepository(api: makeClient(MockClient((req) async => throw StateError('no calls')), tokens), tokens: tokens, deviceId: _device);
      await repo.restore();
      expect(repo.user.value, isNull);
    });
  });
}
