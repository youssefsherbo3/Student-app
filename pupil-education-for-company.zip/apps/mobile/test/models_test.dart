import 'package:edu_student/features/auth/auth_repository.dart';
import 'package:edu_student/features/courses/course_models.dart';
import 'package:edu_student/features/lessons/lesson_models.dart';
import 'package:edu_student/features/notifications/notification_models.dart';
import 'package:edu_student/features/quizzes/quiz_models.dart';
import 'package:edu_student/features/redeem/redeem_repository.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('AppUser.fromJson', () {
    final u = AppUser.fromJson({
      'id': 'u1',
      'name': 'منى',
      'email': null,
      'phone': '01011111111',
      'parentPhone': '01099999999',
      'role': 'student',
      'deviceBound': true,
    });
    expect(u.name, 'منى');
    expect(u.email, isNull);
    expect(u.parentPhone, '01099999999');
    expect(u.deviceBound, isTrue);
  });

  test('Course.fromJson keeps expiresAt and tolerates missing description', () {
    final c = Course.fromJson({'id': 'c1', 'title': 'رياضة', 'expiresAt': '2026-12-31T00:00:00.000Z'});
    expect(c.description, '');
    expect(c.expiresAt, DateTime.utc(2026, 12, 31));
    expect(Course.fromJson({'id': 'c2', 'title': 'x'}).expiresAt, isNull);
  });

  test('Lesson.fromJson: locked lesson has no video', () {
    final l = Lesson.fromJson({
      'id': 'l1',
      'title': 'د1',
      'position': 2,
      'opensAt': '2030-01-01T10:00:00.000Z',
      'locked': true,
      'done': false,
      'minSeconds': 90,
      'unlockAfterQuizId': 'quiz-1',
      'unlockAfterQuizTitle': 'امتحان الفصل',
      'assessmentLocked': true,
      'videoUrl': null,
    });
    expect(l.locked, isTrue);
    expect(l.assessmentLocked, isTrue);
    expect(l.unlockAfterQuizId, 'quiz-1');
    expect(l.unlockAfterQuizTitle, 'امتحان الفصل');
    expect(l.videoUrl, isNull);
    expect(l.minSeconds, 90);
    expect(l.opensAt, isNotNull);
    expect(Lesson.fromJson({'id': 'l2', 'title': 't', 'done': true}).done, isTrue);
  });

  test('LessonStart.fromJson', () {
    final s = LessonStart.fromJson({'remainingSeconds': 42, 'startedAt': '2026-01-01T00:00:00.000Z'});
    expect(s.remainingSeconds, 42);
    expect(s.startedAt, isNotNull);
  });

  test('Quiz.fromJson and attempt gating', () {
    final q = Quiz.fromJson({'id': 'z', 'title': 'q', 'kind': 'homework', 'maxAttempts': 2, 'attemptsUsed': 2});
    expect(q.isHomework, isTrue);
    expect(q.noAttemptsLeft, isTrue);
    expect(q.canSubmit, isFalse);
    final open = Quiz.fromJson({'id': 'z', 'title': 'q'});
    expect(open.kind, 'quiz');
    expect(open.canSubmit, isTrue);
    expect(Quiz.fromJson({'id': 'z', 'title': 'q', 'closed': true}).canSubmit, isFalse);
  });

  test('Question.fromJson converts options to strings and detects essay', () {
    final q = Question.fromJson({'id': '1', 'body': '1+1', 'options': [1, 2, 3], 'points': 2});
    expect(q.options, ['1', '2', '3']);
    expect(q.points, 2);
    expect(q.isEssay, isFalse);
    expect(Question.fromJson({'id': '2', 'body': 'b', 'kind': 'essay'}).isEssay, isTrue);
  });

  test('SubmitResult and Attempt', () {
    final r = SubmitResult.fromJson({'id': 's', 'score': 3, 'mcqTotal': 4, 'hasEssay': true});
    expect(r.hasEssay, isTrue);
    expect(r.mcqTotal, 4);
    final a = Attempt.fromJson({'id': 'a', 'score': 2, 'essayScore': null, 'feedback': 'ok', 'createdAt': '2026-01-01T09:00:00.000Z'});
    expect(a.essayScore, isNull);
    expect(a.feedback, 'ok');
    expect(a.createdAt, DateTime.utc(2026, 1, 1, 9));
  });

  test('Review.fromJson: hidden answers keep correctIndex null', () {
    final r = Review.fromJson({
      'score': 1,
      'mcqTotal': 2,
      'essayScore': null,
      'essayTotal': 5,
      'essayPending': true,
      'feedback': null,
      'answersVisible': false,
      'items': [
        {'questionId': 'q1', 'kind': 'mcq', 'body': 'b', 'options': ['x', 'y'], 'points': 1, 'yourAnswer': 1, 'correctIndex': null},
        {'questionId': 'q2', 'kind': 'essay', 'body': 'e', 'options': null, 'points': 5, 'yourAnswer': 'نص', 'correctIndex': null},
      ],
    });
    expect(r.answersVisible, isFalse);
    expect(r.essayPending, isTrue);
    expect(r.items, hasLength(2));
    expect(r.items[0].correctIndex, isNull);
    expect(r.items[0].chosenIndex, 1);
    expect(r.items[1].isEssay, isTrue);
    expect(r.items[1].yourAnswer, 'نص');
  });

  test('AppNotification.fromJson and copyWith', () {
    final n = AppNotification.fromJson({
      'id': 'n1',
      'type': 'graded',
      'title': 't',
      'body': 'b',
      'data': {'submissionId': 's1'},
      'read': false,
      'createdAt': '2026-01-01T00:00:00.000Z',
    });
    expect(n.data['submissionId'], 's1');
    expect(n.read, isFalse);
    expect(n.copyWith(read: true).read, isTrue);
    expect(n.copyWith(read: true).title, 't');
  });

  test('RedeemResult.fromJson', () {
    final r = RedeemResult.fromJson({'courseId': 'c1', 'expiresAt': '2026-12-31T12:00:00.000Z'});
    expect(r.courseId, 'c1');
    expect(r.expiresAt, DateTime.utc(2026, 12, 31, 12));
  });
}
