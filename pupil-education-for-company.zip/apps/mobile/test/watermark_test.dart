import 'package:edu_student/core/watermark.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Alignment currentAlignment(WidgetTester t) => t.widget<AnimatedAlign>(find.byType(AnimatedAlign)).alignment as Alignment;

void main() {
  test('positions are deterministic and stay inside the box', () {
    for (var step = 0; step < 200; step++) {
      final a = watermarkAlignment(step, seed: 'منى 0101');
      final b = watermarkAlignment(step, seed: 'منى 0101');
      expect(a, b);
      expect(a.x, inInclusiveRange(-1.0, 1.0));
      expect(a.y, inInclusiveRange(-1.0, 1.0));
    }
  });

  test('consecutive steps never land on the same spot (left/right halves alternate)', () {
    for (var step = 0; step < 200; step++) {
      final a = watermarkAlignment(step, seed: 's');
      final b = watermarkAlignment(step + 1, seed: 's');
      expect(a, isNot(b));
      expect(step.isEven ? a.x < 0 : a.x > 0, isTrue);
    }
  });

  test('different seeds usually give different tracks', () {
    final tracks = <String>{
      for (final seed in ['a', 'b', 'c', 'd', 'e']) '${watermarkAlignment(3, seed: seed)}',
    };
    expect(tracks.length, greaterThan(1));
  });

  testWidgets('shows the text and moves every interval', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Watermark(text: 'طالب - 0101', interval: Duration(seconds: 10), child: SizedBox(width: 300, height: 200)),
    ));
    expect(find.text('طالب - 0101'), findsOneWidget);
    final first = currentAlignment(tester);
    expect(first, watermarkAlignment(0, seed: 'طالب - 0101'));
    await tester.pump(const Duration(seconds: 9));
    expect(currentAlignment(tester), first);
    await tester.pump(const Duration(seconds: 2));
    expect(currentAlignment(tester), watermarkAlignment(1, seed: 'طالب - 0101'));
    await tester.pumpAndSettle();
  });

  testWidgets('empty text renders only the child', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Watermark(text: '  ', child: Text('video'))));
    expect(find.text('video'), findsOneWidget);
    expect(find.byType(AnimatedAlign), findsNothing);
  });

  testWidgets('does not block touches on the child', (tester) async {
    var taps = 0;
    await tester.pumpWidget(MaterialApp(
      home: Watermark(
        text: 'x',
        child: GestureDetector(key: const Key('target'), onTap: () => taps++, child: const ColoredBox(color: Colors.black)),
      ),
    ));
    await tester.tap(find.byKey(const Key('target')));
    expect(taps, 1);
  });
}
