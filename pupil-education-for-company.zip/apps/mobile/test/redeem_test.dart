import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/features/redeem/redeem_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

Future<void> redeem(WidgetTester tester, String code) async {
  await tester.enterText(find.byType(TextField), code);
  await tester.tap(find.byType(FilledButton));
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('success shows the expiry date and notifies the shell', (tester) async {
    final fakes = Fakes();
    var notified = 0;
    await fakes.pump(tester, RedeemPage(onRedeemed: () => notified++));
    await redeem(tester, ' abc123 ');
    expect(fakes.redeem.codes, [' abc123 ']);
    expect(find.textContaining('2026/12/31'), findsOneWidget);
    expect(notified, 1);
  });

  testWidgets('invalid code', (tester) async {
    final fakes = Fakes();
    fakes.redeem.error = const ApiException(404, 'invalid_code', '');
    await fakes.pump(tester, const RedeemPage());
    await redeem(tester, 'BAD');
    expect(find.textContaining('غير صحيح'), findsOneWidget);
  });

  testWidgets('rate limit', (tester) async {
    final fakes = Fakes();
    fakes.redeem.error = const ApiException(429, 'too_many_attempts', '');
    await fakes.pump(tester, const RedeemPage());
    await redeem(tester, 'BAD');
    expect(find.textContaining('محاولات كتير'), findsOneWidget);
  });

  testWidgets('network error and empty input', (tester) async {
    final fakes = Fakes();
    fakes.redeem.error = const ApiException(0, 'network', '');
    await fakes.pump(tester, const RedeemPage());
    await tester.tap(find.byType(FilledButton));
    await tester.pumpAndSettle();
    expect(fakes.redeem.codes, isEmpty);
    await redeem(tester, 'X');
    expect(find.textContaining('اتصال'), findsOneWidget);
  });
}
