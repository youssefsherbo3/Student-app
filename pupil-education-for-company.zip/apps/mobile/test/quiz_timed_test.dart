import 'dart:convert';

import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/core/image_picker_service.dart';
import 'package:edu_student/features/quizzes/quiz_models.dart';
import 'package:edu_student/features/quizzes/quiz_page.dart';
import 'package:edu_student/features/quizzes/quizzes_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

import 'helpers/fakes.dart';
import 'helpers/http.dart';

const timedQuiz = Quiz(id: 'z1', title: 'امتحان بوقت', timeLimitMinutes: 1);
const q1 = Question(id: 'q1', body: 'سؤال أول', options: ['خيار ١', 'خيار ٢']);

QuizStart startAt(DateTime clock, int seconds, {List<Question> questions = const [q1]}) =>
    QuizStart(sessionId: 'sess1', endsAt: clock.add(Duration(seconds: seconds)), serverNow: clock, questions: questions);

void main() {
  group('QuizCountdown', () {
    final end = DateTime.utc(2026, 1, 1, 10, 0, 30);

    test('counts whole seconds, rounding up, never below zero', () {
      final c = QuizCountdown(endsAt: end, serverNow: DateTime.utc(2026, 1, 1, 10), deviceNow: DateTime.utc(2026, 1, 1, 10));
      expect(c.remainingSeconds(DateTime.utc(2026, 1, 1, 10)), 30);
      expect(c.remainingSeconds(DateTime.utc(2026, 1, 1, 10, 0, 0, 400)), 30);
      expect(c.remainingSeconds(DateTime.utc(2026, 1, 1, 10, 0, 29, 100)), 1);
      expect(c.remainingSeconds(end), 0);
      expect(c.remainingSeconds(end.add(const Duration(minutes: 5))), 0);
      expect(c.isExpired(DateTime.utc(2026, 1, 1, 10, 0, 29)), isFalse);
      expect(c.isExpired(end), isTrue);
    });

    test('corrects for a device clock that is ahead or behind the server', () {
      final server = DateTime.utc(2026, 1, 1, 10);
      // Device clock is 5 minutes ahead of the server.
      final ahead = server.add(const Duration(minutes: 5));
      final c = QuizCountdown(endsAt: end, serverNow: server, deviceNow: ahead);
      expect(c.remainingSeconds(ahead), 30);
      expect(c.remainingSeconds(ahead.add(const Duration(seconds: 10))), 20);
      // Device clock is 2 minutes behind.
      final behind = server.subtract(const Duration(minutes: 2));
      final d = QuizCountdown(endsAt: end, serverNow: server, deviceNow: behind);
      expect(d.remainingSeconds(behind.add(const Duration(seconds: 30))), 0);
    });

    test('without serverNow the device clock is trusted', () {
      final c = QuizCountdown(endsAt: end, deviceNow: DateTime.utc(2026, 1, 1, 10));
      expect(c.remainingSeconds(DateTime.utc(2026, 1, 1, 10, 0, 20)), 10);
    });
  });

  group('models', () {
    test('QuizStart maps a timed session and questions with images', () {
      final s = QuizStart.fromJson({
        'sessionId': 'sess1',
        'endsAt': '2026-01-01T10:30:00.000Z',
        'serverNow': '2026-01-01T10:00:00.000Z',
        'questions': [
          {'id': 'q1', 'kind': 'mcq', 'body': 'س', 'imageUrl': '/files/public/a.png', 'options': ['أ', 'ب'], 'points': 2, 'position': 0},
          {'id': 'q2', 'kind': 'essay', 'body': 'ص', 'imageUrl': null, 'options': [], 'points': 5, 'position': 1},
        ],
      });
      expect(s.isTimed, isTrue);
      expect(s.sessionId, 'sess1');
      expect(s.endsAt, DateTime.utc(2026, 1, 1, 10, 30));
      expect(s.serverNow, DateTime.utc(2026, 1, 1, 10));
      expect(s.questions, hasLength(2));
      expect(s.questions[0].imageUrl, '/files/public/a.png');
      expect(s.questions[0].options, ['أ', 'ب']);
      expect(s.questions[1].imageUrl, isNull);
      expect(s.questions[1].isEssay, isTrue);
    });

    test('QuizStart for an untimed quiz has no session', () {
      final s = QuizStart.fromJson({'sessionId': null, 'endsAt': null, 'serverNow': '2026-01-01T10:00:00.000Z', 'questions': []});
      expect(s.isTimed, isFalse);
      expect(s.sessionId, isNull);
      expect(s.endsAt, isNull);
    });

    test('Quiz.timeLimitMinutes and ReviewItem images', () {
      expect(Quiz.fromJson({'id': 'a', 'title': 't', 'timeLimitMinutes': 20}).isTimed, isTrue);
      expect(Quiz.fromJson({'id': 'a', 'title': 't', 'timeLimitMinutes': null}).isTimed, isFalse);
      final it = ReviewItem.fromJson({
        'questionId': 'q',
        'kind': 'essay',
        'body': 'b',
        'imageUrl': '/files/public/q.png',
        'yourImages': ['u1', 'u2'],
      });
      expect(it.imageUrl, '/files/public/q.png');
      expect(it.yourImages, ['u1', 'u2']);
      expect(ReviewItem.fromJson({'questionId': 'q', 'body': 'b'}).yourImages, isEmpty);
    });
  });

  group('HttpQuizzesRepository', () {
    test('start posts to /quizzes/:id/start and maps the response', () async {
      http.Request? seen;
      final mock = MockClient((req) async {
        seen = req;
        return jsonResponse(200, {
          'sessionId': 's9',
          'endsAt': '2026-01-01T10:30:00.000Z',
          'serverNow': '2026-01-01T10:00:00.000Z',
          'questions': [
            {'id': 'q1', 'kind': 'mcq', 'body': 'س', 'options': ['أ', 'ب'], 'points': 1, 'position': 0},
          ],
        });
      });
      final s = await HttpQuizzesRepository(makeApi(mock)).start('z1');
      expect(seen!.method, 'POST');
      expect(seen!.url.path, '/api/v1/quizzes/z1/start');
      expect(s.sessionId, 's9');
      expect(s.questions.single.id, 'q1');
    });

    test('submit sends sessionId, displayed positions and images', () async {
      Map<String, dynamic>? body;
      final mock = MockClient((req) async {
        expect(req.url.path, '/api/v1/quizzes/z1/submit');
        body = jsonDecode(req.body) as Map<String, dynamic>;
        return jsonResponse(201, {'id': 'sub1', 'score': 3, 'mcqTotal': 4, 'hasEssay': true});
      });
      final r = await HttpQuizzesRepository(makeApi(mock)).submit(
        'z1',
        {'q1': 1, 'q2': 'نص'},
        sessionId: 'sess1',
        images: {
          'q3': ['up1', 'up2'],
        },
      );
      expect(body, {
        'answers': {'q1': 1, 'q2': 'نص'},
        'sessionId': 'sess1',
        'images': {
          'q3': ['up1', 'up2'],
        },
      });
      expect(r.id, 'sub1');
      expect(r.score, 3);
      expect(r.hasEssay, isTrue);
    });

    test('untimed submit sends only the answers', () async {
      Map<String, dynamic>? body;
      final mock = MockClient((req) async {
        body = jsonDecode(req.body) as Map<String, dynamic>;
        return jsonResponse(201, {'id': 's', 'score': 0, 'mcqTotal': 1, 'hasEssay': false});
      });
      await HttpQuizzesRepository(makeApi(mock)).submit('z1', {'q1': 0});
      expect(body, {
        'answers': {'q1': 0},
      });
    });

    test('time_over surfaces as an ApiException with the Arabic message mapped', () async {
      final mock = MockClient((req) async => jsonResponse(409, {
            'error': {'code': 'time_over', 'message': 'x'},
          }));
      await expectLater(
        HttpQuizzesRepository(makeApi(mock)).submit('z1', {}, sessionId: 's'),
        throwsA(isA<ApiException>().having((e) => e.code, 'code', 'time_over')),
      );
    });
  });

  group('QuizPage (timed)', () {
    testWidgets('shows an intro and only starts the session after the student confirms', (tester) async {
      final fakes = Fakes();
      final clock = DateTime.utc(2026, 1, 1, 10);
      fakes.quizzes.startOverride = startAt(clock, 60);
      await fakes.pumpPushed(tester, QuizPage(quiz: timedQuiz, now: () => clock));
      expect(find.textContaining('1 دقيقة'), findsOneWidget);
      expect(fakes.quizzes.startCalls, 0);
      await tester.tap(find.text('ابدأ الامتحان'));
      await tester.pump();
      await tester.pump();
      expect(fakes.quizzes.startCalls, 1);
      expect(find.text('الوقت المتبقي: 1:00'), findsOneWidget);
      expect(find.text('سؤال أول', skipOffstage: false), findsNothing); // body is prefixed by its number
      expect(find.textContaining('1) سؤال أول'), findsOneWidget);
      // leave the page so the periodic timer is disposed
      await tester.pumpWidget(const SizedBox());
    });

    testWidgets('counts down and auto-submits the answers when time ends, with the sessionId', (tester) async {
      final fakes = Fakes();
      var clock = DateTime.utc(2026, 1, 1, 10);
      fakes.quizzes.startOverride = startAt(clock, 3);
      await fakes.pumpPushed(tester, QuizPage(quiz: timedQuiz, now: () => clock));
      await tester.tap(find.text('ابدأ الامتحان'));
      await tester.pump();
      await tester.pump();
      expect(find.text('الوقت المتبقي: 0:03'), findsOneWidget);
      await tester.tap(find.text('خيار ٢'));
      await tester.pump();

      clock = clock.add(const Duration(seconds: 1));
      await tester.pump(const Duration(seconds: 1));
      expect(find.text('الوقت المتبقي: 0:02'), findsOneWidget);
      expect(fakes.quizzes.submitCalls, 0);

      clock = clock.add(const Duration(seconds: 2));
      await tester.pump(const Duration(seconds: 1));
      await tester.pump(const Duration(seconds: 1));
      await tester.pumpAndSettle();

      expect(fakes.quizzes.submitCalls, 1);
      expect(fakes.quizzes.submitted, {'q1': 1});
      expect(fakes.quizzes.submittedSessionId, 'sess1');
      expect(find.text('انتهى الوقت وتم تسليم إجاباتك'), findsOneWidget);
      await tester.tap(find.text('تمام'));
      await tester.pumpAndSettle();
      expect(find.byType(QuizPage), findsNothing);
    });

    testWidgets('auto-submit works even when nothing was answered', (tester) async {
      final fakes = Fakes();
      var clock = DateTime.utc(2026, 1, 1, 10);
      fakes.quizzes.startOverride = startAt(clock, 2);
      await fakes.pumpPushed(tester, QuizPage(quiz: timedQuiz, now: () => clock));
      await tester.tap(find.text('ابدأ الامتحان'));
      await tester.pump();
      await tester.pump();
      clock = clock.add(const Duration(seconds: 2));
      await tester.pump(const Duration(seconds: 1));
      await tester.pump(const Duration(seconds: 1));
      await tester.pumpAndSettle();
      expect(fakes.quizzes.submitCalls, 1);
      expect(fakes.quizzes.submitted, isEmpty);
      expect(fakes.quizzes.submittedSessionId, 'sess1');
    });

    testWidgets('a deadline that already passed (device clock skew handled) submits straight away', (tester) async {
      final fakes = Fakes();
      final clock = DateTime.utc(2026, 1, 1, 10);
      // Server says it is already past endsAt.
      fakes.quizzes.startOverride = QuizStart(
        sessionId: 'sess1',
        endsAt: clock.subtract(const Duration(seconds: 5)),
        serverNow: clock,
        questions: const [q1],
      );
      await fakes.pumpPushed(tester, QuizPage(quiz: timedQuiz, now: () => clock));
      await tester.tap(find.text('ابدأ الامتحان'));
      await tester.pump();
      await tester.pump();
      await tester.pumpAndSettle();
      expect(fakes.quizzes.submitCalls, 1);
    });

    testWidgets('time_over from the server explains and leaves the page', (tester) async {
      final fakes = Fakes();
      final clock = DateTime.utc(2026, 1, 1, 10);
      fakes.quizzes.startOverride = startAt(clock, 60);
      fakes.quizzes.submitError = const ApiException(409, 'time_over', '');
      await fakes.pumpPushed(tester, QuizPage(quiz: timedQuiz, now: () => clock));
      await tester.tap(find.text('ابدأ الامتحان'));
      await tester.pump();
      await tester.pump();
      await tester.tap(find.text('خيار ١'));
      await tester.pump();
      await tester.tap(find.byType(FilledButton));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));
      expect(find.text('انتهى وقت الامتحان.'), findsOneWidget);
      await tester.tap(find.text('تمام'));
      await tester.pumpAndSettle();
      expect(find.byType(QuizPage), findsNothing);
    });

    testWidgets('no_session / session_required / not_started also end the attempt', (tester) async {
      for (final code in ['no_session', 'session_required', 'not_started']) {
        final fakes = Fakes();
        final clock = DateTime.utc(2026, 1, 1, 10);
        fakes.quizzes.startOverride = startAt(clock, 60);
        fakes.quizzes.submitError = ApiException(409, code, '');
        await fakes.pumpPushed(tester, QuizPage(quiz: timedQuiz, now: () => clock));
        await tester.tap(find.text('ابدأ الامتحان'));
        await tester.pump();
        await tester.pump();
        await tester.tap(find.text('خيار ٢'));
        await tester.pump();
        await tester.tap(find.byType(FilledButton));
        await tester.pump();
        await tester.pump(const Duration(milliseconds: 100));
        expect(find.byType(AlertDialog), findsOneWidget, reason: code);
        await tester.tap(find.text('تمام'));
        await tester.pumpAndSettle();
        expect(find.byType(QuizPage), findsNothing, reason: code);
      }
    });

    testWidgets('a start error is shown with a retry that starts again', (tester) async {
      final fakes = Fakes();
      await fakes.pumpPushed(tester, QuizPage(quiz: timedQuiz, now: () => DateTime.utc(2026)));
      final repo = _FailingOnceStart(fakes.quizzes);
      // Replace the repository with one whose first start() fails (needs a fresh scope).
      await tester.pumpWidget(const SizedBox());
      final f2 = Fakes();
      f2.quizzes.startOverride = null;
      await f2.pump(tester, QuizPage(quiz: timedQuiz, now: () => DateTime.utc(2026)));
      expect(repo, isNotNull);
      await tester.tap(find.text('ابدأ الامتحان'));
      await tester.pump();
      await tester.pump();
      // Untimed fake start works: questions shown (no countdown because there is no session).
      expect(find.textContaining('الوقت المتبقي'), findsNothing);
      expect(find.textContaining('سؤال أول'), findsOneWidget);
    });
  });

  group('QuizPage (untimed)', () {
    testWidgets('starts immediately, shows no countdown and submits without a session', (tester) async {
      final fakes = Fakes();
      await fakes.pumpPushed(tester, const QuizPage(quiz: Quiz(id: 'z1', title: 'عادي')));
      expect(fakes.quizzes.startCalls, 1);
      expect(find.textContaining('الوقت المتبقي'), findsNothing);
      await tester.tap(find.text('خيار ٢'));
      await tester.tap(find.text('خيار ٤'));
      await tester.pump();
      await tester.tap(find.byType(FilledButton));
      await tester.pumpAndSettle();
      expect(fakes.quizzes.submittedSessionId, isNull);
      expect(fakes.quizzes.submittedImages, isEmpty);
      expect(fakes.quizzes.submitted, {'q1': 1, 'q2': 1});
    });
  });

  group('QuizPage essay photos and question images', () {
    testWidgets('a photo satisfies an essay, is uploaded as kind=answer and sent in images', (tester) async {
      final fakes = Fakes();
      fakes.quizzes.withEssay = true;
      await fakes.pumpPushed(tester, const QuizPage(quiz: Quiz(id: 'z1', title: 'امتحان')));
      await tester.tap(find.text('خيار ١'));
      await tester.tap(find.text('خيار ٣'));
      await tester.pump();
      expect(tester.widget<FilledButton>(find.byType(FilledButton)).onPressed, isNull);

      await tester.tap(find.text('صورة من المعرض'));
      await tester.pumpAndSettle();
      expect(fakes.uploads.kinds, ['answer']);
      expect(tester.widget<FilledButton>(find.byType(FilledButton)).onPressed, isNotNull);

      await tester.tap(find.byType(FilledButton));
      await tester.pumpAndSettle();
      expect(fakes.quizzes.submitted, {'q1': 0, 'q2': 0});
      expect(fakes.quizzes.submittedImages, {
        'q3': ['up1'],
      });
    });

    testWidgets('text and photo can be combined; removing the photo drops it from the request', (tester) async {
      final fakes = Fakes();
      fakes.quizzes.withEssay = true;
      await fakes.pumpPushed(tester, const QuizPage(quiz: Quiz(id: 'z1', title: 'امتحان')));
      await tester.tap(find.text('خيار ١'));
      await tester.tap(find.text('خيار ٣'));
      await tester.enterText(find.byType(TextField), 'شرح');
      await tester.tap(find.text('تصوير'));
      await tester.pumpAndSettle();
      expect(fakes.picker.sources, [ImagePickSourceCamera.value]);
      await tester.tap(find.byIcon(Icons.close));
      await tester.pump();
      await tester.tap(find.byType(FilledButton));
      await tester.pumpAndSettle();
      expect(fakes.quizzes.submitted!['q3'], 'شرح');
      expect(fakes.quizzes.submittedImages, isEmpty);
    });

    testWidgets('a cancelled picker adds nothing', (tester) async {
      final fakes = Fakes();
      fakes.quizzes.withEssay = true;
      fakes.picker.next = null;
      await fakes.pump(tester, const QuizPage(quiz: Quiz(id: 'z1', title: 'امتحان')));
      await tester.tap(find.text('صورة من المعرض'));
      await tester.pumpAndSettle();
      expect(fakes.uploads.kinds, isEmpty);
    });

    testWidgets('a failed upload shows the error and keeps the essay unanswered', (tester) async {
      final fakes = Fakes();
      fakes.quizzes.withEssay = true;
      fakes.uploads.error = const ApiException(0, 'network', '');
      await fakes.pump(tester, const QuizPage(quiz: Quiz(id: 'z1', title: 'امتحان')));
      await tester.tap(find.text('خيار ١'));
      await tester.tap(find.text('خيار ٣'));
      await tester.tap(find.text('صورة من المعرض'));
      await tester.pumpAndSettle();
      expect(find.textContaining('مفيش اتصال'), findsOneWidget);
      expect(tester.widget<FilledButton>(find.byType(FilledButton)).onPressed, isNull);
    });

    testWidgets('a question picture is shown with a fallback when it cannot load', (tester) async {
      final fakes = Fakes();
      fakes.quizzes.startOverride = const QuizStart(questions: [
        Question(id: 'q1', body: 'سؤال بصورة', options: ['أ', 'ب'], imageUrl: '/files/public/q.png'),
      ]);
      await fakes.pump(tester, const QuizPage(quiz: Quiz(id: 'z1', title: 'امتحان')));
      expect(find.byType(Image), findsOneWidget);
      final img = tester.widget<Image>(find.byType(Image));
      expect(img.errorBuilder, isNotNull);
      expect((img.image as NetworkImage).url, endsWith('/files/public/q.png'));
      expect((img.image as NetworkImage).url, startsWith('http'));
    });
  });
}

/// Placeholder kept so the start-error test above can document intent; see the repository tests for real errors.
class _FailingOnceStart {
  _FailingOnceStart(this.inner);

  final FakeQuizzesRepository inner;
}

/// Camera source helper for readability in assertions.
class ImagePickSourceCamera {
  const ImagePickSourceCamera._();

  static const value = ImagePickSource.camera;
}
