import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/features/lessons/lesson_models.dart';
import 'package:edu_student/features/lessons/lesson_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

const lesson = Lesson(id: 'l2', title: 'الدرس الثاني', videoUrl: 'https://youtu.be/abc123');

Widget page([Lesson l = lesson]) =>
    LessonPage(lesson: l, videoBuilder: (context, url) => Text('VIDEO:$url'));

FilledButton button(WidgetTester t) => t.widget<FilledButton>(find.byType(FilledButton));

void main() {
  testWidgets('calls start, embeds the video and counts down to enable completion', (tester) async {
    final fakes = Fakes();
    fakes.lessons.remainingSeconds = 3;
    await fakes.pumpPushed(tester, page(), settle: false);
    expect(fakes.lessons.started, ['l2']);
    expect(find.textContaining('youtube-nocookie.com/embed/abc123'), findsOneWidget);
    expect(find.text('متاح بعد 0:03'), findsOneWidget);
    expect(button(tester).onPressed, isNull);

    await tester.pump(const Duration(seconds: 1));
    expect(find.text('متاح بعد 0:02'), findsOneWidget);
    await tester.pump(const Duration(seconds: 2));
    expect(find.text('خلّصت الدرس'), findsOneWidget);
    expect(button(tester).onPressed, isNotNull);

    await tester.tap(find.byType(FilledButton));
    await tester.pumpAndSettle();
    expect(fakes.lessons.completed, ['l2']);
    expect(find.byType(LessonPage), findsNothing);
  });

  testWidgets('too_early shows the message and resyncs with the server', (tester) async {
    final fakes = Fakes();
    fakes.lessons.completeError = const ApiException(409, 'too_early', '');
    await fakes.pumpPushed(tester, page());
    await tester.tap(find.byType(FilledButton));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.textContaining('لسه ما خلصتش المدة'), findsOneWidget);
    expect(fakes.lessons.started.length, 2);
    expect(fakes.lessons.completed, isEmpty);
    expect(find.byType(LessonPage), findsOneWidget);
  });

  testWidgets('locked lesson never calls start', (tester) async {
    final fakes = Fakes();
    await fakes.pumpPushed(tester, page(const Lesson(id: 'l1', title: 'مقفول', locked: true)));
    expect(fakes.lessons.started, isEmpty);
    expect(find.text('الدرس ده لسه مقفول.'), findsOneWidget);
  });

  testWidgets('unsupported video link shows a notice', (tester) async {
    final fakes = Fakes();
    await fakes.pumpPushed(tester, page(const Lesson(id: 'l3', title: 'x', videoUrl: 'https://example.com/a.mp4')));
    expect(find.textContaining('غير مدعوم'), findsOneWidget);
  });

  testWidgets('no wait time means completion is enabled immediately', (tester) async {
    final fakes = Fakes();
    await fakes.pumpPushed(tester, page());
    expect(find.text('خلّصت الدرس'), findsOneWidget);
    expect(button(tester).onPressed, isNotNull);
  });
}
