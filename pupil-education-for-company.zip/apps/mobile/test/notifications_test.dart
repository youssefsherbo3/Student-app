import 'package:edu_student/features/notifications/notification_models.dart';
import 'package:edu_student/features/notifications/notifications_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

void main() {
  testWidgets('lists notifications; unread ones are bold with a dot', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const NotificationsPage());
    expect(find.text('درس جديد'), findsOneWidget);
    expect(find.text('تم تفعيل اشتراكك'), findsOneWidget);
    expect(tester.widget<Text>(find.text('درس جديد')).style?.fontWeight, FontWeight.bold);
    expect(tester.widget<Text>(find.text('تم تفعيل اشتراكك')).style?.fontWeight, FontWeight.normal);
    expect(find.byIcon(Icons.circle), findsOneWidget);
  });

  testWidgets('tapping an unread notification marks it read', (tester) async {
    final fakes = Fakes();
    var changed = 0;
    await fakes.pump(tester, NotificationsPage(onChanged: () => changed++));
    await tester.tap(find.text('درس جديد'));
    await tester.pumpAndSettle();
    expect(fakes.notifications.readIds, ['n1']);
    expect(changed, 1);
    expect(find.byIcon(Icons.circle), findsNothing);
  });

  testWidgets('read-all clears unread state and hides the button', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const NotificationsPage());
    await tester.tap(find.text('قراءة الكل'));
    await tester.pumpAndSettle();
    expect(fakes.notifications.readAll, isTrue);
    expect(find.text('قراءة الكل'), findsNothing);
    expect(find.byIcon(Icons.circle), findsNothing);
  });

  testWidgets('empty state', (tester) async {
    final fakes = Fakes();
    fakes.notifications.items = <AppNotification>[];
    await fakes.pump(tester, const NotificationsPage());
    expect(find.text('مفيش إشعارات.'), findsOneWidget);
  });
}
