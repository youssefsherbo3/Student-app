import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/features/quizzes/attempts_page.dart';
import 'package:edu_student/features/quizzes/quiz_models.dart';
import 'package:edu_student/features/quizzes/quiz_page.dart';
import 'package:edu_student/features/quizzes/review_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

const quiz = Quiz(id: 'z1', title: 'امتحان');

FilledButton submitButton(WidgetTester t) => t.widget<FilledButton>(find.byType(FilledButton));

void main() {
  testWidgets('submit is disabled until every question is answered', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const QuizPage(quiz: quiz));
    expect(submitButton(tester).onPressed, isNull);
    await tester.tap(find.text('خيار ٢'));
    await tester.pump();
    expect(submitButton(tester).onPressed, isNull);
    await tester.tap(find.text('خيار ٤'));
    await tester.pump();
    expect(submitButton(tester).onPressed, isNotNull);
  });

  testWidgets('submitting sends option indexes and shows the score', (tester) async {
    final fakes = Fakes();
    await fakes.pumpPushed(tester, const QuizPage(quiz: quiz));
    await tester.tap(find.text('خيار ٢'));
    await tester.tap(find.text('خيار ٣'));
    await tester.pump();
    await tester.tap(find.byType(FilledButton));
    await tester.pumpAndSettle();
    expect(fakes.quizzes.submitted, {'q1': 1, 'q2': 0});
    expect(find.textContaining('1 / 2'), findsOneWidget);
    expect(find.textContaining('50%'), findsOneWidget);
    await tester.tap(find.text('تمام'));
    await tester.pumpAndSettle();
    expect(find.byType(QuizPage), findsNothing);
  });

  testWidgets('essay needs text and is sent as a trimmed string', (tester) async {
    final fakes = Fakes();
    fakes.quizzes.withEssay = true;
    fakes.quizzes.submitResult = const SubmitResult(id: 's1', score: 2, mcqTotal: 2, hasEssay: true);
    await fakes.pumpPushed(tester, const QuizPage(quiz: quiz));
    await tester.tap(find.text('خيار ١'));
    await tester.tap(find.text('خيار ٤'));
    await tester.pump();
    expect(submitButton(tester).onPressed, isNull);
    await tester.enterText(find.byType(TextField), '  إجابتي  ');
    await tester.pump();
    expect(submitButton(tester).onPressed, isNotNull);
    await tester.tap(find.byType(FilledButton));
    await tester.pumpAndSettle();
    expect(fakes.quizzes.submitted!['q3'], 'إجابتي');
    expect(fakes.quizzes.submitted!['q1'], 0);
    expect(find.textContaining('المقالية'), findsOneWidget);
  });

  testWidgets('clearing the essay disables submit again', (tester) async {
    final fakes = Fakes();
    fakes.quizzes.withEssay = true;
    await fakes.pump(tester, const QuizPage(quiz: quiz));
    await tester.tap(find.text('خيار ١'));
    await tester.tap(find.text('خيار ٣'));
    await tester.enterText(find.byType(TextField), 'x');
    await tester.pump();
    expect(submitButton(tester).onPressed, isNotNull);
    await tester.enterText(find.byType(TextField), '   ');
    await tester.pump();
    expect(submitButton(tester).onPressed, isNull);
  });

  testWidgets('server rejection shows a message and keeps the page', (tester) async {
    final fakes = Fakes();
    fakes.quizzes.submitError = const ApiException(409, 'closed', '');
    await fakes.pump(tester, const QuizPage(quiz: quiz));
    await tester.tap(find.text('خيار ١'));
    await tester.tap(find.text('خيار ٣'));
    await tester.pump();
    await tester.tap(find.byType(FilledButton));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('الامتحان ده اتقفل.'), findsOneWidget);
    expect(submitButton(tester).onPressed, isNotNull);
  });

  testWidgets('closed quiz cannot be taken', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const QuizPage(quiz: Quiz(id: 'z', title: 'ق', closed: true)));
    expect(find.byType(FilledButton), findsNothing);
    expect(find.textContaining('اتقفل'), findsOneWidget);
  });

  testWidgets('attempts are numbered oldest-first and open the review', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const AttemptsPage(quiz: quiz));
    expect(find.text('المحاولة 2: 2 + مقالي 4'), findsOneWidget);
    expect(find.text('المحاولة 1: 1'), findsOneWidget);
    await tester.tap(find.text('المحاولة 1: 1'));
    await tester.pumpAndSettle();
    expect(find.byType(ReviewPage), findsOneWidget);
  });

  testWidgets('empty attempts', (tester) async {
    final fakes = Fakes();
    fakes.quizzes.attemptList = [];
    await fakes.pump(tester, const AttemptsPage(quiz: quiz));
    expect(find.textContaining('لسه ما سلّمتش'), findsOneWidget);
  });

  testWidgets('review hides correct answers and flags pending essay', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const ReviewPage(submissionId: 'a1'));
    expect(find.textContaining('هتظهر بعد انتهاء'), findsOneWidget);
    expect(find.text('بانتظار تصحيح المساعد'), findsOneWidget);
    expect(find.textContaining('ملاحظة المصحّح'), findsOneWidget);
    expect(find.byIcon(Icons.check_circle), findsNothing);
    expect(find.byIcon(Icons.cancel), findsNothing);
    expect(find.text('إجابتك: إجابتي'), findsOneWidget);
  });

  testWidgets('review marks right and wrong when answers are visible', (tester) async {
    final fakes = Fakes();
    fakes.quizzes.reviewResult = const Review(
      score: 0,
      mcqTotal: 1,
      essayScore: null,
      essayTotal: 0,
      essayPending: false,
      answersVisible: true,
      items: [
        ReviewItem(questionId: 'q1', kind: 'mcq', body: 'س', options: ['أ', 'ب'], yourAnswer: '0', correctIndex: 1),
      ],
    );
    await fakes.pump(tester, const ReviewPage(submissionId: 'a1'));
    expect(find.textContaining('هتظهر بعد انتهاء'), findsNothing);
    expect(find.byIcon(Icons.check_circle), findsOneWidget);
    expect(find.byIcon(Icons.cancel), findsOneWidget);
  });
}
