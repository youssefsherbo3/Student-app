import 'package:edu_student/features/help/help_guide_page.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

void main() {
  testWidgets('guide explains the main student steps in Arabic', (
    tester,
  ) async {
    final fakes = Fakes();
    await fakes.pump(tester, const HelpGuidePage());

    expect(find.text('دليل استخدام المنصة'), findsOneWidget);
    expect(find.text('تفعيل الاشتراك'), findsOneWidget);
    expect(find.text('مشاهدة الحصة'), findsOneWidget);
    expect(find.text('الامتحان والواجب المرتبط بالحصة'), findsOneWidget);
  });
}
