import 'dart:convert';
import 'dart:typed_data';

import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/core/image_picker_service.dart';
import 'package:edu_student/features/uploads/uploads_repository.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

import 'helpers/http.dart';

final Uint8List png = base64Decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==');

void main() {
  test('upload sends a multipart request with field "file", kind in the query and auth + device headers', () async {
    http.Request? seen;
    final mock = MockClient((req) async {
      seen = req;
      return jsonResponse(201, {'id': 'up1', 'url': null});
    });
    final repo = HttpUploadsRepository(makeApi(mock));

    final res = await repo.upload(PickedImage(bytes: png, name: 'صورة الإجابة.PNG'), UploadKind.answer);

    expect(res.id, 'up1');
    expect(res.url, isNull);
    final req = seen!;
    expect(req.method, 'POST');
    expect(req.url.path, '/api/v1/uploads');
    expect(req.url.queryParameters, {'kind': 'answer'});
    expect(req.headers['Content-Type'], startsWith('multipart/form-data; boundary='));
    expect(req.headers['X-Device-Id'], testDeviceId);
    expect(req.headers['Authorization'], 'Bearer A1');
    final body = latin1.decode(req.bodyBytes);
    expect(body, contains('name="file"'));
    expect(body, contains('filename="image.png"')); // arabic stem sanitised, extension from the real content
    expect(body.toLowerCase(), contains('content-type: image/png'));
  });

  test('avatar upload returns the public url', () async {
    final mock = MockClient((req) async {
      expect(req.url.queryParameters['kind'], 'avatar');
      return jsonResponse(201, {'id': 'up2', 'url': '/files/public/x.png'});
    });
    final res = await HttpUploadsRepository(makeApi(mock)).upload(PickedImage(bytes: png, name: 'me.png'), UploadKind.avatar);
    expect(res.url, '/files/public/x.png');
  });

  test('non-image bytes are rejected before any request', () async {
    final mock = MockClient((req) async => throw StateError('no call expected'));
    final repo = HttpUploadsRepository(makeApi(mock));
    await expectLater(
      repo.upload(PickedImage(bytes: Uint8List.fromList(utf8.encode('hello')), name: 'a.png'), UploadKind.answer),
      throwsA(isA<ApiException>().having((e) => e.code, 'code', 'invalid_image')),
    );
  });

  test('files over 5MB are rejected before any request', () async {
    final mock = MockClient((req) async => throw StateError('no call expected'));
    final big = Uint8List(maxUploadBytes + 1)..setRange(0, png.length, png);
    await expectLater(
      HttpUploadsRepository(makeApi(mock)).upload(PickedImage(bytes: big, name: 'a.png'), UploadKind.answer),
      throwsA(isA<ApiException>().having((e) => e.code, 'code', 'file_too_large')),
    );
  });

  test('server errors surface as ApiException', () async {
    final mock = MockClient((req) async => jsonResponse(400, {
          'error': {'code': 'validation_error', 'message': 'x'},
        }));
    await expectLater(
      HttpUploadsRepository(makeApi(mock)).upload(PickedImage(bytes: png, name: 'a.png'), UploadKind.answer),
      throwsA(isA<ApiException>().having((e) => e.status, 'status', 400)),
    );
  });

  test('a 401 on upload refreshes the token and replays the multipart request', () async {
    var uploads = 0;
    final mock = MockClient((req) async {
      if (req.url.path.endsWith('/auth/refresh')) {
        return jsonResponse(200, {'accessToken': 'new', 'refreshToken': 'R2'});
      }
      uploads++;
      if (req.headers['Authorization'] != 'Bearer new') {
        return jsonResponse(401, {
          'error': {'code': 'invalid_token', 'message': 'x'},
        });
      }
      expect(latin1.decode(req.bodyBytes), contains('name="file"'));
      return jsonResponse(201, {'id': 'up9'});
    });
    final res = await HttpUploadsRepository(makeApi(mock)).upload(PickedImage(bytes: png, name: 'a.png'), UploadKind.answer);
    expect(res.id, 'up9');
    expect(uploads, 2);
  });

  test('download fetches /uploads/:id with auth and returns the raw bytes', () async {
    http.Request? seen;
    final mock = MockClient((req) async {
      seen = req;
      return http.Response.bytes(png, 200, headers: {'content-type': 'image/png'});
    });
    final bytes = await HttpUploadsRepository(makeApi(mock)).download('up1');
    expect(bytes, png);
    expect(seen!.url.path, '/api/v1/uploads/up1');
    expect(seen!.headers['Authorization'], 'Bearer A1');
    expect(seen!.headers['X-Device-Id'], testDeviceId);
  });

  test('download of a missing upload throws', () async {
    final mock = MockClient((req) async => jsonResponse(404, {
          'error': {'code': 'upload_not_found', 'message': 'x'},
        }));
    await expectLater(
      HttpUploadsRepository(makeApi(mock)).download('nope'),
      throwsA(isA<ApiException>().having((e) => e.code, 'code', 'upload_not_found')),
    );
  });
}
