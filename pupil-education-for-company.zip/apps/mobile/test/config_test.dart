import 'package:edu_student/core/config.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('absoluteUrlFor drops /api/v1 and joins server-relative paths', () {
    expect(absoluteUrlFor('http://h:3000/api/v1', '/files/public/a.png'), 'http://h:3000/files/public/a.png');
    expect(absoluteUrlFor('http://h:3000/api/v1/', 'files/public/a.png'), 'http://h:3000/files/public/a.png');
    expect(absoluteUrlFor('http://h:3000', '/files/x.jpg'), 'http://h:3000/files/x.jpg');
    expect(absoluteUrlFor('http://h:3000//', '/files/x.jpg'), 'http://h:3000/files/x.jpg');
  });

  test('absoluteUrlFor leaves full urls untouched', () {
    expect(absoluteUrlFor('http://h:3000/api/v1', 'https://cdn.test/a.png'), 'https://cdn.test/a.png');
    expect(absoluteUrlFor('http://h:3000/api/v1', 'http://cdn.test/a.png'), 'http://cdn.test/a.png');
  });

  test('absoluteUrl uses the configured API_URL', () {
    expect(absoluteUrl('/files/public/a.png'), '${AppConfig.apiUrl}/files/public/a.png');
  });
}
