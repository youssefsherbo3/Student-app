import 'package:edu_student/app.dart';
import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/features/shell/home_shell.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/fakes.dart';

Finder navLabel(String text) => find.descendant(of: find.byType(NavigationBar), matching: find.text(text));

Future<void> pumpApp(WidgetTester tester, Fakes fakes) async {
  tester.view.physicalSize = const Size(900, 2400);
  tester.view.devicePixelRatio = 1.0;
  addTearDown(tester.view.reset);
  await tester.pumpWidget(fakes.scope(const EduApp()));
  await tester.pumpAndSettle();
}

Future<void> fillAndLogin(WidgetTester tester, {String id = '01011111111', String pw = 'secret1'}) async {
  await tester.enterText(find.byType(TextField).at(0), id);
  await tester.enterText(find.byType(TextField).at(1), pw);
  await tester.tap(find.widgetWithText(FilledButton, 'دخول'));
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('shows the login page when there is no session', (tester) async {
    await pumpApp(tester, Fakes());
    expect(find.text('تسجيل الدخول'), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
  });

  testWidgets('login success opens the shell with the courses list', (tester) async {
    final fakes = Fakes();
    await pumpApp(tester, fakes);
    await fillAndLogin(tester);
    expect(fakes.auth.lastIdentifier, '01011111111');
    expect(fakes.auth.lastPassword, 'secret1');
    expect(find.byType(NavigationBar), findsOneWidget);
    expect(find.text('فيزياء'), findsOneWidget);
  });

  testWidgets('empty fields are rejected locally', (tester) async {
    final fakes = Fakes();
    await pumpApp(tester, fakes);
    await tester.tap(find.widgetWithText(FilledButton, 'دخول'));
    await tester.pump();
    expect(find.textContaining('اكتب رقم الموبايل'), findsOneWidget);
    expect(fakes.auth.lastIdentifier, isNull);
  });

  testWidgets('wrong credentials show the Arabic error and stay on login', (tester) async {
    final fakes = Fakes()..auth.loginError = const ApiException(401, 'invalid_credentials', '');
    await pumpApp(tester, fakes);
    await fillAndLogin(tester, pw: 'bad');
    expect(find.text('بيانات الدخول غلط.'), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
  });

  testWidgets('device_locked on login shows the unlock message', (tester) async {
    final fakes = Fakes()..auth.loginError = const ApiException(403, 'device_locked', '');
    await pumpApp(tester, fakes);
    await fillAndLogin(tester);
    expect(find.textContaining('جهاز تاني'), findsOneWidget);
  });

  testWidgets('register page creates an account and lands in the shell', (tester) async {
    final fakes = Fakes();
    await pumpApp(tester, fakes);
    await tester.tap(find.text('حساب جديد'));
    await tester.pumpAndSettle();
    await tester.tap(find.widgetWithText(FilledButton, 'إنشاء الحساب'));
    await tester.pump();
    expect(find.text('اكتب اسمك.'), findsOneWidget);

    await tester.enterText(find.byType(TextField).at(0), 'منى');
    await tester.enterText(find.byType(TextField).at(1), '01012345678');
    await tester.enterText(find.byType(TextField).at(4), 'secret1');
    await tester.tap(find.widgetWithText(FilledButton, 'إنشاء الحساب'));
    await tester.pumpAndSettle();
    expect(find.byType(NavigationBar), findsOneWidget);
    expect(find.text('إنشاء الحساب'), findsNothing);
  });

  testWidgets('logout from the account tab returns to login and removes the push token', (tester) async {
    final fakes = Fakes()..push = FakePushService('tok-1');
    await pumpApp(tester, fakes);
    await fillAndLogin(tester);
    expect(fakes.notifications.registeredTokens, ['tok-1']);

    await tester.tap(navLabel('حسابي'));
    await tester.pumpAndSettle();
    expect(find.text('طالب تجريبي'), findsOneWidget);
    await tester.tap(find.text('تسجيل خروج'));
    await tester.pumpAndSettle();

    expect(fakes.auth.loggedOut, isTrue);
    expect(fakes.notifications.removedTokens, ['tok-1']);
    expect(find.text('تسجيل الدخول'), findsOneWidget);
  });

  testWidgets('change password dialog validates and calls the repository', (tester) async {
    final fakes = Fakes();
    await pumpApp(tester, fakes);
    await fillAndLogin(tester);
    await tester.tap(navLabel('حسابي'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('تغيير كلمة السر'));
    await tester.pumpAndSettle();

    await tester.tap(find.widgetWithText(FilledButton, 'حفظ'));
    await tester.pump();
    expect(find.text('اكتب كلمة السر الحالية.'), findsOneWidget);

    await tester.enterText(find.byType(TextField).last, '123');
    await tester.enterText(find.byType(TextField).first, 'old-pass');
    await tester.tap(find.widgetWithText(FilledButton, 'حفظ'));
    await tester.pump();
    expect(find.textContaining('6 حروف'), findsOneWidget);

    await tester.enterText(find.byType(TextField).last, 'new-secret');
    await tester.tap(find.widgetWithText(FilledButton, 'حفظ'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 500));
    expect(fakes.auth.lastNewPassword, 'new-secret');
    expect(find.text('تم تغيير كلمة السر.'), findsOneWidget);
  });

  testWidgets('session expiry pops pushed pages and shows login', (tester) async {
    final fakes = Fakes();
    await pumpApp(tester, fakes);
    await fillAndLogin(tester);
    await tester.tap(find.text('فيزياء'));
    await tester.pumpAndSettle();
    expect(find.text('الدروس'), findsOneWidget);

    fakes.auth.setUser(null);
    await tester.pumpAndSettle();

    expect(find.text('الدروس'), findsNothing);
    expect(find.text('تسجيل الدخول'), findsOneWidget);
  });

  testWidgets('shell shows the unread badge and opens notifications', (tester) async {
    final fakes = Fakes();
    await fakes.pump(tester, const HomeShell());
    expect(find.descendant(of: find.byType(Badge), matching: find.text('1')), findsWidgets);
    await tester.tap(navLabel('الإشعارات'));
    await tester.pumpAndSettle();
    expect(find.text('درس جديد'), findsOneWidget);
  });
}
