import 'package:edu_student/core/utils.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('formatDuration', () {
    expect(formatDuration(125), '2:05');
    expect(formatDuration(0), '0:00');
    expect(formatDuration(-5), '0:00');
    expect(formatDuration(3600), '60:00');
  });

  test('percent', () {
    expect(percent(1, 2), 50);
    expect(percent(0, 0), 0);
    expect(percent(2, 3), 67);
  });

  test('formatDate / formatDateTime', () {
    expect(formatDate(DateTime(2026, 3, 5)), '2026/03/05');
    expect(formatDateTime(DateTime(2026, 3, 5, 9, 7)), '2026/03/05 09:07');
  });

  test('safe converters', () {
    expect(asString(null), '');
    expect(asString(5), '5');
    expect(asInt('x'), 0);
    expect(asInt(3.0), 3);
    expect(asIntOrNull(null), isNull);
    expect(parseDate('nope'), isNull);
    expect(parseDate(5), isNull);
  });

  test('parseList accepts arrays and page objects, skips junk', () {
    int id(Map<String, dynamic> m) => m['id'] as int;
    expect(
      parseList<int>([
        {'id': 1},
        'x',
        {'id': 2},
      ], id),
      [1, 2],
    );
    expect(
      parseList<int>({
        'items': [
          {'id': 3},
        ],
        'total': 1,
      }, id),
      [3],
    );
    expect(parseList<int>(null, id), isEmpty);
  });

  group('embedUrl', () {
    test('youtube variants', () {
      const expected =
          'https://www.youtube-nocookie.com/embed/abc123?rel=0&modestbranding=1&playsinline=1';
      expect(embedUrl('https://www.youtube.com/watch?v=abc123'), expected);
      expect(embedUrl('https://youtu.be/abc123'), expected);
      expect(embedUrl('https://www.youtube.com/embed/abc123'), expected);
      expect(embedUrl('https://www.youtube.com/shorts/abc123'), expected);
    });

    test('vimeo, with and without privacy hash', () {
      expect(
        embedUrl('https://vimeo.com/12345'),
        'https://player.vimeo.com/video/12345',
      );
      expect(
        embedUrl('https://vimeo.com/12345/abcdef'),
        'https://player.vimeo.com/video/12345?h=abcdef',
      );
      expect(
        embedUrl('https://player.vimeo.com/video/12345?h=zz'),
        'https://player.vimeo.com/video/12345?h=zz',
      );
    });

    test('unsupported or empty', () {
      expect(embedUrl(null), isNull);
      expect(embedUrl('  '), isNull);
      expect(embedUrl('https://example.com/video.mp4'), isNull);
      expect(embedUrl('not a url'), isNull);
    });
  });

  test('videoHtml embeds the url in an iframe', () {
    expect(
      videoHtml('https://x.test/e'),
      contains('<iframe src="https://x.test/e"'),
    );
    expect(
      videoHtml('https://x.test/e'),
      contains('sandbox="allow-scripts allow-presentation"'),
    );
    expect(videoHtml('https://x.test/e?x=1&y=2'), contains('&amp;'));
    expect(
      videoHtml('https://x.test/" onload="alert(1)'),
      isNot(contains('" onload="alert(1)')),
    );
  });
}
