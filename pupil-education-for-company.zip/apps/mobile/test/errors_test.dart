import 'package:edu_student/core/api_client.dart';
import 'package:edu_student/core/errors.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('known codes map to Arabic messages', () {
    expect(friendlyError(const ApiException(403, 'device_locked', 'x')), contains('جهاز تاني'));
    expect(friendlyError(const ApiException(409, 'too_early', '')), contains('المدة'));
    expect(friendlyError(const ApiException(409, 'no_attempts_left', '')), contains('محاولاتك'));
    expect(friendlyError(const ApiException(404, 'invalid_code', '')), contains('غير صحيح'));
    expect(friendlyError(const ApiException(429, 'too_many_attempts', '')), contains('محاولات كتير'));
    expect(friendlyError(const ApiException(0, 'network', '')), contains('اتصال'));
  });

  test('*_not_found and 5xx', () {
    expect(friendlyError(const ApiException(404, 'lesson_not_found', '')), contains('مش موجود'));
    expect(friendlyError(const ApiException(500, 'http_500', '')), contains('السيرفر'));
  });

  test('validation_error prefers the first detail message', () {
    const e = ApiException(400, 'validation_error', 'عام', [
      {'path': 'password', 'message': 'كلمة السر قصيرة'},
    ]);
    expect(friendlyError(e), 'كلمة السر قصيرة');
    expect(friendlyError(const ApiException(400, 'validation_error', 'عام')), 'عام');
  });

  test('unknown code falls back to the server message, then to a generic one', () {
    expect(friendlyError(const ApiException(418, 'teapot', 'أنا براد شاي')), 'أنا براد شاي');
    expect(friendlyError(const ApiException(418, 'teapot', '')), contains('حصلت مشكلة'));
    expect(friendlyError(Exception('boom')), contains('حصلت مشكلة'));
  });
}
