import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/config.dart';
import '../../core/errors.dart';
import '../../core/image_picker_service.dart';
import '../uploads/uploads_repository.dart';

/// Edit name and avatar. The avatar is uploaded first (`kind=avatar`), then `PATCH /auth/me` links it.
class ProfileEditPage extends StatefulWidget {
  const ProfileEditPage({super.key});

  @override
  State<ProfileEditPage> createState() => _ProfileEditPageState();
}

class _ProfileEditPageState extends State<ProfileEditPage> {
  late final TextEditingController _name;
  PickedImage? _picked;
  String? _avatarUploadId;
  String? _error;
  bool _uploading = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: AppScope.read(context).auth.user.value?.name ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _pick(ImagePickSource source) async {
    final scope = AppScope.read(context);
    PickedImage? img;
    try {
      img = await scope.imagePicker.pick(source);
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'تعذّر فتح الصورة.');
      return;
    }
    if (img == null || !mounted) return;
    setState(() {
      _picked = img;
      _avatarUploadId = null;
      _uploading = true;
      _error = null;
    });
    try {
      final res = await scope.uploads.upload(img, UploadKind.avatar);
      if (!mounted) return;
      setState(() {
        _avatarUploadId = res.id;
        _uploading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _picked = null;
        _uploading = false;
        _error = friendlyError(e);
      });
    }
  }

  Future<void> _save() async {
    if (_busy || _uploading) return;
    final name = _name.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'اكتب اسمك.');
      return;
    }
    final auth = AppScope.read(context).auth;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await auth.updateProfile(name: name, avatarUploadId: _avatarUploadId);
      if (!mounted) return;
      final messenger = ScaffoldMessenger.of(context);
      Navigator.of(context).pop(true);
      messenger.showSnackBar(const SnackBar(content: Text('تم حفظ البيانات.')));
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = friendlyError(e);
      });
    }
  }

  ImageProvider? _avatar() {
    final p = _picked;
    if (p != null) return MemoryImage(p.bytes);
    final url = AppScope.read(context).auth.user.value?.avatarUrl;
    return url == null ? null : NetworkImage(absoluteUrl(url));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final avatar = _avatar();
    return Scaffold(
      appBar: AppBar(title: const Text('تعديل بياناتي')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Stack(alignment: Alignment.center, children: [
                CircleAvatar(
                  radius: 48,
                  backgroundImage: avatar,
                  // A failing network image must not crash the page.
                  onBackgroundImageError: avatar == null ? null : (_, __) {},
                  child: avatar == null ? const Icon(Icons.person, size: 48) : null,
                ),
                if (_uploading) const CircularProgressIndicator(),
              ]),
            ),
            const SizedBox(height: 12),
            Wrap(alignment: WrapAlignment.center, spacing: 8, children: [
              OutlinedButton.icon(
                onPressed: (_busy || _uploading) ? null : () => _pick(ImagePickSource.gallery),
                icon: const Icon(Icons.photo_library_outlined),
                label: const Text('اختيار صورة'),
              ),
              OutlinedButton.icon(
                onPressed: (_busy || _uploading) ? null : () => _pick(ImagePickSource.camera),
                icon: const Icon(Icons.photo_camera_outlined),
                label: const Text('تصوير'),
              ),
            ]),
            const SizedBox(height: 24),
            TextField(
              controller: _name,
              textInputAction: TextInputAction.done,
              decoration: const InputDecoration(labelText: 'الاسم'),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(_error!, style: TextStyle(color: scheme.error)),
              ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: (_busy || _uploading) ? null : _save,
              child: Text(_busy ? 'جاري الحفظ...' : 'حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}
