import 'dart:typed_data';

import '../../core/api_client.dart';
import '../../core/image_picker_service.dart';
import '../../core/utils.dart';

/// `kind` values accepted by `POST /uploads`.
class UploadKind {
  const UploadKind._();

  static const String answer = 'answer';
  static const String avatar = 'avatar';
}

const int maxUploadBytes = 5 * 1024 * 1024;

class UploadResult {
  const UploadResult({required this.id, this.url});

  final String id;

  /// null for private kinds (answer images).
  final String? url;

  factory UploadResult.fromJson(Map<String, dynamic> j) => UploadResult(id: asString(j['id']), url: asStringOrNull(j['url']));
}

abstract class UploadsRepository {
  /// Uploads [image] (png / jpg / webp, up to 5MB) with the given [kind].
  Future<UploadResult> upload(PickedImage image, String kind);

  /// Downloads a private upload (answer image) through the authenticated endpoint.
  Future<Uint8List> download(String uploadId);
}

class HttpUploadsRepository implements UploadsRepository {
  HttpUploadsRepository(this._api);

  final ApiClient _api;

  @override
  Future<UploadResult> upload(PickedImage image, String kind) async {
    final mime = sniffImageMime(image.bytes);
    if (mime == 'application/octet-stream') {
      throw const ApiException(400, 'invalid_image', 'الملف لازم يكون صورة PNG أو JPG أو WEBP.');
    }
    if (image.bytes.length > maxUploadBytes) {
      throw const ApiException(413, 'file_too_large', 'حجم الصورة أكبر من 5 ميجا.');
    }
    final data = await _api.postMultipart(
      '/uploads',
      field: 'file',
      bytes: image.bytes,
      filename: uploadFileName(image.name, mime),
      contentType: mime,
      query: {'kind': kind},
    );
    return UploadResult.fromJson(data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{});
  }

  @override
  Future<Uint8List> download(String uploadId) => _api.getBytes('/uploads/$uploadId');
}
