import 'package:flutter/material.dart';

class HelpGuidePage extends StatelessWidget {
  const HelpGuidePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دليل استخدام المنصة')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: const [
          Padding(
            padding: EdgeInsets.fromLTRB(8, 8, 8, 16),
            child: Text(
              'امشِ بالخطوات دي عشان تلاقي كورساتك وتكمل الحصص والواجبات بسهولة.',
              style: TextStyle(fontSize: 16),
            ),
          ),
          _GuideSection(
            icon: Icons.vpn_key_outlined,
            title: 'تفعيل الاشتراك',
            body:
                'افتح تبويب «كود»، اكتب كود الاشتراك، واضغط تفعيل. بعد التفعيل هتلاقي المدرس وكورساتك في «كورساتي».',
          ),
          _GuideSection(
            icon: Icons.school_outlined,
            title: 'المدرسون والكورسات',
            body:
                'من «كورساتي» هتلاقي كل مدرس مشترك معاه. افتح اسم المدرس عشان تشوف كورساته، وبعدها اختار الكورس.',
          ),
          _GuideSection(
            icon: Icons.play_circle_outline,
            title: 'مشاهدة الحصة',
            body:
                'افتح تبويب «الدروس» واختار حصة متاحة. الفيديو بيشتغل داخل المنصة من غير ما يخرجك لتطبيق YouTube. بعض الحصص لازم تكمل وقت المشاهدة المطلوب فيها قبل ما تتسجل كمكتملة.',
          ),
          _GuideSection(
            icon: Icons.assignment_outlined,
            title: 'الامتحان والواجب المرتبط بالحصة',
            body:
                'لو الحصة عليها امتحان أو واجب مطلوب، هتكون مقفولة ويظهر اسمه. اضغط على الحصة أو علامة الواجب عشان تبدأه مباشرة. بعد التسليم ارجع للحصة؛ لو اتفتحت من السيرفر تقدر تشاهدها. تقدر كمان تفتح كل التقييمات من تبويب «الامتحانات والواجبات».',
          ),
          _GuideSection(
            icon: Icons.picture_as_pdf_outlined,
            title: 'الملازم والملفات',
            body: 'داخل الحصة، اضغط على اسم الملزمة لفتحها على جهازك.',
          ),
          _GuideSection(
            icon: Icons.history,
            title: 'الإجابات والنتائج',
            body:
                'من صفحة الامتحان اضغط علامة السجل «نتائجي» لمراجعة محاولاتك ونتائجك وملاحظات المدرس.',
          ),
          _GuideSection(
            icon: Icons.notifications_outlined,
            title: 'الإشعارات وحسابك',
            body:
                'تابع تبويب «الإشعارات» للمواعيد والتنبيهات. من «حسابي» تقدر تعدّل بياناتك، تغيّر كلمة السر، أو تفتح دليل الاستخدام مرة تانية.',
          ),
        ],
      ),
    );
  }
}

class _GuideSection extends StatelessWidget {
  const _GuideSection({
    required this.icon,
    required this.title,
    required this.body,
  });

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ExpansionTile(
        leading: Icon(icon),
        title: Text(title),
        childrenPadding: const EdgeInsetsDirectional.fromSTEB(16, 0, 16, 16),
        children: [Text(body, textAlign: TextAlign.start)],
      ),
    );
  }
}
