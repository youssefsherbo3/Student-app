import '../../core/api_client.dart';
import '../../core/utils.dart';
import 'course_models.dart';

abstract class CoursesRepository {
  /// The student's active subscriptions.
  Future<List<Course>> list();

  /// The student's rank in the course (anonymous leaderboard position).
  Future<MyRank> myRank(String courseId);
}

class HttpCoursesRepository implements CoursesRepository {
  HttpCoursesRepository(this._api);

  final ApiClient _api;

  @override
  Future<List<Course>> list() async => parseList<Course>(await _api.get('/courses'), Course.fromJson);

  @override
  Future<MyRank> myRank(String courseId) async {
    final data = await _api.get('/courses/$courseId/my-rank');
    return MyRank.fromJson(data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{});
  }
}
