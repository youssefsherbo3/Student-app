import '../../core/utils.dart';

class Course {
  const Course({
    required this.id,
    required this.title,
    this.description = '',
    this.expiresAt,
    this.teacherId,
    this.teacherName = '',
  });

  final String id;
  final String title;
  final String description;

  /// Teacher this course belongs to (a student can be subscribed to several teachers).
  final String? teacherId;
  final String teacherName;

  /// End of the student's subscription (null when the API did not send it).
  final DateTime? expiresAt;

  factory Course.fromJson(Map<String, dynamic> j) => Course(
    id: asString(j['id']),
    title: asString(j['title']),
    description: asString(j['description']),
    expiresAt: parseDate(j['expiresAt']),
    teacherId: asStringOrNull(j['teacherId']),
    teacherName: asString(j['teacherName']),
  );
}

/// `GET /courses/:id/my-rank`. [rank] is null when the student has no graded attempts yet.
class MyRank {
  const MyRank({this.rank, this.of = 0, this.percent = 0});

  final int? rank;

  /// Number of ranked students.
  final int of;
  final int percent;

  factory MyRank.fromJson(Map<String, dynamic> j) => MyRank(
    rank: asIntOrNull(j['rank']),
    of: asInt(j['of']),
    percent: asInt(j['percent']),
  );
}
