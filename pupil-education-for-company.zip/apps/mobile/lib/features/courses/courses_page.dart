import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/utils.dart';
import '../../core/widgets.dart';
import 'course_models.dart';
import 'course_page.dart';

class CoursesPage extends StatelessWidget {
  const CoursesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final repo = AppScope.of(context).courses;
    return Scaffold(
      appBar: AppBar(title: const Text('كورساتي')),
      body: AsyncView<List<Course>>(
        load: repo.list,
        builder: (context, courses, reload) => RefreshIndicator(
          onRefresh: reload,
          child: courses.isEmpty
              ? ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  children: const [
                    EmptyView(
                      'مفيش كورسات مسجّل فيها. فعّل كود الاشتراك من تبويب «كود».',
                    ),
                  ],
                )
              : _TeacherCourseList(groups: _groupCourses(courses)),
        ),
      ),
    );
  }
}

Map<String, _TeacherGroup> _groupCourses(List<Course> courses) {
  final groups = <String, _TeacherGroup>{};
  for (final course in courses) {
    final teacherName = course.teacherName.trim().isEmpty
        ? 'مدرس غير محدد'
        : course.teacherName.trim();
    final teacherId = course.teacherId?.trim();
    final key = teacherId != null && teacherId.isNotEmpty
        ? 'id:$teacherId'
        : 'name:$teacherName';
    groups
        .putIfAbsent(key, () => _TeacherGroup(teacherName))
        .courses
        .add(course);
  }
  return groups;
}

class _TeacherGroup {
  _TeacherGroup(this.name);

  final String name;
  final List<Course> courses = <Course>[];
}

class _TeacherCourseList extends StatelessWidget {
  const _TeacherCourseList({required this.groups});

  final Map<String, _TeacherGroup> groups;

  @override
  Widget build(BuildContext context) {
    final teachers = groups.values.toList();
    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(12),
      itemCount: teachers.length,
      itemBuilder: (context, index) {
        final teacher = teachers[index];
        return Card(
          clipBehavior: Clip.antiAlias,
          child: ExpansionTile(
            initiallyExpanded: true,
            leading: const CircleAvatar(child: Icon(Icons.person_outline)),
            title: Text(teacher.name),
            subtitle: Text('${teacher.courses.length} كورس'),
            children: [
              for (var i = 0; i < teacher.courses.length; i++) ...[
                if (i > 0) const Divider(height: 1, indent: 64),
                _CourseTile(course: teacher.courses[i]),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _CourseTile extends StatelessWidget {
  const _CourseTile({required this.course});

  final Course course;

  @override
  Widget build(BuildContext context) {
    final expires = course.expiresAt;
    final lines = <String>[
      if (course.description.isNotEmpty) course.description,
      if (expires != null) 'الاشتراك ينتهي: ${formatDate(expires.toLocal())}',
    ];
    return ListTile(
      leading: const Icon(Icons.menu_book),
      title: Text(course.title),
      subtitle: lines.isEmpty ? null : Text(lines.join('\n')),
      isThreeLine: lines.length > 1,
      trailing: const Icon(Icons.chevron_left),
      onTap: () => pushPage<void>(context, CoursePage(course: course)),
    );
  }
}
