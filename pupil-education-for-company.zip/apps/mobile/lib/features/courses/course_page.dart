import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/utils.dart';
import '../../core/widgets.dart';
import '../lessons/lesson_models.dart';
import '../lessons/lesson_page.dart';
import '../quizzes/quiz_models.dart';
import '../quizzes/quiz_page.dart';
import 'course_models.dart';

class CoursePage extends StatefulWidget {
  const CoursePage({super.key, required this.course});

  final Course course;

  @override
  State<CoursePage> createState() => _CoursePageState();
}

class _CoursePageState extends State<CoursePage> {
  int _lessonReloadVersion = 0;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.course.title),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'الدروس'),
              Tab(text: 'الامتحانات والواجبات'),
            ],
          ),
        ),
        body: Column(
          children: [
            _RankChip(courseId: widget.course.id),
            Expanded(
              child: TabBarView(
                children: [
                  _LessonsTab(
                    key: ValueKey(_lessonReloadVersion),
                    courseId: widget.course.id,
                  ),
                  _QuizzesTab(
                    courseId: widget.course.id,
                    onQuizReturned: () =>
                        setState(() => _lessonReloadVersion++),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// "Your rank: 3 of 20" chip. Hidden while loading, on error, or when there is no rank yet.
class _RankChip extends StatefulWidget {
  const _RankChip({required this.courseId});

  final String courseId;

  @override
  State<_RankChip> createState() => _RankChipState();
}

class _RankChipState extends State<_RankChip> {
  MyRank? _rank;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = AppScope.read(context).courses;
    try {
      final r = await repo.myRank(widget.courseId);
      if (!mounted) return;
      setState(() => _rank = r);
    } catch (_) {
      // Decorative: a failure just leaves the chip hidden.
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = _rank;
    final rank = r?.rank;
    if (r == null || rank == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Align(
        alignment: AlignmentDirectional.centerStart,
        child: Chip(
          avatar: const Icon(Icons.emoji_events_outlined, size: 18),
          label: Text('ترتيبك: $rank من ${r.of} (${r.percent}%)'),
        ),
      ),
    );
  }
}

class _LessonsTab extends StatelessWidget {
  const _LessonsTab({super.key, required this.courseId});

  final String courseId;

  Future<_LessonsData> _load(BuildContext context) async {
    final scope = AppScope.read(context);
    final lessons = scope.lessons.list(courseId);
    final quizzes = scope.quizzes.list(courseId);
    return _LessonsData(lessons: await lessons, quizzes: await quizzes);
  }

  @override
  Widget build(BuildContext context) {
    return AsyncView<_LessonsData>(
      load: () => _load(context),
      builder: (context, data, reload) => RefreshIndicator(
        onRefresh: reload,
        child: data.lessons.isEmpty
            ? ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: const [EmptyView('مفيش دروس لسه.')],
              )
            : ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: data.lessons.length,
                itemBuilder: (context, i) =>
                    _lessonTile(context, data.lessons[i], data.quizzes, reload),
              ),
      ),
    );
  }

  Widget _lessonTile(
    BuildContext context,
    Lesson l,
    List<Quiz> quizzes,
    Future<void> Function() reload,
  ) {
    final IconData icon = l.locked
        ? Icons.lock
        : (l.done ? Icons.check_circle : Icons.play_circle);
    final subtitle = l.locked
        ? l.assessmentLocked
              ? 'مطلوب قبل مشاهدة الحصة: ${l.unlockAfterQuizTitle ?? 'الامتحان أو الواجب'} — اضغط لفتحه'
              : 'مقفول: خلّص الدرس اللي قبله أو استنى ميعاد الفتح${l.opensAt != null ? ' (${formatDateTime(l.opensAt!.toLocal())})' : ''}'
        : (l.minSeconds > 0
              ? 'المدة المطلوبة: ${formatDuration(l.minSeconds)}'
              : null);
    return ListTile(
      leading: Icon(icon),
      title: Text(l.title),
      subtitle: subtitle == null ? null : Text(subtitle),
      trailing: l.assessmentLocked
          ? IconButton(
              tooltip: 'افتح الامتحان أو الواجب المطلوب',
              icon: const Icon(Icons.assignment_outlined),
              onPressed: () => _openLesson(context, l, quizzes, reload),
            )
          : const Icon(Icons.chevron_left),
      onTap: () => _openLesson(context, l, quizzes, reload),
    );
  }

  Future<void> _openLesson(
    BuildContext context,
    Lesson lesson,
    List<Quiz> quizzes,
    Future<void> Function() reload,
  ) async {
    if (lesson.locked) {
      if (lesson.assessmentLocked) {
        final linkedQuiz = _quizForLesson(lesson, quizzes);
        if (linkedQuiz == null) {
          showSnack(
            context,
            'الامتحان أو الواجب المطلوب مش ظاهر. حدّث الصفحة أو تواصل مع المدرس.',
          );
          return;
        }
        await pushPage<bool>(context, QuizPage(quiz: linkedQuiz));
        if (context.mounted) await reload();
        return;
      }
      showSnack(context, 'الدرس ده لسه مقفول.');
      return;
    }
    await pushPage<bool>(context, LessonPage(lesson: lesson));
    if (context.mounted) await reload();
  }

  Quiz? _quizForLesson(Lesson lesson, List<Quiz> quizzes) {
    final id = lesson.unlockAfterQuizId;
    if (id != null) {
      for (final quiz in quizzes) {
        if (quiz.id == id) return quiz;
      }
    }
    final title = lesson.unlockAfterQuizTitle;
    if (title != null) {
      for (final quiz in quizzes) {
        if (quiz.title == title) return quiz;
      }
    }
    return null;
  }
}

class _LessonsData {
  const _LessonsData({required this.lessons, required this.quizzes});

  final List<Lesson> lessons;
  final List<Quiz> quizzes;
}

class _QuizzesTab extends StatelessWidget {
  const _QuizzesTab({required this.courseId, required this.onQuizReturned});

  final String courseId;
  final VoidCallback onQuizReturned;

  @override
  Widget build(BuildContext context) {
    final repo = AppScope.of(context).quizzes;
    return AsyncView<List<Quiz>>(
      load: () => repo.list(courseId),
      builder: (context, quizzes, reload) => RefreshIndicator(
        onRefresh: reload,
        child: quizzes.isEmpty
            ? ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: const [EmptyView('مفيش امتحانات أو واجبات لسه.')],
              )
            : ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: quizzes.length,
                itemBuilder: (context, i) =>
                    _quizTile(context, quizzes[i], reload),
              ),
      ),
    );
  }

  Widget _quizTile(
    BuildContext context,
    Quiz q,
    Future<void> Function() reload,
  ) {
    final parts = <String>[
      q.isHomework ? 'واجب' : 'امتحان',
      if (q.dueAt != null) 'الموعد: ${formatDateTime(q.dueAt!.toLocal())}',
      if (q.maxAttempts != null)
        'المحاولات: ${q.attemptsUsed ?? 0} / ${q.maxAttempts}',
      if (q.closed) 'مقفول',
    ];
    return ListTile(
      leading: Icon(q.isHomework ? Icons.assignment : Icons.quiz),
      title: Text(q.title),
      subtitle: Text(parts.join(' • ')),
      onTap: () async {
        await pushPage<bool>(context, QuizPage(quiz: q));
        await reload();
        if (context.mounted) onQuizReturned();
      },
    );
  }
}
