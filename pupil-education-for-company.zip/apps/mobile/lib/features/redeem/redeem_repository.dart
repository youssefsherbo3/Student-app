import '../../core/api_client.dart';
import '../../core/utils.dart';

class RedeemResult {
  const RedeemResult({required this.courseId, this.expiresAt});

  final String courseId;
  final DateTime? expiresAt;

  factory RedeemResult.fromJson(Map<String, dynamic> j) =>
      RedeemResult(courseId: asString(j['courseId']), expiresAt: parseDate(j['expiresAt']));
}

abstract class RedeemRepository {
  /// Throws ApiException `invalid_code` (404) or `too_many_attempts` (429).
  Future<RedeemResult> redeem(String code);
}

class HttpRedeemRepository implements RedeemRepository {
  HttpRedeemRepository(this._api);

  final ApiClient _api;

  @override
  Future<RedeemResult> redeem(String code) async {
    final data = await _api.post('/codes/redeem', body: {'code': code.trim()});
    return RedeemResult.fromJson(data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{});
  }
}
