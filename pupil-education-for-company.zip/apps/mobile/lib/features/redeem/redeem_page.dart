import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/errors.dart';
import '../../core/utils.dart';

class RedeemPage extends StatefulWidget {
  const RedeemPage({super.key, this.onRedeemed});

  /// Called after a successful redeem (the shell uses it to reload the courses list).
  final VoidCallback? onRedeemed;

  @override
  State<RedeemPage> createState() => _RedeemPageState();
}

class _RedeemPageState extends State<RedeemPage> {
  final _code = TextEditingController();
  String? _message;
  bool _ok = false;
  bool _busy = false;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy || _code.text.trim().isEmpty) return;
    final repo = AppScope.read(context).redeem;
    setState(() {
      _busy = true;
      _message = null;
    });
    String msg;
    var ok = false;
    try {
      final r = await repo.redeem(_code.text);
      ok = true;
      final d = r.expiresAt;
      msg = d == null ? 'تم تفعيل الكود.' : 'تم التفعيل. الاشتراك ينتهي ${formatDate(d.toLocal())}';
    } catch (e) {
      msg = friendlyError(e);
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      _ok = ok;
      _message = msg;
      if (ok) _code.clear();
    });
    if (ok) widget.onRedeemed?.call();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('تفعيل كود الاشتراك')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          TextField(
            controller: _code,
            textCapitalization: TextCapitalization.characters,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _submit(),
            decoration: const InputDecoration(labelText: 'الكود'),
          ),
          const SizedBox(height: 16),
          FilledButton(onPressed: _busy ? null : _submit, child: Text(_busy ? 'جاري التفعيل...' : 'تفعيل')),
          if (_message != null)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Text(_message!, style: TextStyle(color: _ok ? Colors.green.shade700 : scheme.error)),
            ),
        ],
      ),
    );
  }
}
