import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../courses/courses_page.dart';
import '../notifications/notifications_page.dart';
import '../notifications/push_service.dart';
import '../redeem/redeem_page.dart';
import 'account_page.dart';

/// Signed-in shell: courses / notifications (unread badge) / redeem code / account.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  int _unread = 0;
  int _coursesVersion = 0;
  int _notificationsVersion = 0;
  String? _pushToken;
  StreamSubscription<String>? _tokenSub;

  @override
  void initState() {
    super.initState();
    _refreshUnread();
    _setupPush();
  }

  @override
  void dispose() {
    _tokenSub?.cancel();
    super.dispose();
  }

  Future<void> _refreshUnread() async {
    final repo = AppScope.read(context).notifications;
    try {
      final n = await repo.unreadCount();
      if (!mounted) return;
      setState(() => _unread = n);
    } catch (_) {
      // The badge is cosmetic; ignore failures.
    }
  }

  Future<void> _setupPush() async {
    final scope = AppScope.read(context);
    try {
      final token = await scope.push.getToken();
      if (!mounted) return;
      if (token != null) {
        _pushToken = token;
        await scope.notifications.registerPushToken(token, currentPushPlatform());
      }
      if (!mounted) return;
      _tokenSub = scope.push.onTokenRefresh.listen((t) {
        _pushToken = t;
        scope.notifications.registerPushToken(t, currentPushPlatform()).catchError((Object _) {});
      });
    } catch (_) {
      // Push is optional.
    }
  }

  Future<void> _logout() async {
    final scope = AppScope.read(context);
    final token = _pushToken;
    if (token != null) {
      try {
        await scope.notifications.unregisterPushToken(token);
      } catch (_) {
        // Best effort.
      }
    }
    await scope.auth.logout();
  }

  void _select(int i) {
    setState(() {
      _index = i;
      if (i == 1) _notificationsVersion++;
    });
    _refreshUnread();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          CoursesPage(key: ValueKey<int>(_coursesVersion)),
          NotificationsPage(key: ValueKey<int>(_notificationsVersion), onChanged: _refreshUnread),
          RedeemPage(onRedeemed: () => setState(() => _coursesVersion++)),
          AccountPage(onLogout: _logout),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _select,
        destinations: [
          const NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: 'كورساتي'),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: _unread > 0,
              label: Text('$_unread'),
              child: const Icon(Icons.notifications_outlined),
            ),
            selectedIcon: Badge(
              isLabelVisible: _unread > 0,
              label: Text('$_unread'),
              child: const Icon(Icons.notifications),
            ),
            label: 'الإشعارات',
          ),
          const NavigationDestination(icon: Icon(Icons.vpn_key_outlined), selectedIcon: Icon(Icons.vpn_key), label: 'كود'),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}
