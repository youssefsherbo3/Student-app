import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/config.dart';
import '../../core/errors.dart';
import '../../core/widgets.dart';
import '../auth/auth_repository.dart';
import '../help/help_guide_page.dart';
import '../profile/profile_edit_page.dart';

class AccountPage extends StatelessWidget {
  const AccountPage({super.key, required this.onLogout});

  final Future<void> Function() onLogout;

  @override
  Widget build(BuildContext context) {
    final auth = AppScope.of(context).auth;
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ValueListenableBuilder<AppUser?>(
            valueListenable: auth.user,
            builder: (context, user, _) {
              final avatar = user?.avatarUrl;
              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: avatar == null
                      ? null
                      : NetworkImage(absoluteUrl(avatar)),
                  onBackgroundImageError: avatar == null ? null : (_, __) {},
                  child: avatar == null ? const Icon(Icons.person) : null,
                ),
                title: Text(user?.name ?? ''),
                subtitle: Text(
                  [
                    user?.phone,
                    user?.email,
                  ].whereType<String>().where((s) => s.isNotEmpty).join(' • '),
                ),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.edit_outlined),
            title: const Text('تعديل بياناتي'),
            onTap: () => pushPage<bool>(context, const ProfileEditPage()),
          ),
          ListTile(
            leading: const Icon(Icons.help_outline),
            title: const Text('دليل استخدام المنصة'),
            subtitle: const Text('شرح الكورسات والحصص والامتحانات'),
            onTap: () => pushPage<void>(context, const HelpGuidePage()),
          ),
          ListTile(
            leading: const Icon(Icons.lock_reset),
            title: const Text('تغيير كلمة السر'),
            onTap: () => showDialog<void>(
              context: context,
              builder: (_) => const ChangePasswordDialog(),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('تسجيل خروج'),
            onTap: onLogout,
          ),
        ],
      ),
    );
  }
}

class ChangePasswordDialog extends StatefulWidget {
  const ChangePasswordDialog({super.key});

  @override
  State<ChangePasswordDialog> createState() => _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<ChangePasswordDialog> {
  final _current = TextEditingController();
  final _next = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _current.dispose();
    _next.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_current.text.isEmpty) {
      setState(() => _error = 'اكتب كلمة السر الحالية.');
      return;
    }
    if (_next.text.length < 6) {
      setState(() => _error = 'كلمة السر الجديدة لازم تكون 6 حروف أو أكتر.');
      return;
    }
    final auth = AppScope.read(context).auth;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await auth.changePassword(_current.text, _next.text);
      if (!mounted) return;
      final messenger = ScaffoldMessenger.of(context);
      Navigator.of(context).pop();
      messenger.showSnackBar(
        const SnackBar(content: Text('تم تغيير كلمة السر.')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = friendlyError(e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('تغيير كلمة السر'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _current,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'كلمة السر الحالية'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _next,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'كلمة السر الجديدة'),
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(
                _error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'جاري الحفظ...' : 'حفظ'),
        ),
      ],
    );
  }
}
