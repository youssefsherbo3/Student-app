import '../../core/api_client.dart';
import '../../core/utils.dart';
import 'notification_models.dart';

abstract class NotificationsRepository {
  Future<List<AppNotification>> list({bool unreadOnly = false});

  Future<int> unreadCount();

  Future<void> markRead(String id);

  Future<void> markAllRead();

  /// platform: android | ios | web
  Future<void> registerPushToken(String token, String platform);

  Future<void> unregisterPushToken(String token);
}

class HttpNotificationsRepository implements NotificationsRepository {
  HttpNotificationsRepository(this._api);

  final ApiClient _api;

  @override
  Future<List<AppNotification>> list({bool unreadOnly = false}) async {
    final data = await _api.get('/notifications', query: {'pageSize': '50', if (unreadOnly) 'unreadOnly': 'true'});
    return parseList<AppNotification>(data, AppNotification.fromJson);
  }

  @override
  Future<int> unreadCount() async {
    final data = await _api.get('/notifications/unread-count');
    return data is Map ? asInt(data['count']) : 0;
  }

  @override
  Future<void> markRead(String id) async {
    await _api.post('/notifications/$id/read');
  }

  @override
  Future<void> markAllRead() async {
    await _api.post('/notifications/read-all');
  }

  @override
  Future<void> registerPushToken(String token, String platform) async {
    await _api.post('/push-tokens', body: {'token': token, 'platform': platform});
  }

  @override
  Future<void> unregisterPushToken(String token) async {
    await _api.delete('/push-tokens', body: {'token': token});
  }
}
