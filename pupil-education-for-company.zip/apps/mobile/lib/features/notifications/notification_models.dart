import '../../core/utils.dart';

class AppNotification {
  const AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    this.data = const <String, String>{},
    this.read = false,
    this.createdAt,
  });

  final String id;

  /// lesson_opened, quiz_created, quiz_due_soon, subscription_expiring, enrolled, graded.
  final String type;
  final String title;
  final String body;

  /// May hold courseId / lessonId / quizId / submissionId.
  final Map<String, String> data;
  final bool read;
  final DateTime? createdAt;

  AppNotification copyWith({bool? read}) => AppNotification(
        id: id,
        type: type,
        title: title,
        body: body,
        data: data,
        read: read ?? this.read,
        createdAt: createdAt,
      );

  factory AppNotification.fromJson(Map<String, dynamic> j) {
    final raw = j['data'];
    return AppNotification(
      id: asString(j['id']),
      type: asString(j['type']),
      title: asString(j['title']),
      body: asString(j['body']),
      data: raw is Map ? <String, String>{for (final e in raw.entries) '${e.key}': '${e.value}'} : const <String, String>{},
      read: j['read'] == true,
      createdAt: parseDate(j['createdAt']),
    );
  }
}
