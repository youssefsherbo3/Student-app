import 'package:flutter/foundation.dart';

/// Source of the device push token. The app only depends on this interface, so the project builds
/// with NO Firebase dependency. HomeShell registers the token with `POST /push-tokens` after login
/// and removes it on logout.
///
/// To plug Firebase Cloud Messaging in later:
///  1. Add `firebase_core` and `firebase_messaging` to pubspec.yaml and run `flutterfire configure`
///     (it generates firebase_options.dart and the platform config files).
///  2. In main(): `await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);`
///  3. Implement this interface:
///
///     class FcmPushService implements PushService {
///       @override
///       Future<String?> getToken() async {
///         await FirebaseMessaging.instance.requestPermission();
///         return FirebaseMessaging.instance.getToken(); // on web pass vapidKey: '...'
///       }
///
///       @override
///       Stream<String> get onTokenRefresh => FirebaseMessaging.instance.onTokenRefresh;
///     }
///
///  4. Pass `push: FcmPushService()` to AppScope in main.dart instead of NoopPushService.
abstract class PushService {
  /// Current token, or null when push is unavailable / permission was denied.
  Future<String?> getToken();

  /// Emits a new token whenever the provider rotates it.
  Stream<String> get onTokenRefresh;
}

/// Default: push disabled.
class NoopPushService implements PushService {
  const NoopPushService();

  @override
  Future<String?> getToken() async => null;

  @override
  Stream<String> get onTokenRefresh => const Stream<String>.empty();
}

/// Value for the `platform` field of `POST /push-tokens`.
String currentPushPlatform() {
  if (kIsWeb) return 'web';
  return defaultTargetPlatform == TargetPlatform.iOS ? 'ios' : 'android';
}
