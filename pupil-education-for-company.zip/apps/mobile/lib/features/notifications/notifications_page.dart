import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/errors.dart';
import '../../core/utils.dart';
import '../../core/widgets.dart';
import 'notification_models.dart';

IconData _iconFor(String type) {
  switch (type) {
    case 'lesson_opened':
      return Icons.play_circle_outline;
    case 'quiz_created':
    case 'quiz_due_soon':
      return Icons.quiz_outlined;
    case 'subscription_expiring':
      return Icons.timer_outlined;
    case 'enrolled':
      return Icons.verified_outlined;
    case 'graded':
      return Icons.grading;
    case 'announcement':
      return Icons.campaign_outlined;
    default:
      return Icons.notifications_none;
  }
}

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key, this.onChanged});

  /// Called after read / read-all so the shell can refresh its unread badge.
  final VoidCallback? onChanged;

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  List<AppNotification>? _items;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = AppScope.read(context).notifications;
    try {
      final items = await repo.list();
      if (!mounted) return;
      setState(() {
        _items = items;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e);
    }
  }

  Future<void> _markRead(AppNotification n) async {
    if (n.read) return;
    final repo = AppScope.read(context).notifications;
    _replace(n.id, (x) => x.copyWith(read: true));
    try {
      await repo.markRead(n.id);
      widget.onChanged?.call();
    } catch (e) {
      if (!mounted) return;
      _replace(n.id, (x) => x.copyWith(read: false));
      showSnack(context, friendlyError(e));
    }
  }

  Future<void> _markAll() async {
    final repo = AppScope.read(context).notifications;
    try {
      await repo.markAllRead();
      if (!mounted) return;
      setState(() => _items = [for (final n in _items ?? <AppNotification>[]) n.copyWith(read: true)]);
      widget.onChanged?.call();
    } catch (e) {
      if (!mounted) return;
      showSnack(context, friendlyError(e));
    }
  }

  void _replace(String id, AppNotification Function(AppNotification) f) {
    if (!mounted) return;
    setState(() => _items = [for (final n in _items ?? <AppNotification>[]) n.id == id ? f(n) : n]);
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    final hasUnread = items != null && items.any((n) => !n.read);
    return Scaffold(
      appBar: AppBar(
        title: const Text('الإشعارات'),
        actions: [
          if (hasUnread) TextButton(onPressed: _markAll, child: const Text('قراءة الكل')),
        ],
      ),
      body: _body(items),
    );
  }

  Widget _body(List<AppNotification>? items) {
    if (items == null) {
      if (_error != null) {
        return ErrorView(
          error: _error!,
          onRetry: () {
            setState(() => _error = null);
            _load();
          },
        );
      }
      return const Center(child: CircularProgressIndicator());
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: items.isEmpty
          ? ListView(physics: const AlwaysScrollableScrollPhysics(), children: const [EmptyView('مفيش إشعارات.')])
          : ListView.separated(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final n = items[i];
                final date = n.createdAt;
                return ListTile(
                  leading: Icon(_iconFor(n.type)),
                  title: Text(n.title, style: TextStyle(fontWeight: n.read ? FontWeight.normal : FontWeight.bold)),
                  subtitle: Text(date == null ? n.body : '${n.body}\n${formatDateTime(date.toLocal())}'),
                  isThreeLine: date != null,
                  trailing: n.read ? null : const Icon(Icons.circle, size: 10, color: Colors.red),
                  onTap: () => _markRead(n),
                );
              },
            ),
    );
  }
}
