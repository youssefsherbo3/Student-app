import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/widgets.dart';
import 'quiz_models.dart';

/// Review of one submission: the student's answers, and the correct ones only when the server reveals them.
class ReviewPage extends StatelessWidget {
  const ReviewPage({super.key, required this.submissionId, this.quizTitle = ''});

  final String submissionId;
  final String quizTitle;

  @override
  Widget build(BuildContext context) {
    final repo = AppScope.of(context).quizzes;
    return Scaffold(
      appBar: AppBar(title: Text(quizTitle.isEmpty ? 'مراجعة المحاولة' : 'مراجعة: $quizTitle')),
      body: AsyncView<Review>(
        load: () => repo.review(submissionId),
        builder: (context, review, reload) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _Summary(review: review),
            if (!review.answersVisible)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  'الإجابات الصحيحة هتظهر بعد انتهاء موعد الامتحان أو المحاولات.',
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            for (final it in review.items) _ItemCard(item: it, essayPending: review.essayPending),
          ],
        ),
      ),
    );
  }
}

class _Summary extends StatelessWidget {
  const _Summary({required this.review});

  final Review review;

  @override
  Widget build(BuildContext context) {
    final lines = <String>[
      if (review.mcqTotal > 0) 'الاختياري: ${review.score} / ${review.mcqTotal}',
      if (review.essayTotal > 0)
        review.essayPending ? 'المقالي: بانتظار تصحيح المساعد' : 'المقالي: ${review.essayScore ?? 0} / ${review.essayTotal}',
    ];
    final feedback = review.feedback;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final l in lines) Text(l, style: const TextStyle(fontWeight: FontWeight.bold)),
            if (feedback != null && feedback.isNotEmpty) Text('ملاحظة المصحّح: $feedback'),
          ],
        ),
      ),
    );
  }
}

class _ItemCard extends StatelessWidget {
  const _ItemCard({required this.item, required this.essayPending});

  final ReviewItem item;
  final bool essayPending;

  Widget _option(int i) {
    final chosen = item.chosenIndex == i;
    final correct = item.correctIndex == i;
    IconData icon = chosen ? Icons.radio_button_checked : Icons.radio_button_unchecked;
    Color? color;
    if (correct) {
      icon = Icons.check_circle;
      color = Colors.green;
    } else if (chosen && item.correctIndex != null) {
      icon = Icons.cancel;
      color = Colors.red;
    }
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: color),
      title: Text(item.options[i], style: TextStyle(fontWeight: chosen ? FontWeight.bold : FontWeight.normal)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${item.body}  (${item.points} درجة)', style: const TextStyle(fontWeight: FontWeight.bold)),
            if (item.imageUrl != null) ...[
              const SizedBox(height: 8),
              Center(child: NetImage(item.imageUrl!)),
            ],
            if (item.isEssay) ...[
              const SizedBox(height: 8),
              Text('إجابتك: ${item.yourAnswer ?? '-'}'),
              for (final id in item.yourImages)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Center(child: AuthImage(id)),
                ),
              if (essayPending) const Text('بانتظار تصحيح المساعد', style: TextStyle(color: Colors.orange)),
            ] else
              for (var i = 0; i < item.options.length; i++) _option(i),
          ],
        ),
      ),
    );
  }
}
