import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/utils.dart';
import '../../core/widgets.dart';
import 'quiz_models.dart';
import 'review_page.dart';

/// The student's own submissions for one quiz, newest first.
class AttemptsPage extends StatelessWidget {
  const AttemptsPage({super.key, required this.quiz});

  final Quiz quiz;

  @override
  Widget build(BuildContext context) {
    final repo = AppScope.of(context).quizzes;
    return Scaffold(
      appBar: AppBar(title: Text('نتائجي: ${quiz.title}')),
      body: AsyncView<List<Attempt>>(
        load: () => repo.attempts(quiz.id),
        builder: (context, attempts, reload) {
          if (attempts.isEmpty) {
            return RefreshIndicator(
              onRefresh: reload,
              child: ListView(physics: const AlwaysScrollableScrollPhysics(), children: const [EmptyView('لسه ما سلّمتش أي محاولة.')]),
            );
          }
          // Number attempts oldest = 1, then show the newest first.
          final oldestFirst = List<Attempt>.of(attempts)
            ..sort((a, b) => (a.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0)).compareTo(b.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0)));
          final shown = oldestFirst.reversed.toList();
          return RefreshIndicator(
            onRefresh: reload,
            child: ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: shown.length,
              itemBuilder: (context, i) {
                final a = shown[i];
                final n = shown.length - i;
                final essay = a.essayScore != null ? ' + مقالي ${a.essayScore}' : '';
                final date = a.createdAt;
                return ListTile(
                  leading: const Icon(Icons.fact_check),
                  title: Text('المحاولة $n: ${a.score}$essay'),
                  subtitle: date == null ? null : Text(formatDateTime(date.toLocal())),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => pushPage<void>(context, ReviewPage(submissionId: a.id, quizTitle: quiz.title)),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
