import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../core/api_client.dart';
import '../../core/app_scope.dart';
import '../../core/errors.dart';
import '../../core/image_picker_service.dart';
import '../../core/utils.dart';
import '../../core/widgets.dart';
import '../uploads/uploads_repository.dart';
import 'attempts_page.dart';
import 'quiz_models.dart';

/// Error codes after which the attempt cannot continue (deadline passed / no valid session).
const Set<String> quizSessionErrorCodes = <String>{'time_over', 'no_session', 'session_required', 'not_started'};

/// A photo attached to an essay answer. [id] is set once the upload finished.
class _Pic {
  _Pic(this.bytes);

  final Uint8List bytes;
  String? id;
  bool uploading = true;
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key, required this.quiz, this.now = systemNow});

  final Quiz quiz;

  /// Wall clock (injectable for tests).
  final DateTime Function() now;

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  static const int _maxPhotos = 4;

  /// question id -> DISPLAYED option position (mcq) or trimmed text (essay). Missing = unanswered.
  final Map<String, Object> _answers = <String, Object>{};

  /// essay question id -> attached photos.
  final Map<String, List<_Pic>> _pics = <String, List<_Pic>>{};

  QuizStart? _data;
  Object? _error;
  bool _starting = false;
  bool _busy = false;
  Timer? _ticker;
  QuizCountdown? _countdown;
  int? _remaining;

  @override
  void initState() {
    super.initState();
    if (widget.quiz.canSubmit && !widget.quiz.isTimed) {
      // Untimed quizzes open straight away; timed ones wait for an explicit "start" (it burns an attempt).
      _starting = true;
      _run();
    }
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  void _begin() {
    setState(() {
      _starting = true;
      _error = null;
    });
    _run();
  }

  Future<void> _run() async {
    final repo = AppScope.read(context).quizzes;
    try {
      final s = await repo.start(widget.quiz.id);
      if (!mounted) return;
      final end = s.endsAt;
      setState(() {
        _data = s;
        _starting = false;
      });
      if (s.isTimed && end != null) {
        final now = widget.now();
        _countdown = QuizCountdown(endsAt: end, serverNow: s.serverNow, deviceNow: now);
        _remaining = _countdown!.remainingSeconds(now);
        _ticker?.cancel();
        _ticker = Timer.periodic(const Duration(seconds: 1), _tick);
        if (_remaining == 0) _timeUp();
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _starting = false;
        _error = e;
      });
    }
  }

  void _tick(Timer t) {
    if (!mounted) {
      t.cancel();
      return;
    }
    final c = _countdown;
    if (c == null) return;
    final r = c.remainingSeconds(widget.now());
    setState(() => _remaining = r);
    if (r == 0) {
      t.cancel();
      _timeUp();
    }
  }

  /// Time is over: submit whatever has been answered so far.
  void _timeUp() {
    if (_busy) return;
    _submit(auto: true);
  }

  bool get _expired => _countdown != null && _remaining == 0;

  bool _hasPhoto(String qid) => (_pics[qid] ?? const <_Pic>[]).any((p) => p.id != null);

  bool _answered(Question q) => q.isEssay ? (_answers.containsKey(q.id) || _hasPhoto(q.id)) : _answers.containsKey(q.id);

  bool _complete(List<Question> qs) => qs.isNotEmpty && qs.every(_answered);

  bool get _uploading => _pics.values.any((l) => l.any((p) => p.uploading));

  String _summary(SubmitResult r) {
    final lines = <String>[
      if (r.mcqTotal > 0) 'الاختياري: ${r.score} / ${r.mcqTotal} (${percent(r.score, r.mcqTotal)}%)',
      if (r.hasEssay) 'الأسئلة المقالية هتتصحّح بواسطة المساعد.',
    ];
    return lines.isEmpty ? 'تم تسليم إجاباتك.' : lines.join('\n');
  }

  Map<String, List<String>> _imageIds() {
    final out = <String, List<String>>{};
    _pics.forEach((qid, list) {
      final ids = <String>[
        for (final p in list)
          if (p.id != null) p.id!,
      ];
      if (ids.isNotEmpty) out[qid] = ids;
    });
    return out;
  }

  Future<void> _submit({bool auto = false}) async {
    if (_busy) return;
    final repo = AppScope.read(context).quizzes;
    setState(() => _busy = true);
    try {
      final result = await repo.submit(
        widget.quiz.id,
        Map<String, Object>.of(_answers),
        sessionId: _data?.sessionId,
        images: _imageIds(),
      );
      _ticker?.cancel();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: Text(auto ? 'انتهى الوقت وتم تسليم إجاباتك' : 'تم التسليم'),
          content: Text(_summary(result)),
          actions: [TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('تمام'))],
        ),
      );
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      if (e is ApiException && quizSessionErrorCodes.contains(e.code)) {
        // The attempt is over; nothing more can be sent. Explain and leave.
        _ticker?.cancel();
        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            content: Text(friendlyError(e)),
            actions: [TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('تمام'))],
          ),
        );
        if (!mounted) return;
        Navigator.of(context).pop(true);
        return;
      }
      showSnack(context, friendlyError(e));
    }
  }

  void _setAnswer(String id, Object? value) {
    setState(() {
      if (value == null) {
        _answers.remove(id);
      } else {
        _answers[id] = value;
      }
    });
  }

  Future<void> _addPhoto(Question q, ImagePickSource source) async {
    final scope = AppScope.read(context);
    PickedImage? img;
    try {
      img = await scope.imagePicker.pick(source);
    } catch (_) {
      if (!mounted) return;
      showSnack(context, 'تعذّر فتح الصورة.');
      return;
    }
    if (img == null || !mounted) return;
    final pic = _Pic(img.bytes);
    setState(() => _pics.putIfAbsent(q.id, () => <_Pic>[]).add(pic));
    try {
      final res = await scope.uploads.upload(img, UploadKind.answer);
      if (!mounted) return;
      setState(() {
        pic.id = res.id;
        pic.uploading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _pics[q.id]?.remove(pic));
      showSnack(context, friendlyError(e));
    }
  }

  void _removePhoto(Question q, _Pic pic) => setState(() => _pics[q.id]?.remove(pic));

  Widget _photos(Question q) {
    final list = _pics[q.id] ?? const <_Pic>[];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        if (list.length < _maxPhotos)
          Wrap(spacing: 8, children: [
            OutlinedButton.icon(
              onPressed: _busy ? null : () => _addPhoto(q, ImagePickSource.gallery),
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('صورة من المعرض'),
            ),
            OutlinedButton.icon(
              onPressed: _busy ? null : () => _addPhoto(q, ImagePickSource.camera),
              icon: const Icon(Icons.photo_camera_outlined),
              label: const Text('تصوير'),
            ),
          ]),
        if (list.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in list)
                Stack(children: [
                  SizedBox(
                    width: 96,
                    height: 96,
                    child: Image.memory(
                      p.bytes,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stack) => const Icon(Icons.image_outlined),
                    ),
                  ),
                  if (p.uploading)
                    const Positioned.fill(child: ColoredBox(color: Colors.black38, child: Center(child: CircularProgressIndicator(strokeWidth: 2)))),
                  PositionedDirectional(
                    top: 0,
                    end: 0,
                    child: InkWell(
                      onTap: _busy ? null : () => _removePhoto(q, p),
                      child: const CircleAvatar(radius: 12, child: Icon(Icons.close, size: 14)),
                    ),
                  ),
                ]),
            ]),
          ),
      ],
    );
  }

  Widget _questionCard(Question q, int number) {
    final img = q.imageUrl;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$number) ${q.body}  (${q.points} درجة)', style: const TextStyle(fontWeight: FontWeight.bold)),
            if (img != null) ...[
              const SizedBox(height: 8),
              Center(child: NetImage(img)),
            ],
            const SizedBox(height: 8),
            if (q.isEssay) ...[
              TextField(
                maxLines: 5,
                decoration: const InputDecoration(hintText: 'اكتب إجابتك (أو أرفق صورة)'),
                onChanged: (v) {
                  final t = v.trim();
                  _setAnswer(q.id, t.isEmpty ? null : t);
                },
              ),
              _photos(q),
            ] else
              // The index in q.options IS the displayed position the server expects on submit.
              for (var i = 0; i < q.options.length; i++)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  leading: Icon(_answers[q.id] == i ? Icons.radio_button_checked : Icons.radio_button_unchecked),
                  title: Text(q.options[i]),
                  onTap: () => _setAnswer(q.id, i),
                ),
          ],
        ),
      ),
    );
  }

  Widget _timerBar() {
    final r = _remaining;
    if (r == null) return const SizedBox.shrink();
    final scheme = Theme.of(context).colorScheme;
    final low = r <= 60;
    return Material(
      color: low ? scheme.errorContainer : scheme.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.timer_outlined, color: low ? scheme.error : null),
          const SizedBox(width: 8),
          Text(
            r == 0 ? 'انتهى الوقت' : 'الوقت المتبقي: ${formatDuration(r)}',
            style: TextStyle(fontWeight: FontWeight.bold, color: low ? scheme.error : null),
          ),
        ]),
      ),
    );
  }

  Widget _intro() {
    final mins = widget.quiz.timeLimitMinutes ?? 0;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.timer_outlined, size: 48),
          const SizedBox(height: 12),
          Text('امتحان بوقت محدد: $mins دقيقة', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text(
            'العدّاد بيبدأ أول ما تدوس "ابدأ"، وبيتحسب ده محاولة. لو الوقت خلص هتتسلّم إجاباتك تلقائيًا.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          FilledButton(onPressed: _begin, child: const Text('ابدأ الامتحان')),
        ]),
      ),
    );
  }

  Widget _form(List<Question> qs) {
    if (qs.isEmpty) return const EmptyView('مفيش أسئلة لسه.');
    final canPress = !_busy && !_uploading && (_complete(qs) || _expired);
    return Column(
      children: [
        _timerBar(),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var i = 0; i < qs.length; i++) _questionCard(qs[i], i + 1),
                FilledButton(
                  onPressed: canPress ? _submit : null,
                  child: Text(_busy ? 'جاري التسليم...' : 'تسليم'),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _body() {
    final quiz = widget.quiz;
    if (!quiz.canSubmit) {
      return EmptyView(quiz.closed ? 'الامتحان ده اتقفل. تقدر تشوف نتايجك من أيقونة السجل.' : 'خلصت كل محاولاتك. تقدر تشوف نتايجك من أيقونة السجل.');
    }
    final data = _data;
    if (data != null) return _form(data.questions);
    final err = _error;
    if (err != null) return ErrorView(error: err, onRetry: _begin);
    if (quiz.isTimed && !_starting) return _intro();
    return const Center(child: CircularProgressIndicator());
  }

  @override
  Widget build(BuildContext context) {
    final quiz = widget.quiz;
    return Scaffold(
      appBar: AppBar(
        title: Text(quiz.title),
        actions: [
          IconButton(
            tooltip: 'نتائجي',
            icon: const Icon(Icons.history),
            onPressed: () => pushPage<void>(context, AttemptsPage(quiz: quiz)),
          ),
        ],
      ),
      body: _body(),
    );
  }
}
