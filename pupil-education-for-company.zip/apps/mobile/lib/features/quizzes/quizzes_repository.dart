import '../../core/api_client.dart';
import '../../core/utils.dart';
import 'quiz_models.dart';

abstract class QuizzesRepository {
  Future<List<Quiz>> list(String courseId);

  /// Plain question list (untimed quizzes only; timed ones answer 409 `not_started`). The quiz page uses [start].
  Future<List<Question>> questions(String quizId);

  /// `POST /quizzes/:id/start`: questions in the displayed order, plus session + deadline for timed quizzes.
  /// Calling it again while the session is open returns the same session.
  Future<QuizStart> start(String quizId);

  /// answers: question id -> DISPLAYED option position (int) for mcq, or text (String) for essay.
  /// [sessionId] is mandatory for timed quizzes. [images]: essay question id -> uploaded answer image ids.
  Future<SubmitResult> submit(
    String quizId,
    Map<String, Object> answers, {
    String? sessionId,
    Map<String, List<String>> images = const <String, List<String>>{},
  });

  Future<List<Attempt>> attempts(String quizId);

  Future<Review> review(String submissionId);
}

class HttpQuizzesRepository implements QuizzesRepository {
  HttpQuizzesRepository(this._api);

  final ApiClient _api;

  Map<String, dynamic> _map(dynamic data) => data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};

  @override
  Future<List<Quiz>> list(String courseId) async =>
      parseList<Quiz>(await _api.get('/courses/$courseId/quizzes'), Quiz.fromJson);

  @override
  Future<List<Question>> questions(String quizId) async =>
      parseList<Question>(await _api.get('/quizzes/$quizId/questions'), Question.fromJson);

  @override
  Future<QuizStart> start(String quizId) async => QuizStart.fromJson(_map(await _api.post('/quizzes/$quizId/start')));

  @override
  Future<SubmitResult> submit(
    String quizId,
    Map<String, Object> answers, {
    String? sessionId,
    Map<String, List<String>> images = const <String, List<String>>{},
  }) async {
    final body = <String, Object>{
      'answers': answers,
      if (sessionId != null) 'sessionId': sessionId,
      if (images.isNotEmpty) 'images': images,
    };
    final data = await _api.post('/quizzes/$quizId/submit', body: body);
    return SubmitResult.fromJson(_map(data));
  }

  @override
  Future<List<Attempt>> attempts(String quizId) async =>
      parseList<Attempt>(await _api.get('/quizzes/$quizId/attempts'), Attempt.fromJson);

  @override
  Future<Review> review(String submissionId) async => Review.fromJson(_map(await _api.get('/submissions/$submissionId')));
}
