import '../../core/utils.dart';

List<String> _strings(Object? v) => v is List ? <String>[for (final e in v) '$e'] : <String>[];

class Quiz {
  const Quiz({
    required this.id,
    required this.title,
    this.kind = 'quiz',
    this.maxAttempts,
    this.dueAt,
    this.attemptsUsed,
    this.closed = false,
    this.timeLimitMinutes,
  });

  final String id;
  final String title;

  /// `quiz` or `homework`.
  final String kind;
  final int? maxAttempts;
  final DateTime? dueAt;
  final int? attemptsUsed;
  final bool closed;

  /// null = untimed.
  final int? timeLimitMinutes;

  bool get isTimed => (timeLimitMinutes ?? 0) > 0;

  bool get isHomework => kind == 'homework';

  bool get noAttemptsLeft => maxAttempts != null && (attemptsUsed ?? 0) >= maxAttempts!;

  bool get canSubmit => !closed && !noAttemptsLeft;

  factory Quiz.fromJson(Map<String, dynamic> j) => Quiz(
        id: asString(j['id']),
        title: asString(j['title']),
        kind: asString(j['kind'], 'quiz'),
        maxAttempts: asIntOrNull(j['maxAttempts']),
        dueAt: parseDate(j['dueAt']),
        attemptsUsed: asIntOrNull(j['attemptsUsed']),
        closed: j['closed'] == true,
        timeLimitMinutes: asIntOrNull(j['timeLimitMinutes']),
      );
}

class Question {
  const Question({
    required this.id,
    required this.body,
    this.kind = 'mcq',
    this.options = const <String>[],
    this.points = 1,
    this.position = 0,
    this.imageUrl,
  });

  final String id;
  final String body;
  final String kind;
  final List<String> options;
  final int points;
  final int position;

  /// Server-relative path or full URL; null when the question has no picture.
  final String? imageUrl;

  bool get isEssay => kind == 'essay';

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: asString(j['id']),
        body: asString(j['body']),
        kind: asString(j['kind'], 'mcq'),
        options: _strings(j['options']),
        points: asInt(j['points'], 1),
        position: asInt(j['position']),
        imageUrl: asStringOrNull(j['imageUrl']),
      );
}

/// Response of `POST /quizzes/:id/start`. [questions] come in the order (and with the option order) shown to
/// the student, so the index of a chosen option in [Question.options] is the "displayed position" the server expects.
class QuizStart {
  const QuizStart({required this.questions, this.sessionId, this.endsAt, this.serverNow});

  /// null for untimed quizzes.
  final String? sessionId;
  final DateTime? endsAt;
  final DateTime? serverNow;
  final List<Question> questions;

  bool get isTimed => sessionId != null && endsAt != null;

  factory QuizStart.fromJson(Map<String, dynamic> j) => QuizStart(
        sessionId: asStringOrNull(j['sessionId']),
        endsAt: parseDate(j['endsAt']),
        serverNow: parseDate(j['serverNow']),
        questions: parseList<Question>(j['questions'], Question.fromJson),
      );
}

/// Pure countdown maths for a timed quiz. The device clock may be off, so the offset between the server's
/// `serverNow` and the device clock at the moment of the response is applied to every reading.
class QuizCountdown {
  QuizCountdown({required this.endsAt, DateTime? serverNow, required DateTime deviceNow})
      : _offset = serverNow == null ? Duration.zero : serverNow.difference(deviceNow);

  final DateTime endsAt;
  final Duration _offset;

  /// Whole seconds left (rounded up so "0:00" only shows once time is really over); never negative.
  int remainingSeconds(DateTime deviceNow) {
    final ms = endsAt.difference(deviceNow.add(_offset)).inMilliseconds;
    if (ms <= 0) return 0;
    return (ms + 999) ~/ 1000;
  }

  bool isExpired(DateTime deviceNow) => remainingSeconds(deviceNow) == 0;
}

class SubmitResult {
  const SubmitResult({required this.id, required this.score, required this.mcqTotal, required this.hasEssay});

  final String id;
  final int score;
  final int mcqTotal;
  final bool hasEssay;

  factory SubmitResult.fromJson(Map<String, dynamic> j) => SubmitResult(
        id: asString(j['id']),
        score: asInt(j['score']),
        mcqTotal: asInt(j['mcqTotal']),
        hasEssay: j['hasEssay'] == true,
      );
}

class Attempt {
  const Attempt({required this.id, required this.score, this.essayScore, this.feedback, this.createdAt});

  final String id;
  final int score;
  final int? essayScore;
  final String? feedback;
  final DateTime? createdAt;

  factory Attempt.fromJson(Map<String, dynamic> j) => Attempt(
        id: asString(j['id']),
        score: asInt(j['score']),
        essayScore: asIntOrNull(j['essayScore']),
        feedback: j['feedback'] as String?,
        createdAt: parseDate(j['createdAt']),
      );
}

class ReviewItem {
  const ReviewItem({
    required this.questionId,
    required this.kind,
    required this.body,
    this.options = const <String>[],
    this.points = 1,
    this.yourAnswer,
    this.correctIndex,
    this.imageUrl,
    this.yourImages = const <String>[],
  });

  final String questionId;
  final String kind;
  final String body;
  final List<String> options;
  final int points;

  /// Option index as text for mcq, free text for essay.
  final String? yourAnswer;

  /// null while the correct answers are hidden.
  final int? correctIndex;

  final String? imageUrl;

  /// Upload ids of the student's photo answers (essay); fetch with `GET /uploads/:id`.
  final List<String> yourImages;

  bool get isEssay => kind == 'essay';

  int? get chosenIndex => int.tryParse(yourAnswer ?? '');

  factory ReviewItem.fromJson(Map<String, dynamic> j) => ReviewItem(
        questionId: asString(j['questionId']),
        kind: asString(j['kind'], 'mcq'),
        body: asString(j['body']),
        options: _strings(j['options']),
        points: asInt(j['points'], 1),
        yourAnswer: j['yourAnswer'] == null ? null : '${j['yourAnswer']}',
        correctIndex: asIntOrNull(j['correctIndex']),
        imageUrl: asStringOrNull(j['imageUrl']),
        yourImages: _strings(j['yourImages']),
      );
}

class Review {
  const Review({
    required this.score,
    required this.mcqTotal,
    required this.essayScore,
    required this.essayTotal,
    required this.essayPending,
    required this.answersVisible,
    required this.items,
    this.feedback,
  });

  final int score;
  final int mcqTotal;
  final int? essayScore;
  final int essayTotal;
  final bool essayPending;
  final String? feedback;
  final bool answersVisible;
  final List<ReviewItem> items;

  factory Review.fromJson(Map<String, dynamic> j) => Review(
        score: asInt(j['score']),
        mcqTotal: asInt(j['mcqTotal']),
        essayScore: asIntOrNull(j['essayScore']),
        essayTotal: asInt(j['essayTotal']),
        essayPending: j['essayPending'] == true,
        feedback: j['feedback'] as String?,
        answersVisible: j['answersVisible'] == true,
        items: parseList<ReviewItem>(j['items'], ReviewItem.fromJson),
      );
}
