import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../core/api_client.dart';
import '../../core/app_scope.dart';
import '../../core/errors.dart';
import '../../core/utils.dart';
import '../../core/watermark.dart';
import '../../core/widgets.dart';
import 'lesson_models.dart';
import 'lesson_video.dart';

typedef VideoBuilder = Widget Function(BuildContext context, String embedUrl);

class LessonPage extends StatefulWidget {
  const LessonPage({super.key, required this.lesson, this.videoBuilder});

  final Lesson lesson;

  /// Override the player (tests use this because WebView needs a platform implementation).
  final VideoBuilder? videoBuilder;

  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  int? _remaining; // null = still loading / failed
  String? _error;
  bool _busy = false;
  Timer? _timer;
  Timer? _heartbeat;

  /// Attendance ping period.
  static const Duration heartbeatEvery = Duration(seconds: 30);

  @override
  void initState() {
    super.initState();
    if (!widget.lesson.locked) _start();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _heartbeat?.cancel();
    super.dispose();
  }

  Future<void> _start() async {
    final repo = AppScope.read(context).lessons;
    try {
      final s = await repo.start(widget.lesson.id);
      if (!mounted) return;
      _timer?.cancel();
      final secs = s.remainingSeconds < 0 ? 0 : s.remainingSeconds;
      setState(() {
        _remaining = secs;
        _error = null;
      });
      if (secs > 0) _timer = Timer.periodic(const Duration(seconds: 1), _tick);
      _heartbeat ??= Timer.periodic(heartbeatEvery, (_) => _beat());
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = friendlyError(e));
    }
  }

  /// Best effort: a failed ping must never disturb the student.
  Future<void> _beat() async {
    if (!mounted) return;
    try {
      await AppScope.read(context).lessons.heartbeat(widget.lesson.id);
    } catch (_) {}
  }

  void _tick(Timer t) {
    if (!mounted) {
      t.cancel();
      return;
    }
    final r = _remaining ?? 0;
    if (r <= 1) t.cancel();
    setState(() => _remaining = r <= 1 ? 0 : r - 1);
  }

  void _retry() {
    setState(() => _error = null);
    _start();
  }

  Future<void> _complete() async {
    final repo = AppScope.read(context).lessons;
    setState(() => _busy = true);
    try {
      await repo.complete(widget.lesson.id);
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      showSnack(context, friendlyError(e));
      // The server is the authority on the timer: resync after "too early".
      if (e is ApiException && e.code == 'too_early') _start();
    }
  }

  String get _label {
    final r = _remaining;
    if (r == null) return 'جاري التحميل...';
    if (r == 0) return 'خلّصت الدرس';
    return 'متاح بعد ${formatDuration(r)}';
  }

  Widget _video(BuildContext context) {
    final url = embedUrl(widget.lesson.videoUrl);
    if (url == null) {
      return const AspectRatio(
        aspectRatio: 16 / 9,
        child: ColoredBox(
          color: Colors.black12,
          child: Center(child: Text('لينك الفيديو مفقود أو غير مدعوم (يوتيوب/ڤيميو فقط)', textAlign: TextAlign.center)),
        ),
      );
    }
    final builder = widget.videoBuilder;
    final user = AppScope.of(context).auth.user.value;
    final mark = [user?.name, user?.phone].whereType<String>().where((e) => e.isNotEmpty).join(' - ');
    return AspectRatio(
      aspectRatio: 16 / 9,
      child: Watermark(text: mark, child: builder != null ? builder(context, url) : LessonVideo(url: url)),
    );
  }

  String? _openingFile;

  Future<void> _openFile(LessonFile f) async {
    if (_openingFile != null) return;
    final scope = AppScope.read(context);
    setState(() => _openingFile = f.id);
    try {
      final Uint8List bytes = await scope.lessons.downloadFile(f.id);
      await scope.pdf.open(bytes, f.title.toLowerCase().endsWith('.pdf') ? f.title : '${f.title}.pdf');
    } catch (e) {
      if (mounted) showSnack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _openingFile = null);
    }
  }

  Widget _handouts() {
    final files = widget.lesson.files;
    if (files.isEmpty) return const SizedBox.shrink();
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text('الملازم', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          for (final f in files)
            ListTile(
              leading: const Icon(Icons.picture_as_pdf_outlined),
              title: Text(f.title),
              subtitle: f.size > 0 ? Text('${(f.size / 1024).ceil()} ك.ب') : null,
              trailing: _openingFile == f.id
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.download_outlined),
              onTap: () => _openFile(f),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lesson = widget.lesson;
    if (lesson.locked) {
      return Scaffold(
        appBar: AppBar(title: Text(lesson.title)),
        body: const EmptyView('الدرس ده لسه مقفول.'),
      );
    }
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(lesson.title)),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _video(context),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (_error != null) ...[
                    Text(_error!, style: TextStyle(color: scheme.error)),
                    TextButton(onPressed: _retry, child: const Text('حاول تاني')),
                  ],
                  const SizedBox(height: 8),
                  _handouts(),
                  const SizedBox(height: 8),
                  FilledButton(
                    onPressed: (_remaining == 0 && !_busy) ? _complete : null,
                    child: Text(_label),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
