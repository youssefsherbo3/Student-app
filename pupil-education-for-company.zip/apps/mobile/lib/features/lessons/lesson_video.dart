import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../core/config.dart';
import '../../core/utils.dart';

/// Embedded YouTube/Vimeo player. Player links must not navigate the app away from the lesson.
class LessonVideo extends StatefulWidget {
  const LessonVideo({super.key, required this.url});

  final String url;

  @override
  State<LessonVideo> createState() => _LessonVideoState();
}

class _LessonVideoState extends State<LessonVideo> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController();
    if (kIsWeb) {
      // webview_flutter_web renders an <iframe> and only supports loadRequest.
      _controller.loadRequest(Uri.parse(widget.url));
    } else {
      // Mobile: load a tiny HTML page so the player gets a real origin (needed by some Vimeo settings).
      _controller
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(
          NavigationDelegate(
            onNavigationRequest: (request) {
              if (!request.isMainFrame) return NavigationDecision.navigate;
              final destination = Uri.tryParse(request.url);
              final origin = Uri.tryParse(AppConfig.embedOrigin);
              final staysInPlayer =
                  destination != null &&
                  origin != null &&
                  destination.scheme == origin.scheme &&
                  destination.host == origin.host;
              return staysInPlayer
                  ? NavigationDecision.navigate
                  : NavigationDecision.prevent;
            },
          ),
        )
        ..setBackgroundColor(Colors.black)
        ..loadHtmlString(videoHtml(widget.url), baseUrl: AppConfig.embedOrigin);
    }
  }

  @override
  Widget build(BuildContext context) => WebViewWidget(controller: _controller);
}
