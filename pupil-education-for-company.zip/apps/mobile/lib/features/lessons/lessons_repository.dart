import 'dart:typed_data';

import '../../core/api_client.dart';
import '../../core/utils.dart';
import 'lesson_models.dart';

abstract class LessonsRepository {
  Future<List<Lesson>> list(String courseId);

  /// Call when the video is opened; returns the seconds left before the lesson can be completed.
  Future<LessonStart> start(String lessonId);

  /// Attendance ping, sent about every 30s while the lesson is open. Throws `not_started` before [start].
  Future<void> heartbeat(String lessonId);

  /// `GET /lesson-files/:id` — the PDF bytes (needs auth, so it can't be a plain URL).
  Future<Uint8List> downloadFile(String fileId);

  /// Throws ApiException `too_early` / `locked_lesson`.
  Future<void> complete(String lessonId);
}

class HttpLessonsRepository implements LessonsRepository {
  HttpLessonsRepository(this._api);

  final ApiClient _api;

  @override
  Future<List<Lesson>> list(String courseId) async =>
      parseList<Lesson>(await _api.get('/courses/$courseId/lessons'), Lesson.fromJson);

  @override
  Future<LessonStart> start(String lessonId) async {
    final data = await _api.post('/lessons/$lessonId/start');
    return LessonStart.fromJson(data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{});
  }

  @override
  Future<void> complete(String lessonId) async {
    await _api.post('/lessons/$lessonId/complete');
  }

  @override
  Future<Uint8List> downloadFile(String fileId) => _api.getBytes('/lesson-files/$fileId');

  @override
  Future<void> heartbeat(String lessonId) async {
    await _api.post('/lessons/$lessonId/heartbeat');
  }
}
