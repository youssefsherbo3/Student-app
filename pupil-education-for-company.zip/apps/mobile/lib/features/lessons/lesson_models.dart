import '../../core/utils.dart';

class Lesson {
  const Lesson({
    required this.id,
    required this.title,
    this.position = 0,
    this.opensAt,
    this.locked = false,
    this.done = false,
    this.minSeconds = 0,
    this.unlockAfterQuizId,
    this.unlockAfterQuizTitle,
    this.assessmentLocked = false,
    this.videoUrl,
    this.files = const <LessonFile>[],
  });

  final String id;
  final String title;
  final int position;
  final DateTime? opensAt;
  final bool locked;
  final bool done;
  final int minSeconds;
  final String? unlockAfterQuizId;
  final String? unlockAfterQuizTitle;
  final bool assessmentLocked;

  /// null when the lesson is locked.
  final String? videoUrl;

  /// Handouts (PDF). Empty while the lesson is locked.
  final List<LessonFile> files;

  factory Lesson.fromJson(Map<String, dynamic> j) => Lesson(
        id: asString(j['id']),
        title: asString(j['title']),
        position: asInt(j['position']),
        opensAt: parseDate(j['opensAt']),
        locked: j['locked'] == true,
        done: j['done'] == true,
        minSeconds: asInt(j['minSeconds']),
        unlockAfterQuizId: j['unlockAfterQuizId'] as String?,
        unlockAfterQuizTitle: j['unlockAfterQuizTitle'] as String?,
        assessmentLocked: j['assessmentLocked'] == true,
        videoUrl: j['videoUrl'] as String?,
        files: parseList<LessonFile>(j['files'], LessonFile.fromJson),
      );
}

class LessonFile {
  const LessonFile({required this.id, required this.title, this.size = 0});

  final String id;
  final String title;
  final int size;

  factory LessonFile.fromJson(Map<String, dynamic> j) =>
      LessonFile(id: asString(j['id']), title: asString(j['title']), size: asInt(j['size']));
}

class LessonStart {
  const LessonStart({required this.remainingSeconds, this.startedAt});

  final int remainingSeconds;
  final DateTime? startedAt;

  factory LessonStart.fromJson(Map<String, dynamic> j) =>
      LessonStart(remainingSeconds: asInt(j['remainingSeconds']), startedAt: parseDate(j['startedAt']));
}
