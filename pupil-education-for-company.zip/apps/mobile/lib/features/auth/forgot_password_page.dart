import 'package:flutter/material.dart';

import '../../core/api_client.dart';
import '../../core/app_scope.dart';
import '../../core/errors.dart';

/// Whether a failed forgot-password call should be shown to the user. The server never reveals whether the
/// account exists, so only transport / rate-limit / server failures are reported; everything else looks like success.
bool forgotPasswordErrorIsVisible(Object e) =>
    e is! ApiException || e.status == 0 || e.status == 429 || e.status >= 500;

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final _identifier = TextEditingController();
  String? _error;
  bool _busy = false;
  bool _done = false;

  @override
  void dispose() {
    _identifier.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    if (_identifier.text.trim().isEmpty) {
      setState(() => _error = 'اكتب رقم الموبايل أو الإيميل.');
      return;
    }
    final auth = AppScope.read(context).auth;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await auth.forgotPassword(_identifier.text);
      if (!mounted) return;
      setState(() {
        _busy = false;
        _done = true;
      });
    } catch (e) {
      if (!mounted) return;
      if (forgotPasswordErrorIsVisible(e)) {
        setState(() {
          _busy = false;
          _error = friendlyError(e);
        });
      } else {
        setState(() {
          _busy = false;
          _done = true;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('نسيت كلمة السر')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: _done
                  ? Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Icon(Icons.mark_email_read_outlined, size: 56, color: scheme.primary),
                      const SizedBox(height: 12),
                      const Text(
                        'لو الحساب موجود، تم تسجيل طلبك وهيتواصل معاك المساعد لإعادة تعيين كلمة السر.',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      FilledButton(onPressed: () => Navigator.of(context).pop(), child: const Text('رجوع لتسجيل الدخول')),
                    ])
                  : Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      const Text('اكتب رقم الموبايل أو الإيميل المسجّل بيه، وهنبلّغ المساعد.', textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _identifier,
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _submit(),
                        decoration: const InputDecoration(labelText: 'رقم الموبايل أو الإيميل'),
                      ),
                      if (_error != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 12),
                          child: Text(_error!, style: TextStyle(color: scheme.error)),
                        ),
                      const SizedBox(height: 20),
                      FilledButton(onPressed: _busy ? null : _submit, child: Text(_busy ? 'جاري الإرسال...' : 'إرسال')),
                    ]),
            ),
          ),
        ),
      ),
    );
  }
}
