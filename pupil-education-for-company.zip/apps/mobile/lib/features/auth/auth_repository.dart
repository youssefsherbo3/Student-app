import 'package:flutter/foundation.dart';

import '../../core/api_client.dart';
import '../../core/token_store.dart';
import '../../core/utils.dart';

class AppUser {
  const AppUser({
    required this.id,
    required this.name,
    required this.role,
    this.email,
    this.phone,
    this.parentPhone,
    this.avatarUrl,
    this.deviceBound = false,
  });

  final String id;
  final String name;
  final String role;
  final String? email;
  final String? phone;
  final String? parentPhone;

  /// Server-relative public path (use `absoluteUrl`), or null.
  final String? avatarUrl;
  final bool deviceBound;

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: asString(j['id']),
        name: asString(j['name']),
        role: asString(j['role'], 'student'),
        email: j['email'] as String?,
        phone: j['phone'] as String?,
        parentPhone: j['parentPhone'] as String?,
        avatarUrl: asStringOrNull(j['avatarUrl']),
        deviceBound: j['deviceBound'] == true,
      );
}

abstract class AuthRepository {
  /// Current signed-in user; null when signed out. Becomes null when the session expires.
  ValueListenable<AppUser?> get user;

  /// Tries to resume a stored session (never throws).
  Future<void> restore();

  Future<AppUser> login(String identifier, String password);

  Future<AppUser> register({
    required String name,
    required String password,
    String? phone,
    String? email,
    String? parentPhone,
  });

  Future<void> logout();

  Future<void> changePassword(String current, String next);

  /// `POST /auth/forgot-password`. The server answers 204 whether or not the account exists.
  Future<void> forgotPassword(String identifier);

  /// `PATCH /auth/me`; publishes and returns the updated user. [avatarUploadId] comes from `POST /uploads?kind=avatar`.
  Future<AppUser> updateProfile({String? name, String? avatarUploadId});
}

class HttpAuthRepository implements AuthRepository {
  HttpAuthRepository({required ApiClient api, required TokenStore tokens, required String deviceId})
      : _api = api,
        _tokens = tokens,
        _deviceId = deviceId {
    api.onSessionExpired = () => _user.value = null;
  }

  final ApiClient _api;
  final TokenStore _tokens;
  final String _deviceId;
  final ValueNotifier<AppUser?> _user = ValueNotifier<AppUser?>(null);

  @override
  ValueListenable<AppUser?> get user => _user;

  Future<AppUser> _startSession(dynamic data) async {
    final m = Map<String, dynamic>.from(data as Map);
    await _tokens.save(m['accessToken'] as String, m['refreshToken'] as String);
    final u = AppUser.fromJson(Map<String, dynamic>.from(m['user'] as Map));
    _user.value = u;
    return u;
  }

  @override
  Future<void> restore() async {
    final access = await _tokens.readAccess();
    final refresh = await _tokens.readRefresh();
    if (access == null && refresh == null) return;
    try {
      final data = await _api.get('/auth/me');
      _user.value = AppUser.fromJson(Map<String, dynamic>.from(data as Map));
    } catch (e) {
      // Offline: keep the tokens so the next launch can resume. Anything else: start clean.
      if (e is ApiException && e.status == 0) return;
      await _tokens.clear();
    }
  }

  @override
  Future<AppUser> login(String identifier, String password) async {
    final data = await _api.post(
      '/auth/login',
      body: {'identifier': identifier.trim(), 'password': password, 'deviceId': _deviceId},
      auth: false,
    );
    return _startSession(data);
  }

  @override
  Future<AppUser> register({
    required String name,
    required String password,
    String? phone,
    String? email,
    String? parentPhone,
  }) async {
    final data = await _api.post(
      '/auth/register',
      body: {
        'name': name.trim(),
        'password': password,
        'deviceId': _deviceId,
        if (phone != null && phone.trim().isNotEmpty) 'phone': phone.trim(),
        if (email != null && email.trim().isNotEmpty) 'email': email.trim(),
        if (parentPhone != null && parentPhone.trim().isNotEmpty) 'parentPhone': parentPhone.trim(),
      },
      auth: false,
    );
    return _startSession(data);
  }

  @override
  Future<void> logout() async {
    final rt = await _tokens.readRefresh();
    _user.value = null;
    if (rt != null) {
      try {
        await _api.post('/auth/logout', body: {'refreshToken': rt}, auth: false);
      } catch (_) {
        // Best effort: the local session is gone either way.
      }
    }
    await _tokens.clear();
  }

  @override
  Future<void> changePassword(String current, String next) async {
    await _api.post('/auth/change-password', body: {'current': current, 'next': next});
  }

  @override
  Future<void> forgotPassword(String identifier) async {
    await _api.post('/auth/forgot-password', body: {'identifier': identifier.trim()}, auth: false);
  }

  @override
  Future<AppUser> updateProfile({String? name, String? avatarUploadId}) async {
    final data = await _api.patch('/auth/me', body: {
      if (name != null) 'name': name.trim(),
      if (avatarUploadId != null) 'avatarUploadId': avatarUploadId,
    });
    final u = AppUser.fromJson(Map<String, dynamic>.from(data as Map));
    _user.value = u;
    return u;
  }
}
