import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../shell/home_shell.dart';
import 'auth_repository.dart';
import 'login_page.dart';

/// Home route: resumes a stored session, then shows login or the main shell.
/// When the session ends (logout / refresh failure) every pushed route is popped.
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  AuthRepository? _auth;
  bool _restoring = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_auth != null) return;
    final auth = AppScope.of(context).auth;
    _auth = auth;
    auth.user.addListener(_onUserChanged);
    auth.restore().whenComplete(() {
      if (mounted) setState(() => _restoring = false);
    });
  }

  void _onUserChanged() {
    if (!mounted) return;
    if (_auth?.user.value == null) {
      Navigator.of(context).popUntil((r) => r.isFirst);
    }
  }

  @override
  void dispose() {
    _auth?.user.removeListener(_onUserChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = _auth;
    if (_restoring || auth == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return ValueListenableBuilder<AppUser?>(
      valueListenable: auth.user,
      builder: (context, user, _) =>
          user == null ? const LoginPage() : HomeShell(key: ValueKey<String>(user.id)),
    );
  }
}
