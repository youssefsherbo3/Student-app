import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/errors.dart';
import '../../core/widgets.dart';
import 'forgot_password_page.dart';
import 'register_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _identifier = TextEditingController();
  final _password = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _identifier.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    if (_identifier.text.trim().isEmpty || _password.text.isEmpty) {
      setState(() => _error = 'اكتب رقم الموبايل أو الإيميل وكلمة السر.');
      return;
    }
    final auth = AppScope.read(context).auth;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await auth.login(_identifier.text, _password.text);
      // On success AuthGate swaps this page out; nothing else to do.
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = friendlyError(e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(Icons.school, size: 64, color: scheme.primary),
                  const SizedBox(height: 8),
                  Text('تسجيل الدخول', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _identifier,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(labelText: 'رقم الموبايل أو الإيميل'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _password,
                    obscureText: true,
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) => _submit(),
                    decoration: const InputDecoration(labelText: 'كلمة السر'),
                  ),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(_error!, style: TextStyle(color: scheme.error)),
                    ),
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: Text(_busy ? 'جاري الدخول...' : 'دخول'),
                  ),
                  TextButton(
                    onPressed: _busy ? null : () => pushPage<void>(context, const RegisterPage()),
                    child: const Text('حساب جديد'),
                  ),
                  TextButton(
                    onPressed: _busy ? null : () => pushPage<void>(context, const ForgotPasswordPage()),
                    child: const Text('نسيت كلمة السر؟'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
