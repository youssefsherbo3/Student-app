import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'core/api_client.dart';
import 'core/app_scope.dart';
import 'core/config.dart';
import 'core/device_id.dart';
import 'core/image_picker_service.dart';
import 'core/token_store.dart';
import 'features/auth/auth_repository.dart';
import 'features/courses/courses_repository.dart';
import 'features/lessons/lessons_repository.dart';
import 'features/notifications/notifications_repository.dart';
import 'features/notifications/push_service.dart';
import 'features/quizzes/quizzes_repository.dart';
import 'features/redeem/redeem_repository.dart';
import 'features/uploads/uploads_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final deviceId = await loadOrCreateDeviceId(prefs);
  final tokens = PrefsTokenStore(prefs);
  final api = ApiClient(baseUrl: AppConfig.apiBase, tokens: tokens, deviceId: deviceId);

  runApp(AppScope(
    auth: HttpAuthRepository(api: api, tokens: tokens, deviceId: deviceId),
    courses: HttpCoursesRepository(api),
    lessons: HttpLessonsRepository(api),
    quizzes: HttpQuizzesRepository(api),
    redeem: HttpRedeemRepository(api),
    notifications: HttpNotificationsRepository(api),
    push: const NoopPushService(),
    uploads: HttpUploadsRepository(api),
    imagePicker: DefaultImagePickerService(),
    child: const EduApp(),
  ));
}
