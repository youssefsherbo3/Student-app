import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'api_client.dart';
import 'app_scope.dart';
import 'config.dart';
import 'errors.dart';

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

Future<T?> pushPage<T>(BuildContext context, Widget page) =>
    Navigator.of(context).push<T>(MaterialPageRoute<T>(builder: (_) => page));

/// Loads data once, shows spinner / error (with retry) / content.
class AsyncView<T> extends StatefulWidget {
  const AsyncView({super.key, required this.load, required this.builder});

  final Future<T> Function() load;

  /// `reload` re-fetches without showing the spinner (use it for pull-to-refresh).
  final Widget Function(BuildContext context, T data, Future<void> Function() reload) builder;

  @override
  State<AsyncView<T>> createState() => _AsyncViewState<T>();
}

class _AsyncViewState<T> extends State<AsyncView<T>> {
  T? _data;
  bool _hasData = false;
  bool _loading = true;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    try {
      final d = await widget.load();
      if (!mounted) return;
      setState(() {
        _data = d;
        _hasData = true;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e;
        _loading = false;
      });
    }
  }

  void _retry() {
    setState(() {
      _loading = true;
      _error = null;
    });
    _run();
  }

  @override
  Widget build(BuildContext context) {
    if (_hasData) return widget.builder(context, _data as T, _run);
    if (_loading) return const Center(child: CircularProgressIndicator());
    return ErrorView(error: _error ?? 'error', onRetry: _retry);
  }
}

class ErrorView extends StatelessWidget {
  const ErrorView({super.key, required this.error, this.onRetry});

  final Object error;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    final e = error;
    final locked = e is ApiException && e.isDeviceLocked;
    final auth = AppScope.maybeOf(context)?.auth;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, size: 48),
          const SizedBox(height: 12),
          Text(friendlyError(e), textAlign: TextAlign.center),
          const SizedBox(height: 16),
          if (locked && auth != null)
            FilledButton.tonal(onPressed: auth.logout, child: const Text('تسجيل خروج'))
          else if (onRetry != null)
            FilledButton(onPressed: onRetry, child: const Text('حاول تاني')),
        ]),
      ),
    );
  }
}

class EmptyView extends StatelessWidget {
  const EmptyView(this.message, {super.key});

  final String message;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 96, horizontal: 24),
        child: Center(child: Text(message, textAlign: TextAlign.center)),
      );
}

Widget _brokenImage() => const SizedBox(
      height: 80,
      child: Center(child: Icon(Icons.broken_image_outlined, color: Colors.grey)),
    );

/// Public server image (`/files/public/...` or a full URL) with a fallback icon when it fails to load.
class NetImage extends StatelessWidget {
  const NetImage(this.url, {super.key, this.height = 200});

  final String url;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: height),
      child: Image.network(
        absoluteUrl(url),
        fit: BoxFit.contain,
        errorBuilder: (context, error, stack) => _brokenImage(),
        loadingBuilder: (context, child, progress) =>
            progress == null ? child : const SizedBox(height: 80, child: Center(child: CircularProgressIndicator(strokeWidth: 2))),
      ),
    );
  }
}

/// Private upload (e.g. the student's own essay photo), downloaded with the auth header.
class AuthImage extends StatefulWidget {
  const AuthImage(this.uploadId, {super.key, this.height = 200});

  final String uploadId;
  final double height;

  @override
  State<AuthImage> createState() => _AuthImageState();
}

class _AuthImageState extends State<AuthImage> {
  Future<Uint8List>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future ??= AppScope.read(context).uploads.download(widget.uploadId);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError) return _brokenImage();
        final bytes = snap.data;
        if (bytes == null) return const SizedBox(height: 80, child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
        return ConstrainedBox(
          constraints: BoxConstraints(maxHeight: widget.height),
          child: Image.memory(bytes, fit: BoxFit.contain, errorBuilder: (context, error, stack) => _brokenImage()),
        );
      },
    );
  }
}
