import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

const _key = 'device_id';

/// Stable per-install id (API requires 8-100 chars). Generated once, then persisted (also on web).
Future<String> loadOrCreateDeviceId(SharedPreferences prefs) async {
  final existing = prefs.getString(_key);
  if (existing != null && existing.length >= 8) return existing;
  final id = const Uuid().v4();
  await prefs.setString(_key, id);
  return id;
}
