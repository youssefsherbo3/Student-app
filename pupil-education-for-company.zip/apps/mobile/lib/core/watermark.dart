import 'dart:async';

import 'package:flutter/material.dart';

/// Deterministic pseudo-random spot for the watermark at a given [step] (one step = one move).
///
/// Even steps land in the left half, odd steps in the right half, so two consecutive positions never coincide.
/// Returned alignment components are always within [-1, 1].
Alignment watermarkAlignment(int step, {String seed = ''}) {
  const m = 2147483647;
  var h = 17;
  for (final c in seed.codeUnits) {
    h = (h * 31 + c) % m;
  }
  int next(int s) => (s * 48271) % m;
  var s = (h + (step < 0 ? -step : step) * 40503 + 1) % m;
  if (s == 0) s = 1;
  s = next(next(s));
  final fx = (s % 1000) / 1000.0;
  s = next(s);
  final fy = (s % 1000) / 1000.0;
  final left = step.isEven;
  final dx = left ? -1.0 + fx * 0.8 : 0.2 + fx * 0.8; // [-1, -0.2] or [0.2, 1]
  final dy = -0.9 + fy * 1.8; // [-0.9, 0.9]
  return Alignment(dx, dy);
}

/// Draws a faint, slowly moving label (student name + phone) over [child]. Deters screen recording / sharing:
/// a leaked clip identifies the account. Touches pass through to [child].
class Watermark extends StatefulWidget {
  const Watermark({
    super.key,
    required this.text,
    required this.child,
    this.interval = const Duration(seconds: 10),
    this.opacity = 0.25,
  });

  final String text;
  final Widget child;

  /// How often the label jumps to a new position.
  final Duration interval;
  final double opacity;

  @override
  State<Watermark> createState() => _WatermarkState();
}

class _WatermarkState extends State<Watermark> {
  Timer? _timer;
  int _step = 0;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(widget.interval, (_) {
      if (!mounted) return;
      setState(() => _step++);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.text.trim().isEmpty) return widget.child;
    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        Positioned.fill(
          child: IgnorePointer(
            child: ExcludeSemantics(
              child: AnimatedAlign(
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeInOut,
                alignment: watermarkAlignment(_step, seed: widget.text),
                child: Opacity(
                  opacity: widget.opacity,
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text(
                      widget.text,
                      textDirection: TextDirection.ltr,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        shadows: [Shadow(color: Colors.black, blurRadius: 3)],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
