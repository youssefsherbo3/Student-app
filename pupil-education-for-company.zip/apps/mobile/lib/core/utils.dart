import 'dart:convert';

/// 125 -> 2:05
String formatDuration(int secs) {
  final s = secs < 0 ? 0 : secs;
  return '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';
}

/// Score percentage (0 when total is 0).
int percent(int score, int total) =>
    total == 0 ? 0 : ((score / total) * 100).round();

String _two(int n) => n.toString().padLeft(2, '0');

String formatDate(DateTime d) => '${d.year}/${_two(d.month)}/${_two(d.day)}';

String formatDateTime(DateTime d) =>
    '${formatDate(d)} ${_two(d.hour)}:${_two(d.minute)}';

String asString(Object? v, [String fallback = '']) =>
    v == null ? fallback : '$v';

int asInt(Object? v, [int fallback = 0]) => v is num ? v.toInt() : fallback;

int? asIntOrNull(Object? v) => v is num ? v.toInt() : null;

/// A non-empty string, or null.
String? asStringOrNull(Object? v) => v is String && v.isNotEmpty ? v : null;

/// Wall clock; injectable into widgets that count down so tests can drive time.
DateTime systemNow() => DateTime.now();

DateTime? parseDate(Object? v) => v is String ? DateTime.tryParse(v) : null;

/// Accepts a bare JSON array or a page object `{items: [...]}`.
List<T> parseList<T>(dynamic data, T Function(Map<String, dynamic>) f) {
  final raw = data is Map ? data['items'] : data;
  if (raw is! List) return <T>[];
  return <T>[
    for (final e in raw)
      if (e is Map) f(Map<String, dynamic>.from(e)),
  ];
}

/// Converts a YouTube/Vimeo link into an embeddable URL; null when unsupported.
String? embedUrl(String? raw) {
  if (raw == null || raw.trim().isEmpty) return null;
  final u = Uri.tryParse(raw.trim());
  if (u == null || u.host.isEmpty) return null;
  final host = u.host.replaceFirst('www.', '');
  final seg = u.pathSegments.where((e) => e.isNotEmpty).toList();

  String? yt;
  if (host == 'youtu.be' && seg.isNotEmpty) {
    yt = seg[0];
  } else if (host.endsWith('youtube.com') ||
      host.endsWith('youtube-nocookie.com')) {
    final v = u.queryParameters['v'];
    if (v != null && v.isNotEmpty) {
      yt = v;
    } else if (seg.length >= 2 &&
        const ['embed', 'shorts', 'live'].contains(seg[0])) {
      yt = seg[1];
    }
  }
  if (yt != null)
    return 'https://www.youtube-nocookie.com/embed/$yt?rel=0&modestbranding=1&playsinline=1';

  if (host == 'vimeo.com' || host == 'player.vimeo.com') {
    final i = seg.indexWhere((e) => RegExp(r'^\d+$').hasMatch(e));
    if (i == -1) return null;
    final hash =
        u.queryParameters['h'] ?? (seg.length > i + 1 ? seg[i + 1] : null);
    return 'https://player.vimeo.com/video/${seg[i]}${hash != null ? '?h=$hash' : ''}';
  }
  return null;
}

/// Minimal page wrapping an iframe (used on mobile where we need a baseUrl origin).
String videoHtml(String url) {
  final safeUrl = const HtmlEscape(HtmlEscapeMode.attribute).convert(url);
  return '<html><body style="margin:0;background:#000"><iframe src="$safeUrl" '
      'style="position:absolute;inset:0;width:100%;height:100%;border:0" '
      'sandbox="allow-scripts allow-presentation" '
      'allow="autoplay; encrypted-media; fullscreen; picture-in-picture" '
      'referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></body></html>';
}

/// Detects png / jpeg / webp from the first bytes; `application/octet-stream` otherwise.
String sniffImageMime(List<int> b) {
  bool at(int i, List<int> sig) {
    if (b.length < i + sig.length) return false;
    for (var k = 0; k < sig.length; k++) {
      if (b[i + k] != sig[k]) return false;
    }
    return true;
  }

  if (at(0, const [0x89, 0x50, 0x4E, 0x47])) return 'image/png';
  if (at(0, const [0xFF, 0xD8, 0xFF])) return 'image/jpeg';
  if (at(0, const [0x52, 0x49, 0x46, 0x46]) &&
      at(8, const [0x57, 0x45, 0x42, 0x50]))
    return 'image/webp';
  return 'application/octet-stream';
}

/// ASCII-safe upload file name whose extension matches [mime].
String uploadFileName(String name, String mime) {
  const exts = {'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp'};
  final ext = exts[mime];
  final base = name.trim().isEmpty ? 'image' : name.trim();
  final dot = base.lastIndexOf('.');
  var stem = (dot > 0 ? base.substring(0, dot) : base).replaceAll(
    RegExp(r'[^A-Za-z0-9_-]'),
    '_',
  );
  if (!RegExp(r'[A-Za-z0-9]').hasMatch(stem)) stem = 'image';
  final current = dot > 0 ? base.substring(dot + 1).toLowerCase() : '';
  if (ext == null) return current.isEmpty ? stem : '$stem.$current';
  return '$stem.$ext';
}
