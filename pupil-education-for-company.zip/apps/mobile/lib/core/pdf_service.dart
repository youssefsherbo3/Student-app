import 'dart:typed_data';

import 'package:printing/printing.dart';

/// Opens / shares a downloaded PDF. Abstract so widget tests can inject a fake
/// (the `printing` plugin needs a real platform implementation).
abstract class PdfService {
  Future<void> open(Uint8List bytes, String filename);
}

/// Android/iOS: system share/open sheet. Web: browser download. Uses the `printing` package on all three.
class DefaultPdfService implements PdfService {
  const DefaultPdfService();

  @override
  Future<void> open(Uint8List bytes, String filename) => Printing.sharePdf(bytes: bytes, filename: filename);
}
