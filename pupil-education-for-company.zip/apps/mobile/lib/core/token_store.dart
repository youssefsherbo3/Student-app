import 'package:shared_preferences/shared_preferences.dart';

/// Where access/refresh tokens live. Swap the implementation (e.g. secure storage) without touching the rest.
abstract class TokenStore {
  Future<String?> readAccess();
  Future<String?> readRefresh();
  Future<void> save(String access, String refresh);
  Future<void> clear();
}

class InMemoryTokenStore implements TokenStore {
  InMemoryTokenStore({String? access, String? refresh})
      : _access = access,
        _refresh = refresh;

  String? _access;
  String? _refresh;

  @override
  Future<String?> readAccess() async => _access;

  @override
  Future<String?> readRefresh() async => _refresh;

  @override
  Future<void> save(String access, String refresh) async {
    _access = access;
    _refresh = refresh;
  }

  @override
  Future<void> clear() async {
    _access = null;
    _refresh = null;
  }
}

/// SharedPreferences-backed store. Not encrypted: consider flutter_secure_storage for production.
class PrefsTokenStore implements TokenStore {
  PrefsTokenStore(this._prefs);

  final SharedPreferences _prefs;
  static const _accessKey = 'access_token';
  static const _refreshKey = 'refresh_token';

  @override
  Future<String?> readAccess() async => _prefs.getString(_accessKey);

  @override
  Future<String?> readRefresh() async => _prefs.getString(_refreshKey);

  @override
  Future<void> save(String access, String refresh) async {
    await _prefs.setString(_accessKey, access);
    await _prefs.setString(_refreshKey, refresh);
  }

  @override
  Future<void> clear() async {
    await _prefs.remove(_accessKey);
    await _prefs.remove(_refreshKey);
  }
}
