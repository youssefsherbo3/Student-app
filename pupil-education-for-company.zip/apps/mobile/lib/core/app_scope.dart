import 'package:flutter/widgets.dart';

import '../features/auth/auth_repository.dart';
import '../features/courses/courses_repository.dart';
import '../features/lessons/lessons_repository.dart';
import '../features/notifications/notifications_repository.dart';
import '../features/notifications/push_service.dart';
import '../features/quizzes/quizzes_repository.dart';
import '../features/redeem/redeem_repository.dart';
import '../features/uploads/uploads_repository.dart';
import 'image_picker_service.dart';
import 'pdf_service.dart';

/// Dependency injection: holds the repositories; tests inject fakes here.
/// Place it ABOVE MaterialApp so every pushed route can see it.
class AppScope extends InheritedWidget {
  const AppScope({
    super.key,
    required this.auth,
    required this.courses,
    required this.lessons,
    required this.quizzes,
    required this.redeem,
    required this.notifications,
    required this.push,
    required this.uploads,
    required this.imagePicker,
    this.pdf = const DefaultPdfService(),
    required super.child,
  });

  final AuthRepository auth;
  final CoursesRepository courses;
  final LessonsRepository lessons;
  final QuizzesRepository quizzes;
  final RedeemRepository redeem;
  final NotificationsRepository notifications;
  final PushService push;
  final UploadsRepository uploads;
  final ImagePickerService imagePicker;
  final PdfService pdf;

  static AppScope? maybeOf(BuildContext context) => context.dependOnInheritedWidgetOfExactType<AppScope>();

  /// Use inside build / didChangeDependencies.
  static AppScope of(BuildContext context) {
    final s = maybeOf(context);
    assert(s != null, 'AppScope not found in widget tree');
    return s!;
  }

  /// Non-subscribing lookup: safe in initState and in event handlers (the scope never changes).
  static AppScope read(BuildContext context) {
    final s = context.getInheritedWidgetOfExactType<AppScope>();
    assert(s != null, 'AppScope not found in widget tree');
    return s!;
  }

  @override
  bool updateShouldNotify(AppScope oldWidget) => false;
}
