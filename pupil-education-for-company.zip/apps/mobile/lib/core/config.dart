/// Build-time configuration. Override with: --dart-define=API_URL=http://host:3000
class AppConfig {
  const AppConfig._();

  static const String apiUrl = String.fromEnvironment(
    'API_URL',
    defaultValue: 'https://pupil-learning-hub--awedy52.replit.app',
  );
  static const String apiBase = '$apiUrl/api/v1';

  /// Origin used as baseUrl when embedding video via loadHtmlString (mobile only).
  static const String embedOrigin = String.fromEnvironment('EMBED_ORIGIN', defaultValue: 'https://www.youtube-nocookie.com');
}

/// Turns a server-relative path (`/files/public/x.png`) into a full URL.
/// Files are served from the server root, so a trailing `/api/v1` on [base] is dropped.
String absoluteUrlFor(String base, String path) {
  if (path.startsWith('http://') || path.startsWith('https://')) return path;
  var root = base;
  while (root.endsWith('/')) {
    root = root.substring(0, root.length - 1);
  }
  const api = '/api/v1';
  if (root.endsWith(api)) root = root.substring(0, root.length - api.length);
  return path.startsWith('/') ? '$root$path' : '$root/$path';
}

String absoluteUrl(String path) => absoluteUrlFor(AppConfig.apiBase, path);
