import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

import 'token_store.dart';

class ApiException implements Exception {
  const ApiException(this.status, this.code, this.message, [this.details = const <dynamic>[]]);

  /// HTTP status, or 0 when the server could not be reached.
  final int status;
  final String code;
  final String message;
  final List<dynamic> details;

  bool get isDeviceLocked => code == 'device_locked';

  @override
  String toString() => 'ApiException($status, $code, $message)';
}

class ApiClient {
  ApiClient({
    required this.baseUrl,
    required this.tokens,
    required this.deviceId,
    http.Client? httpClient,
    this.onSessionExpired,
  }) : _http = httpClient ?? http.Client();

  final String baseUrl;
  final TokenStore tokens;
  final String deviceId;
  final http.Client _http;

  /// Called when refresh failed definitively (tokens already cleared).
  void Function()? onSessionExpired;

  Future<bool>? _refreshing;

  Future<dynamic> get(String path, {Map<String, String>? query}) => request('GET', path, query: query);

  Future<dynamic> post(String path, {Object? body, bool auth = true}) => request('POST', path, body: body, auth: auth);

  Future<dynamic> patch(String path, {Object? body}) => request('PATCH', path, body: body);

  Future<dynamic> delete(String path, {Object? body}) => request('DELETE', path, body: body);

  /// Sends the request; on 401 tries one token refresh and replays the request once.
  Future<dynamic> request(String method, String path, {Object? body, Map<String, String>? query, bool auth = true}) =>
      _authed<dynamic>(auth, () => _send(method, path, body, query, auth));

  /// `multipart/form-data` upload with a single file part. Same device header / refresh logic as [request];
  /// the request is rebuilt for the replay because a MultipartRequest can only be sent once.
  Future<dynamic> postMultipart(
    String path, {
    required String field,
    required List<int> bytes,
    required String filename,
    String? contentType,
    Map<String, String>? query,
  }) {
    return _authed<dynamic>(true, () async {
      final res = await _raw(() {
        final req = http.MultipartRequest('POST', _uri(path, query));
        req.headers['Accept'] = 'application/json';
        req.files.add(http.MultipartFile.fromBytes(
          field,
          bytes,
          filename: filename,
          contentType: contentType == null ? null : MediaType.parse(contentType),
        ));
        return req;
      }, true, const Duration(seconds: 60));
      return _decode(res);
    });
  }

  /// Authenticated binary download (e.g. private answer images).
  Future<Uint8List> getBytes(String path, {Map<String, String>? query}) {
    return _authed<Uint8List>(true, () async {
      final res = await _raw(() {
        final req = http.Request('GET', _uri(path, query));
        req.headers['Accept'] = '*/*';
        return req;
      }, true, const Duration(seconds: 60));
      if (res.statusCode >= 200 && res.statusCode < 300) return res.bodyBytes;
      throw _toException(res.statusCode, _tryJson(res));
    });
  }

  Future<T> _authed<T>(bool auth, Future<T> Function() op) async {
    try {
      return await op();
    } on ApiException catch (e) {
      if (auth && e.status == 401 && await _refreshOnce()) return op();
      rethrow;
    }
  }

  Future<bool> _refreshOnce() {
    final running = _refreshing;
    if (running != null) return running;
    final f = _doRefresh().whenComplete(() => _refreshing = null);
    _refreshing = f;
    return f;
  }

  Future<bool> _doRefresh() async {
    final rt = await tokens.readRefresh();
    if (rt == null) {
      await _expire();
      return false;
    }
    try {
      final data = await _send('POST', '/auth/refresh', {'refreshToken': rt, 'deviceId': deviceId}, null, false);
      final m = data as Map<String, dynamic>;
      await tokens.save(m['accessToken'] as String, m['refreshToken'] as String);
      return true;
    } on ApiException catch (e) {
      if (e.status != 0) await _expire();
      return false;
    } catch (_) {
      return false;
    }
  }

  Future<void> _expire() async {
    await tokens.clear();
    onSessionExpired?.call();
  }

  Uri _uri(String path, Map<String, String>? query) => Uri.parse('$baseUrl$path').replace(queryParameters: query);

  Future<dynamic> _send(String method, String path, Object? body, Map<String, String>? query, bool auth) async {
    final res = await _raw(() {
      final req = http.Request(method, _uri(path, query));
      req.headers['Accept'] = 'application/json';
      if (body != null) {
        req.headers['Content-Type'] = 'application/json; charset=utf-8';
        req.body = jsonEncode(body);
      }
      return req;
    }, auth, const Duration(seconds: 30));
    return _decode(res);
  }

  /// Adds the device / auth headers, sends, and maps transport failures to ApiException(status 0).
  Future<http.Response> _raw(http.BaseRequest Function() build, bool auth, Duration timeout) async {
    final req = build();
    req.headers['X-Device-Id'] = deviceId;
    if (auth) {
      final token = await tokens.readAccess();
      if (token != null) req.headers['Authorization'] = 'Bearer $token';
    }
    try {
      final streamed = await _http.send(req).timeout(timeout);
      return await http.Response.fromStream(streamed);
    } catch (_) {
      throw const ApiException(0, 'network', 'تعذّر الاتصال بالسيرفر');
    }
  }

  dynamic _tryJson(http.Response res) {
    final text = utf8.decode(res.bodyBytes, allowMalformed: true);
    if (text.isEmpty) return null;
    try {
      return jsonDecode(text);
    } catch (_) {
      return null;
    }
  }

  dynamic _decode(http.Response res) {
    final json = _tryJson(res);
    if (res.statusCode >= 200 && res.statusCode < 300) return json;
    throw _toException(res.statusCode, json);
  }

  ApiException _toException(int status, dynamic json) {
    if (json is Map && json['error'] is Map) {
      final e = json['error'] as Map;
      final details = e['details'];
      return ApiException(
        status,
        '${e['code'] ?? 'http_$status'}',
        '${e['message'] ?? ''}',
        details is List ? details : const <dynamic>[],
      );
    }
    return ApiException(status, 'http_$status', '');
  }
}
