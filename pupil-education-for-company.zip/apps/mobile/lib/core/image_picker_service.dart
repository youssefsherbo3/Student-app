import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';

/// An image chosen by the user, already read into memory (works on mobile and web).
class PickedImage {
  const PickedImage({required this.bytes, required this.name});

  final Uint8List bytes;
  final String name;
}

enum ImagePickSource { gallery, camera }

/// Abstraction over the `image_picker` plugin so widget tests can inject a fake.
abstract class ImagePickerService {
  /// Returns null when the user cancelled.
  Future<PickedImage?> pick(ImagePickSource source);
}

class DefaultImagePickerService implements ImagePickerService {
  DefaultImagePickerService([ImagePicker? picker]) : _picker = picker ?? ImagePicker();

  final ImagePicker _picker;

  @override
  Future<PickedImage?> pick(ImagePickSource source) async {
    final XFile? file = await _picker.pickImage(
      source: source == ImagePickSource.camera ? ImageSource.camera : ImageSource.gallery,
      maxWidth: 1800,
      imageQuality: 85,
    );
    if (file == null) return null;
    final bytes = await file.readAsBytes();
    return PickedImage(bytes: bytes, name: file.name);
  }
}
