import 'api_client.dart';

const _byCode = <String, String>{
  'network': 'مفيش اتصال بالسيرفر. اتأكد من النت وجرّب تاني.',
  'unauthorized': 'لازم تسجّل دخول الأول.',
  'invalid_credentials': 'بيانات الدخول غلط.',
  'invalid_token': 'انتهت الجلسة، سجّل دخول تاني.',
  'device_unbound': 'انتهت الجلسة، سجّل دخول تاني.',
  'forbidden': 'مش مسموحلك بالعملية دي.',
  'device_locked': 'حسابك مربوط بجهاز تاني. اطلب من المساعد فك الربط.',
  'not_enrolled': 'إنت مش مشترك في الكورس ده.',
  'account_disabled': 'الحساب ده موقوف. كلّم المساعد.',
  'invalid_code': 'الكود غير صحيح أو مستخدم قبل كده.',
  'locked_lesson': 'الدرس ده لسه مقفول.',
  'too_early': 'لسه ما خلصتش المدة المطلوبة للدرس.',
  'closed': 'الامتحان ده اتقفل.',
  'no_attempts_left': 'خلصت كل محاولاتك.',
  'time_over': 'انتهى وقت الامتحان.',
  'no_session': 'جلسة الامتحان مش موجودة. افتح الامتحان من جديد.',
  'session_required': 'لازم تبدأ الامتحان الأول.',
  'not_started': 'لازم تبدأ الامتحان الأول.',
  'too_many_attempts': 'محاولات كتير غلط. استنى شوية وجرّب تاني.',
  'too_many_requests': 'طلبات كتير. استنى شوية وجرّب تاني.',
};

const _generic = 'حصلت مشكلة. جرّب تاني.';

/// Arabic, user-facing message for any error thrown by the data layer.
String friendlyError(Object e) {
  if (e is! ApiException) return _generic;
  final known = _byCode[e.code];
  if (known != null) return known;
  if (e.code.endsWith('_not_found')) return 'العنصر المطلوب مش موجود.';
  if (e.code == 'validation_error') {
    for (final d in e.details) {
      if (d is Map && d['message'] is String) return d['message'] as String;
    }
    return e.message.isNotEmpty ? e.message : 'البيانات المدخلة غير صحيحة.';
  }
  if (e.status >= 500) return 'في مشكلة في السيرفر. جرّب بعد شوية.';
  return e.message.isNotEmpty ? e.message : _generic;
}
