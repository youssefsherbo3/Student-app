# تطبيق الطالب (Flutter: Android + iOS + Web)

Student app for the educational platform. It talks to the REST API in `apps/api` (`/api/v1`, contract in `docs/API.md`).

> This project includes Flutter source plus Android and iOS platform scaffolding. It contains no prebuilt APK/IPA.
> Verified with `flutter analyze` and `flutter test`. The app uses the published API by default; creating a signed store release still requires your own Android/iOS signing setup.

## Run

Requires Flutter 3.22+ (Dart 3.4+). All commands from `apps/mobile`:

```bash
# 1. dependencies
flutter pub get

# 2. run against the local API (start it first: cd ../api && npm run dev, port 3000)
flutter run --dart-define=API_URL=http://10.0.2.2:3000        # Android emulator
flutter run --dart-define=API_URL=http://localhost:3000       # iOS simulator, or: flutter run -d chrome ...
flutter run --dart-define=API_URL=http://<laptop-LAN-IP>:3000 # real phone (same wifi as the laptop)
```

`API_URL` defaults to the published platform backend (`https://pupil-learning-hub--awedy52.replit.app`).
For local development, override it as shown above. Optional: `--dart-define=EMBED_ORIGIN=https://yourdomain.com`
(the origin sent to Vimeo when its domain restriction is enabled).

### Build an Android release

After generating platform folders and installing dependencies, run:

```bash
flutter analyze
flutter test
flutter build apk --release
```

The generated APK is at `build/app/outputs/flutter-apk/app-release.apk`. iOS builds require macOS and Xcode; create a signed iOS archive there with `flutter build ipa --release`.
Before publishing to either store, replace the sample application/bundle ID with one registered to your organization.

### Local http on Android

Android blocks plain `http://` by default. After `flutter create`, for local development only, edit
`android/app/src/main/AndroidManifest.xml` and add the attribute to the `<application ...>` tag:

```xml
<application android:usesCleartextTraffic="true" ...>
```

Use https in production. A real phone also needs the laptop firewall to allow port 3000, and the API must listen on
`0.0.0.0`. On the web, the API must allow your origin through CORS.

### Demo student login

Run `cd ../api && npm run seed:demo`. It prints the demo accounts, e.g. `01011111111 / <generated password>`
(students "طالب تجريبي ١..٣"; the password is shown once in the seed output) plus subscription codes you can use
in the "كود" tab.

A student account is bound to the first device that logs in (the app sends `X-Device-Id`, a UUID generated once and
stored locally, also on web). Logging in from another browser/device returns `403 device_locked`; ask an assistant to reset the device.

## Features (student)

- Courses, sequential lessons with a minimum watch time; a heartbeat is sent every 30 s while a lesson is open.
- Courses are grouped under each subscribed teacher. A lesson can require submission of a linked exam or homework before it opens; tapping the locked lesson opens that assessment directly.
- The Arabic in-app guide explains how to activate a subscription, find courses, watch lessons, submit assessments, and review results.
- Moving watermark (name + phone) over the video: deters leaks, cannot stop screen recording.
- Quizzes: optional timer (countdown, auto-submit at the end, server is authoritative), shuffled questions/options,
  question images, essay answers as text and/or photos (`image_picker`, behind `ImagePickerService` so tests can fake it).
- Review with correct answers (when the server allows), your essay photos, teacher feedback.
- Forgot password (request goes to the assistant), profile edit with avatar, class rank chip, notifications
  (including announcements), subscription codes.
- Camera/gallery permission explanations are included in `ios/Runner/Info.plist`.

The supplied archive contains the mobile client only. Lesson-to-assessment links are read from the platform API (`assessmentLocked`, `unlockAfterQuizId`, and `unlockAfterQuizTitle`); the API remains responsible for deciding whether a submitted assessment unlocks a lesson.

## Tests

```bash
flutter test
```

Unit tests: models, utils, error messages, `ApiClient` (device header, refresh-token rotation, device_locked).
Widget tests use fake repositories from `test/helpers/fakes.dart`.

## Structure

```
lib/main.dart, app.dart          wiring, MaterialApp (ar, RTL)
lib/core/                        ApiClient, token store, device id, errors, utils, theme, shared widgets, AppScope (DI)
lib/features/<feature>/          *_repository.dart (abstract + Http impl), *_models.dart, pages
```

Repositories are injected through `AppScope`; tests replace them with fakes.

## Push notifications

No Firebase dependency is included. `NoopPushService` is used; see the comment in
`lib/features/notifications/push_service.dart` for plugging in `firebase_messaging`.

## Notes

- Tokens are stored in SharedPreferences (not encrypted). Consider `flutter_secure_storage` on mobile for production.
- Video: YouTube/Vimeo links only. Mobile uses `loadHtmlString` with an iframe; web uses `loadRequest` (iframe).
- Arabic text on web needs the Flutter web font fallback (downloaded from Google Fonts at runtime unless bundled).
