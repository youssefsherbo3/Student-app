package com.pupil.edu_student

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
