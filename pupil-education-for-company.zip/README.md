# Education platform – mobile app + API

```
apps/mobile   Flutter student app (Android / iOS / Web)
apps/api      Node.js + SQLite REST API (/api/v1) + back-office endpoints
```

Quick start (two terminals):

```bash
# 1) API
cd apps/api && npm install && npm run seed:demo && npm start      # http://localhost:3000

# 2) App
cd apps/mobile && flutter pub get
flutter run --dart-define=API_URL=http://10.0.2.2:3000            # Android emulator
```

Details: `apps/api/README.md` (API, admin endpoints, deployment) and `apps/mobile/README.md` (app).
